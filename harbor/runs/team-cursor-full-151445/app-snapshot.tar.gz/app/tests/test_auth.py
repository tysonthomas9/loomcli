"""Contract tests for Auth API (register / login / me)."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from server.app import create_app
from server.auth.users import USER_OBJ_KEYS
from server.db import ensure_schema, reverse_migration, connect_and_bootstrap
from server.settings import Settings


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


USER_KEYS = set(USER_OBJ_KEYS)


def test_register_happy_path(tmp_path: Path) -> None:
    client = _client(tmp_path)
    resp = client.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password1"},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert "token" in body and len(body["token"]) >= 16
    user = body["user"]
    assert set(user.keys()) == USER_KEYS
    assert "email" not in user
    assert user["username"] == "ada"
    assert user["display_name"] == "ada"
    assert user["timezone"] is None
    assert user["avatar_url"] is None
    assert user["status_text"] is None
    assert user["status_emoji"] is None
    assert "password" not in resp.text.lower() or "password1" not in resp.text


def test_register_with_display_name(tmp_path: Path) -> None:
    client = _client(tmp_path)
    resp = client.post(
        "/api/auth/register",
        json={
            "username": "ada",
            "password": "password1",
            "display_name": "Ada Lovelace",
            "extra_ignored": True,
        },
    )
    assert resp.status_code == 201
    assert resp.json()["user"]["display_name"] == "Ada Lovelace"


def test_register_blank_display_name_defaults(tmp_path: Path) -> None:
    client = _client(tmp_path)
    resp = client.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password1", "display_name": "   "},
    )
    assert resp.status_code == 201
    assert resp.json()["user"]["display_name"] == "ada"


def test_duplicate_username_409(tmp_path: Path) -> None:
    client = _client(tmp_path)
    assert (
        client.post(
            "/api/auth/register",
            json={"username": "ada", "password": "password1"},
        ).status_code
        == 201
    )
    resp = client.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password2"},
    )
    assert resp.status_code == 409
    assert resp.json() == {
        "error": {"code": "conflict", "message": "username already taken"}
    }


@pytest.mark.parametrize(
    "payload",
    [
        {"username": "Ada", "password": "password1"},
        {"username": "a", "password": "password1"},
        {"username": "user@x.com", "password": "password1"},
        {"username": "has space", "password": "password1"},
        {"username": "ada", "password": "short"},
        {"username": "ada", "password": "x" * 129},
        {"username": "ada"},
        {"password": "password1"},
    ],
)
def test_register_validation_400(tmp_path: Path, payload: dict) -> None:
    client = _client(tmp_path)
    resp = client.post("/api/auth/register", json=payload)
    assert resp.status_code == 400
    body = resp.json()
    assert body["error"]["code"] == "validation_error"
    assert "message" in body["error"]
    assert "detail" not in body


def test_register_password_length_8_ok(tmp_path: Path) -> None:
    client = _client(tmp_path)
    resp = client.post(
        "/api/auth/register",
        json={"username": "ab", "password": "12345678"},
    )
    assert resp.status_code == 201


def test_login_success_and_new_token(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = client.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password1"},
    ).json()
    login = client.post(
        "/api/auth/login",
        json={"username": "ada", "password": "password1"},
    )
    assert login.status_code == 200
    body = login.json()
    assert set(body["user"].keys()) == USER_KEYS
    assert len(body["token"]) >= 16
    assert body["token"] != reg["token"]


def test_login_wrong_password_401(tmp_path: Path) -> None:
    client = _client(tmp_path)
    client.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password1"},
    )
    resp = client.post(
        "/api/auth/login",
        json={"username": "ada", "password": "wrongpass"},
    )
    assert resp.status_code == 401
    assert resp.json()["error"]["code"] == "unauthorized"
    assert resp.status_code != 404


def test_login_unknown_user_401(tmp_path: Path) -> None:
    client = _client(tmp_path)
    resp = client.post(
        "/api/auth/login",
        json={"username": "nobody", "password": "password1"},
    )
    assert resp.status_code == 401
    assert resp.json()["error"]["code"] == "unauthorized"
    assert resp.json()["error"]["message"] == "invalid username or password"


def test_me_success(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = client.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password1"},
    ).json()
    resp = client.get(
        "/api/auth/me",
        headers={"Authorization": f"Bearer {reg['token']}"},
    )
    assert resp.status_code == 200
    assert resp.json()["user"] == reg["user"]


def test_me_lowercase_bearer_scheme(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = client.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password1"},
    ).json()
    resp = client.get(
        "/api/auth/me",
        headers={"Authorization": f"bearer {reg['token']}"},
    )
    assert resp.status_code == 200


@pytest.mark.parametrize(
    "headers",
    [
        None,
        {"Authorization": "Bearer"},
        {"Authorization": "Bearer "},
        {"Authorization": "Token abcdefghijklmnop"},
        {"Authorization": "Bearer definitely-not-a-real-token"},
        {"Authorization": "Bearer has spaces in token"},
    ],
)
def test_me_unauthorized(tmp_path: Path, headers: dict | None) -> None:
    client = _client(tmp_path)
    resp = client.get("/api/auth/me", headers=headers)
    assert resp.status_code == 401
    assert resp.json()["error"]["code"] == "unauthorized"


def test_cluster_shared_sqlite_two_apps(tmp_path: Path) -> None:
    """Register on node 0 app; /me on node 2 app with same data_dir."""
    shared = tmp_path / "shared"
    client_a = _client(shared, node_id=0)
    client_b = _client(shared, node_id=2)
    reg = client_a.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password1"},
    )
    assert reg.status_code == 201
    token = reg.json()["token"]
    me = client_b.get(
        "/api/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert me.status_code == 200
    assert me.json()["user"]["username"] == "ada"


def test_health_still_unenveloped(tmp_path: Path) -> None:
    client = _client(tmp_path)
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json() == {"status": "ok", "node_id": 0}
    assert "error" not in health.json()


def test_passwords_not_stored_plaintext(tmp_path: Path) -> None:
    client = _client(tmp_path)
    client.post(
        "/api/auth/register",
        json={"username": "ada", "password": "password1"},
    )
    db_path = tmp_path / "huddle.sqlite"
    conn = sqlite3.connect(str(db_path))
    row = conn.execute("SELECT password_hash FROM users").fetchone()
    conn.close()
    assert row is not None
    assert "password1" not in row[0]
    assert row[0].startswith("scrypt$")


def test_migration_v1_forward_and_reverse(tmp_path: Path) -> None:
    db_path = tmp_path / "huddle.sqlite"
    ensure_schema(str(db_path))
    conn = connect_and_bootstrap(str(db_path))
    versions = {
        int(r[0]) for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 0 in versions and 1 in versions
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    assert "users" in tables and "auth_tokens" in tables
    reverse_migration(conn, 1)
    versions_after = {
        int(r[0]) for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 1 not in versions_after
    tables_after = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    assert "users" not in tables_after and "auth_tokens" not in tables_after
    conn.close()
