"""Contract tests for messages, threads, and reactions (MARATHON-8)."""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path
from urllib.parse import quote

from fastapi.testclient import TestClient

from server.app import create_app
from server.auth.users import USER_OBJ_KEYS
from server.db import (
    apply_migrations,
    connect_and_bootstrap,
    reverse_migration,
    utc_now_z,
)
from server.messages.store import MESSAGE_OBJ_KEYS
from server.settings import Settings

USER_KEYS = set(USER_OBJ_KEYS)
MSG_KEYS = set(MESSAGE_OBJ_KEYS)


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


def _register(client: TestClient, username: str) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": "password1"},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _create_ws(client: TestClient, token: str, slug: str = "acme") -> dict:
    resp = client.post(
        "/api/workspaces",
        headers=_auth(token),
        json={"slug": slug, "name": "Acme"},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["workspace"]


def _seed_ws_member(
    tmp_path: Path, *, workspace_id: str, user_id: str, role: str = "member"
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (workspace_id, user_id, role, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _setup(tmp_path: Path) -> dict:
    client = _client(tmp_path)
    owner = _register(client, "owner1")
    member = _register(client, "member1")
    stranger = _register(client, "stranger1")
    ws = _create_ws(client, owner["token"])
    _seed_ws_member(
        tmp_path, workspace_id=ws["id"], user_id=member["user"]["id"]
    )
    created = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(owner["token"]),
        json={"name": "eng"},
    )
    assert created.status_code == 201, created.text
    channel = created.json()["channel"]
    joined = client.post(
        f"/api/channels/{channel['id']}/join",
        headers=_auth(member["token"]),
    )
    assert joined.status_code == 200, joined.text
    return {
        "client": client,
        "owner": owner,
        "member": member,
        "stranger": stranger,
        "ws": ws,
        "channel": channel,
    }


def _assert_message_obj(msg: dict) -> None:
    assert set(msg.keys()) == MSG_KEYS
    assert set(msg["author"].keys()) == USER_KEYS
    assert "seq" not in msg
    assert "blocks" not in msg
    assert "deleted_at" not in msg


def test_create_list_pagination_and_keys(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    channel_id = ctx["channel"]["id"]
    h = _auth(ctx["member"]["token"])

    empty = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "   "},
    )
    assert empty.status_code == 400
    assert empty.json()["error"]["code"] == "validation_error"

    too_long = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "x" * 4001},
    )
    assert too_long.status_code == 400

    created_ids: list[str] = []
    for i, body in enumerate(("one", "two", "three")):
        resp = client.post(
            f"/api/channels/{channel_id}/messages",
            headers=h,
            json={"body": body, "extra": "ignored"},
        )
        assert resp.status_code == 201, resp.text
        msg = resp.json()["message"]
        _assert_message_obj(msg)
        assert msg["body"] == body
        assert msg["parent_id"] is None
        assert msg["edited_at"] is None
        assert msg["reply_count"] == 0
        assert msg["files"] == []
        assert msg["reactions"] == []
        assert msg["mentions"] == []
        created_ids.append(msg["id"])

    # Distinct created_at so newest-first order is deterministic within one second.
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        for i, mid in enumerate(created_ids):
            conn.execute(
                "UPDATE messages SET created_at = ? WHERE id = ?",
                (f"2026-08-23T00:00:0{i}Z", mid),
            )
        conn.commit()
    finally:
        conn.close()

    listed = client.get(f"/api/channels/{channel_id}/messages", headers=h)
    assert listed.status_code == 200
    messages = listed.json()["messages"]
    assert [m["body"] for m in messages] == ["three", "two", "one"]

    page = client.get(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        params={"limit": 2},
    )
    assert [m["body"] for m in page.json()["messages"]] == ["three", "two"]
    before_id = page.json()["messages"][-1]["id"]
    next_page = client.get(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        params={"limit": 2, "before": before_id},
    )
    assert [m["body"] for m in next_page.json()["messages"]] == ["one"]

    assert (
        client.get(
            f"/api/channels/{channel_id}/messages",
            headers=h,
            params={"limit": 0},
        ).status_code
        == 400
    )
    assert (
        client.get(
            f"/api/channels/{channel_id}/messages",
            headers=h,
            params={"limit": 101},
        ).status_code
        == 400
    )
    assert (
        client.get(
            f"/api/channels/{channel_id}/messages",
            headers=h,
            params={"before": str(uuid.uuid4())},
        ).status_code
        == 400
    )

    slash = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "/shrug hello"},
    )
    assert slash.status_code == 201
    assert slash.json()["message"]["body"] == "/shrug hello"

    assert (
        client.post(
            f"/api/channels/{channel_id}/messages",
            headers=h,
            json={"body": "ok", "blocks": {}},
        ).status_code
        == 400
    )
    blocks_ok = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "with blocks", "blocks": []},
    )
    assert blocks_ok.status_code == 201
    _assert_message_obj(blocks_ok.json()["message"])

    files = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "attach", "file_ids": [str(uuid.uuid4())]},
    )
    assert files.status_code == 400


def test_threads_replies_and_reply_count(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    channel_id = ctx["channel"]["id"]
    h = _auth(ctx["owner"]["token"])

    parent = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "parent"},
    ).json()["message"]

    r1 = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "r1", "parent_id": parent["id"]},
    )
    assert r1.status_code == 201
    r2 = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=_auth(ctx["member"]["token"]),
        json={"body": "r2", "parent_id": parent["id"]},
    )
    assert r2.status_code == 201

    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            "UPDATE messages SET created_at = ? WHERE id = ?",
            ("2026-08-23T00:01:00Z", r1.json()["message"]["id"]),
        )
        conn.execute(
            "UPDATE messages SET created_at = ? WHERE id = ?",
            ("2026-08-23T00:01:01Z", r2.json()["message"]["id"]),
        )
        conn.commit()
    finally:
        conn.close()

    deep = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "deep", "parent_id": r1.json()["message"]["id"]},
    )
    assert deep.status_code == 400

    assert (
        client.post(
            f"/api/channels/{channel_id}/messages",
            headers=h,
            json={"body": "x", "parent_id": str(uuid.uuid4())},
        ).status_code
        == 400
    )

    history = client.get(
        f"/api/channels/{channel_id}/messages", headers=h
    ).json()["messages"]
    assert [m["id"] for m in history] == [parent["id"]]
    assert history[0]["reply_count"] == 2

    replies = client.get(f"/api/messages/{parent['id']}/replies", headers=h)
    assert replies.status_code == 200
    assert "replies" in replies.json()
    assert "messages" not in replies.json()
    assert [m["body"] for m in replies.json()["replies"]] == ["r1", "r2"]


def test_edit_delete_owner_and_conflicts(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    channel_id = ctx["channel"]["id"]
    member_h = _auth(ctx["member"]["token"])
    owner_h = _auth(ctx["owner"]["token"])

    msg = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=member_h,
        json={"body": "edit me"},
    ).json()["message"]

    denied = client.patch(
        f"/api/messages/{msg['id']}",
        headers=owner_h,
        json={"body": "nope"},
    )
    assert denied.status_code == 403

    edited = client.patch(
        f"/api/messages/{msg['id']}",
        headers=member_h,
        json={"body": "edited"},
    )
    assert edited.status_code == 200
    assert edited.json()["message"]["body"] == "edited"
    assert edited.json()["message"]["edited_at"] is not None

    admin = _register(client, "admin1")
    _seed_ws_member(
        tmp_path,
        workspace_id=ctx["ws"]["id"],
        user_id=admin["user"]["id"],
        role="admin",
    )
    client.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(admin["token"]),
    )
    assert (
        client.delete(
            f"/api/messages/{msg['id']}",
            headers=_auth(admin["token"]),
        ).status_code
        == 403
    )

    owned = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=member_h,
        json={"body": "owner deletes"},
    ).json()["message"]
    owner_del = client.delete(f"/api/messages/{owned['id']}", headers=owner_h)
    assert owner_del.status_code == 200
    assert owner_del.json() == {"deleted": True}

    author_msg = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=member_h,
        json={"body": "author deletes"},
    ).json()["message"]
    d1 = client.delete(f"/api/messages/{author_msg['id']}", headers=member_h)
    assert d1.status_code == 200
    assert d1.json() == {"deleted": True}
    d2 = client.delete(f"/api/messages/{author_msg['id']}", headers=member_h)
    assert d2.status_code == 200
    assert d2.json() == {"deleted": True}

    history_ids = {
        m["id"]
        for m in client.get(
            f"/api/channels/{channel_id}/messages", headers=member_h
        ).json()["messages"]
    }
    assert author_msg["id"] not in history_ids
    assert owned["id"] not in history_ids

    conflict = client.patch(
        f"/api/messages/{author_msg['id']}",
        headers=member_h,
        json={"body": "again"},
    )
    assert conflict.status_code == 409
    assert conflict.json()["error"]["code"] == "conflict"

    react_conflict = client.post(
        f"/api/messages/{author_msg['id']}/reactions",
        headers=member_h,
        json={"emoji": "👍"},
    )
    assert react_conflict.status_code == 409


def test_reactions_idempotent_and_aggregate(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    channel_id = ctx["channel"]["id"]
    owner_h = _auth(ctx["owner"]["token"])
    member_h = _auth(ctx["member"]["token"])

    msg = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=owner_h,
        json={"body": "react"},
    ).json()["message"]

    r1 = client.post(
        f"/api/messages/{msg['id']}/reactions",
        headers=owner_h,
        json={"emoji": "👍"},
    )
    assert r1.status_code == 200
    assert r1.json()["reactions"] == [
        {
            "emoji": "👍",
            "count": 1,
            "user_ids": [ctx["owner"]["user"]["id"]],
        }
    ]
    r1b = client.post(
        f"/api/messages/{msg['id']}/reactions",
        headers=owner_h,
        json={"emoji": "👍"},
    )
    assert r1b.status_code == 200
    assert r1b.json()["reactions"][0]["count"] == 1

    r2 = client.post(
        f"/api/messages/{msg['id']}/reactions",
        headers=member_h,
        json={"emoji": "👍"},
    )
    assert r2.status_code == 200
    assert r2.json()["reactions"][0]["count"] == 2

    shortcode = client.post(
        f"/api/messages/{msg['id']}/reactions",
        headers=owner_h,
        json={"emoji": ":+1:"},
    )
    assert shortcode.status_code == 200
    assert {r["emoji"] for r in shortcode.json()["reactions"]} == {
        "👍",
        ":+1:",
    }

    missing = client.delete(
        f"/api/messages/{msg['id']}/reactions/{quote('🎉', safe='')}",
        headers=owner_h,
    )
    assert missing.status_code == 200
    assert len(missing.json()["reactions"]) == 2

    removed = client.delete(
        f"/api/messages/{msg['id']}/reactions/{quote('👍', safe='')}",
        headers=owner_h,
    )
    assert removed.status_code == 200
    thumb = next(r for r in removed.json()["reactions"] if r["emoji"] == "👍")
    assert thumb["count"] == 1
    assert thumb["user_ids"] == [ctx["member"]["user"]["id"]]


def test_mentions_authz_archived_and_cluster(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    channel_id = ctx["channel"]["id"]
    owner_h = _auth(ctx["owner"]["token"])
    member_h = _auth(ctx["member"]["token"])

    mentioned = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=owner_h,
        json={"body": "hey @member1 mid foo@member1 and @owner1 @nobody"},
    )
    assert mentioned.status_code == 201
    assert mentioned.json()["message"]["mentions"] == [
        ctx["member"]["user"]["id"]
    ]

    client.post(f"/api/channels/{channel_id}/leave", headers=member_h)
    denied = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=member_h,
        json={"body": "nope"},
    )
    assert denied.status_code == 403
    client.post(f"/api/channels/{channel_id}/join", headers=member_h)

    stranger = client.get(
        f"/api/channels/{channel_id}/messages",
        headers=_auth(ctx["stranger"]["token"]),
    )
    assert stranger.status_code == 404

    priv = client.post(
        "/api/workspaces/acme/channels",
        headers=owner_h,
        json={"name": "vault", "is_private": True},
    ).json()["channel"]
    assert (
        client.get(
            f"/api/channels/{priv['id']}/messages",
            headers=member_h,
        ).status_code
        == 403
    )

    client.post(f"/api/channels/{channel_id}/archive", headers=owner_h)
    locked = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=member_h,
        json={"body": "archived"},
    )
    assert locked.status_code == 423
    assert locked.json()["error"]["code"] == "archived"
    assert (
        client.get(
            f"/api/channels/{channel_id}/messages",
            headers=member_h,
        ).status_code
        == 200
    )
    client.post(f"/api/channels/{channel_id}/unarchive", headers=owner_h)

    posted = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=member_h,
        json={"body": "shared"},
    )
    assert posted.status_code == 201
    other = _client(tmp_path, node_id=1)
    remote = other.get(
        f"/api/channels/{channel_id}/messages",
        headers=owner_h,
    )
    assert remote.status_code == 200
    assert any(m["body"] == "shared" for m in remote.json()["messages"])


def test_pin_tombstone_after_soft_delete(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    channel_id = ctx["channel"]["id"]
    h = _auth(ctx["owner"]["token"])

    msg = client.post(
        f"/api/channels/{channel_id}/messages",
        headers=h,
        json={"body": "pin me"},
    ).json()["message"]
    assert client.post(f"/api/messages/{msg['id']}/pin", headers=h).status_code == 200
    assert client.delete(f"/api/messages/{msg['id']}", headers=h).status_code == 200

    pins = client.get(f"/api/channels/{channel_id}/pins", headers=h).json()["pins"]
    assert len(pins) == 1
    tomb = pins[0]["message"]
    _assert_message_obj(tomb)
    assert tomb["body"] == ""
    assert tomb["files"] == []
    assert tomb["reactions"] == []
    assert tomb["mentions"] == []


def test_migration_v5_apply_and_reverse(tmp_path: Path) -> None:
    db_path = str(tmp_path / "mig.sqlite")
    conn = connect_and_bootstrap(db_path)
    conn.execute(
        "INSERT INTO schema_migrations (version, applied_at) VALUES (0, ?)",
        (utc_now_z(),),
    )
    conn.commit()
    apply_migrations(conn)
    versions = {
        int(r[0])
        for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 5 in versions
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    assert "messages" in tables
    assert "message_reactions" in tables
    assert "message_files" in tables
    cols = {
        r[1] for r in conn.execute("PRAGMA table_info(messages)").fetchall()
    }
    assert "blocks_json" in cols

    reverse_migration(conn, 5)
    versions = {
        int(r[0])
        for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 5 not in versions
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    assert "message_reactions" not in tables
    assert "message_files" not in tables
    assert "messages" in tables
    conn.close()
