"""Contract tests for Workspaces API (create / list / detail)."""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from server.app import create_app
from server.channels.store import CHANNEL_OBJ_KEYS, READ_STATE_ENTRY_KEYS
from server.db import apply_migrations, connect_and_bootstrap, reverse_migration
from server.settings import Settings
from server.workspaces.store import WORKSPACE_OBJ_KEYS

WS_KEYS = set(WORKSPACE_OBJ_KEYS)
CH_KEYS = set(CHANNEL_OBJ_KEYS)
RS_KEYS = set(READ_STATE_ENTRY_KEYS)


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


def _register(
    client: TestClient,
    username: str = "ada",
    password: str = "password1",
) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": password},
    )
    assert resp.status_code == 201
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _create_ws(
    client: TestClient,
    token: str,
    slug: str = "acme",
    name: str = "Acme Corp",
) -> dict:
    resp = client.post(
        "/api/workspaces",
        headers=_auth(token),
        json={"slug": slug, "name": name},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


def test_create_workspace_happy_path(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    resp = client.post(
        "/api/workspaces",
        headers=_auth(reg["token"]),
        json={"slug": "acme", "name": "Acme Corp", "join_mode": "invite_only", "x": 1},
    )
    assert resp.status_code == 201
    body = resp.json()
    workspace = body["workspace"]
    general = body["general_channel"]
    assert set(workspace.keys()) == WS_KEYS
    assert set(general.keys()) == CH_KEYS
    assert workspace["slug"] == "acme"
    assert workspace["name"] == "Acme Corp"
    assert workspace["owner_id"] == reg["user"]["id"]
    assert workspace["join_mode"] == "open"
    assert general["name"] == "general"
    assert general["workspace_id"] == workspace["id"]
    assert general["is_private"] is False
    assert general["is_dm"] is False
    assert general["is_archived"] is False
    assert general["topic"] == ""
    assert "email" not in resp.text.lower()

    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    conn.row_factory = sqlite3.Row
    try:
        members = conn.execute(
            "SELECT role FROM workspace_members WHERE workspace_id = ?",
            (workspace["id"],),
        ).fetchall()
        assert len(members) == 1
        assert members[0]["role"] == "owner"
        channels = conn.execute(
            "SELECT name FROM channels WHERE workspace_id = ?",
            (workspace["id"],),
        ).fetchall()
        assert [r["name"] for r in channels] == ["general"]
        cm = conn.execute(
            "SELECT 1 FROM channel_members WHERE channel_id = ? AND user_id = ?",
            (general["id"], reg["user"]["id"]),
        ).fetchone()
        assert cm is not None
        rs = conn.execute("SELECT COUNT(*) AS n FROM channel_read_state").fetchone()
        assert rs["n"] == 0
    finally:
        conn.close()


def test_duplicate_slug_409(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    _create_ws(client, reg["token"])
    resp = client.post(
        "/api/workspaces",
        headers=_auth(reg["token"]),
        json={"slug": "acme", "name": "Other"},
    )
    assert resp.status_code == 409
    assert resp.json() == {
        "error": {"code": "conflict", "message": "slug already taken"}
    }


@pytest.mark.parametrize(
    "payload",
    [
        {"slug": "AB", "name": "Acme"},
        {"slug": "a", "name": "Acme"},
        {"slug": "ab_cd", "name": "Acme"},
        {"slug": "", "name": "Acme"},
        {"slug": "acme", "name": "  "},
        {"slug": "acme", "name": ""},
        {"slug": "acme"},
        {"name": "Acme"},
        {"slug": "a" * 33, "name": "Acme"},
        {"slug": "acme", "name": "x" * 81},
    ],
)
def test_create_validation_400(tmp_path: Path, payload: dict) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    resp = client.post(
        "/api/workspaces", headers=_auth(reg["token"]), json=payload
    )
    assert resp.status_code == 400
    body = resp.json()
    assert body["error"]["code"] == "validation_error"
    assert "message" in body["error"]
    assert "detail" not in body


@pytest.mark.parametrize(
    "slug,name",
    [
        ("ab", "OK"),
        ("a-b", "OK"),
        ("a" * 32, "OK"),
        ("acme", "  Acme Corp  "),
        ("acme", "Acmé 公司"),
    ],
)
def test_create_slug_name_accepted(tmp_path: Path, slug: str, name: str) -> None:
    client = _client(tmp_path)
    reg = _register(client, username=f"u{uuid.uuid4().hex[:8]}")
    resp = client.post(
        "/api/workspaces",
        headers=_auth(reg["token"]),
        json={"slug": slug, "name": name},
    )
    assert resp.status_code == 201
    assert resp.json()["workspace"]["name"] == name.strip()


@pytest.mark.parametrize(
    "method,path,kwargs",
    [
        ("post", "/api/workspaces", {"json": {"slug": "acme", "name": "Acme"}}),
        ("get", "/api/workspaces", {}),
        ("get", "/api/workspaces/acme", {}),
    ],
)
def test_unauthorized(tmp_path: Path, method: str, path: str, kwargs: dict) -> None:
    client = _client(tmp_path)
    resp = getattr(client, method)(path, **kwargs)
    assert resp.status_code == 401
    assert resp.json()["error"]["code"] == "unauthorized"


def test_list_empty_then_after_create(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    empty = client.get("/api/workspaces", headers=_auth(reg["token"]))
    assert empty.status_code == 200
    assert empty.json() == {"workspaces": []}

    created = _create_ws(client, reg["token"], slug="zeta", name="Zeta")
    _create_ws(client, reg["token"], slug="alpha", name="Alpha")
    listed = client.get("/api/workspaces", headers=_auth(reg["token"]))
    assert listed.status_code == 200
    names = [w["name"] for w in listed.json()["workspaces"]]
    assert names == ["Alpha", "Zeta"]
    assert created["workspace"]["slug"] == "zeta"


def test_detail_member_vs_non_member(tmp_path: Path) -> None:
    client = _client(tmp_path)
    owner = _register(client, username="owner1")
    other = _register(client, username="other1")
    _create_ws(client, owner["token"], slug="acme", name="Acme")

    ok = client.get("/api/workspaces/acme", headers=_auth(owner["token"]))
    assert ok.status_code == 200
    body = ok.json()
    assert set(body["workspace"].keys()) == WS_KEYS
    assert len(body["channels"]) == 1
    assert body["channels"][0]["name"] == "general"
    assert set(body["channels"][0].keys()) == CH_KEYS
    assert body["read_state"] == []

    missing = client.get("/api/workspaces/nope", headers=_auth(owner["token"]))
    assert missing.status_code == 404
    assert missing.json() == {
        "error": {"code": "not_found", "message": "workspace not found"}
    }

    denied = client.get("/api/workspaces/acme", headers=_auth(other["token"]))
    assert denied.status_code == 404
    assert denied.json() == {
        "error": {"code": "not_found", "message": "workspace not found"}
    }


def test_include_archived_and_private_filter(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    created = _create_ws(client, reg["token"])
    ws_id = created["workspace"]["id"]
    user_id = reg["user"]["id"]

    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        now = "2026-01-01T00:00:00Z"
        archived_id = str(uuid.uuid4())
        private_id = str(uuid.uuid4())
        private_arch_id = str(uuid.uuid4())
        conn.execute(
            """
            INSERT INTO channels (
                id, workspace_id, name, is_private, is_dm, topic, is_archived,
                created_at, updated_at
            ) VALUES
            (?, ?, 'archived-pub', 0, 0, '', 1, ?, ?),
            (?, ?, 'secret', 1, 0, '', 0, ?, ?),
            (?, ?, 'secret-arch', 1, 0, '', 1, ?, ?)
            """,
            (
                archived_id,
                ws_id,
                now,
                now,
                private_id,
                ws_id,
                now,
                now,
                private_arch_id,
                ws_id,
                now,
                now,
            ),
        )
        conn.commit()
    finally:
        conn.close()

    default = client.get("/api/workspaces/acme", headers=_auth(reg["token"]))
    assert default.status_code == 200
    names = {c["name"] for c in default.json()["channels"]}
    assert names == {"general"}

    for query in ("include_archived=1", "include_archived=true", "include_archived=TRUE"):
        resp = client.get(
            f"/api/workspaces/acme?{query}", headers=_auth(reg["token"])
        )
        assert resp.status_code == 200
        names = {c["name"] for c in resp.json()["channels"]}
        assert names == {"archived-pub", "general"}
        assert "secret" not in names
        assert "secret-arch" not in names

    for query in (
        "include_archived=0",
        "include_archived=false",
        "include_archived=yes",
        "include_archived=on",
    ):
        resp = client.get(
            f"/api/workspaces/acme?{query}", headers=_auth(reg["token"])
        )
        assert resp.status_code == 200
        names = {c["name"] for c in resp.json()["channels"]}
        assert names == {"general"}

    # Private visible when membership exists, still omitted without it.
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            "INSERT INTO channel_members (channel_id, user_id, created_at) VALUES (?, ?, ?)",
            (private_id, user_id, now),
        )
        conn.commit()
    finally:
        conn.close()

    with_priv = client.get(
        "/api/workspaces/acme?include_archived=1", headers=_auth(reg["token"])
    )
    names = {c["name"] for c in with_priv.json()["channels"]}
    assert "secret" in names
    assert "secret-arch" not in names  # still no membership


def test_read_state_full_shape_for_visible_only(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    created = _create_ws(client, reg["token"])
    general_id = created["general_channel"]["id"]
    ws_id = created["workspace"]["id"]
    user_id = reg["user"]["id"]

    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        now = "2026-01-01T00:00:00Z"
        private_id = str(uuid.uuid4())
        conn.execute(
            """
            INSERT INTO channels (
                id, workspace_id, name, is_private, is_dm, topic, is_archived,
                created_at, updated_at
            ) VALUES (?, ?, 'hidden', 1, 0, '', 0, ?, ?)
            """,
            (private_id, ws_id, now, now),
        )
        conn.execute(
            """
            INSERT INTO channel_read_state (
                channel_id, user_id, last_read_seq, unread_count, mention_count,
                updated_at
            ) VALUES
            (?, ?, 12, 3, 1, ?),
            (?, ?, 99, 7, 2, ?)
            """,
            (general_id, user_id, now, private_id, user_id, now),
        )
        conn.commit()
    finally:
        conn.close()

    resp = client.get("/api/workspaces/acme", headers=_auth(reg["token"]))
    assert resp.status_code == 200
    body = resp.json()
    assert {c["name"] for c in body["channels"]} == {"general"}
    assert len(body["read_state"]) == 1
    entry = body["read_state"][0]
    assert set(entry.keys()) == RS_KEYS
    assert entry == {
        "channel_id": general_id,
        "last_read_seq": 12,
        "unread_count": 3,
        "mention_count": 1,
    }


def test_two_apps_share_data_dir(tmp_path: Path) -> None:
    a = _client(tmp_path, node_id=0)
    b = _client(tmp_path, node_id=1)
    reg = _register(a)
    created = _create_ws(a, reg["token"], slug="shared", name="Shared")
    listed = b.get("/api/workspaces", headers=_auth(reg["token"]))
    assert listed.status_code == 200
    assert any(w["slug"] == "shared" for w in listed.json()["workspaces"])
    detail = b.get("/api/workspaces/shared", headers=_auth(reg["token"]))
    assert detail.status_code == 200
    assert detail.json()["workspace"]["id"] == created["workspace"]["id"]


def test_migration_v2_idempotent_and_reversible(tmp_path: Path) -> None:
    sqlite_path = str(tmp_path / "huddle.sqlite")
    # Start from v1-only DB then upgrade.
    conn = connect_and_bootstrap(sqlite_path)
    conn.execute(
        "INSERT INTO schema_migrations (version, applied_at) VALUES (0, ?)",
        ("2026-01-01T00:00:00Z",),
    )
    conn.commit()
    from server.db import _migrate_v1

    _migrate_v1(conn)
    conn.execute(
        "INSERT INTO schema_migrations (version, applied_at) VALUES (1, ?)",
        ("2026-01-01T00:00:00Z",),
    )
    conn.commit()
    apply_migrations(conn)
    versions = {
        int(r[0]) for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 2 in versions
    cols = {
        r[1]
        for r in conn.execute("PRAGMA table_info(channel_read_state)").fetchall()
    }
    assert {"unread_count", "mention_count", "last_read_seq"} <= cols
    apply_migrations(conn)  # idempotent
    reverse_migration(conn, 2)
    versions = {
        int(r[0]) for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 2 not in versions
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    assert "workspaces" not in tables
    conn.close()
