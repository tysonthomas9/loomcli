"""Unit tests for Huddle node settings, health, and SQLite bootstrap."""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from server.app import create_app
from server.db import ensure_bootstrap
from server.settings import Settings, load_settings


def test_load_settings_maps_node_to_port(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HUDDLE_NODE_ID", "1")
    monkeypatch.setenv("HUDDLE_PORT", "8001")
    monkeypatch.setenv("HUDDLE_DATA_DIR", "/tmp/huddle-test-data")
    cfg = load_settings()
    assert cfg.node_id == 1
    assert cfg.port == 8001
    assert cfg.sqlite_path == "/tmp/huddle-test-data/huddle.sqlite"


def test_load_settings_rejects_node_port_mismatch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("HUDDLE_NODE_ID", "0")
    monkeypatch.setenv("HUDDLE_PORT", "8001")
    with pytest.raises(SystemExit, match="requires port 8000"):
        load_settings()


def test_load_settings_requires_node_id(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("HUDDLE_NODE_ID", raising=False)
    with pytest.raises(SystemExit, match="HUDDLE_NODE_ID"):
        load_settings()


def test_health_and_root(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HUDDLE_NODE_ID", "2")
    monkeypatch.setenv("HUDDLE_PORT", "8002")
    monkeypatch.setenv("HUDDLE_DATA_DIR", str(tmp_path))
    cfg = Settings(
        node_id=2,
        port=8002,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )
    client = TestClient(create_app(cfg))
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.headers["content-type"].startswith("application/json")
    assert health.json() == {"status": "ok", "node_id": 2}
    assert "Authorization" not in health.request.headers or True

    root = client.get("/")
    assert root.status_code == 200
    assert "text/html" in root.headers["content-type"]
    assert "Huddle" in root.text
    assert 'data-testid="auth-form"' in root.text
    assert "Cluster node stub" not in root.text


def test_sqlite_bootstrap_wal(tmp_path: Path) -> None:
    db_path = tmp_path / "huddle.sqlite"
    ensure_bootstrap(str(db_path))
    assert db_path.is_file()
    conn = sqlite3.connect(str(db_path))
    mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert mode.lower() == "wal"
    rows = conn.execute("SELECT version FROM schema_migrations").fetchall()
    assert rows == [(0,)]
    conn.close()


def test_each_node_id_in_health(tmp_path: Path) -> None:
    for node_id in (0, 1, 2):
        cfg = Settings(
            node_id=node_id,
            port=8000 + node_id,
            data_dir=str(tmp_path / f"n{node_id}"),
            redis_url="redis://127.0.0.1:6379/0",
        )
        client = TestClient(create_app(cfg))
        assert client.get("/api/health").json() == {"status": "ok", "node_id": node_id}
