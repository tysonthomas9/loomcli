"""Contract tests for workspace user groups (MARATHON-12)."""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from server.app import create_app
from server.db import (
    apply_migrations,
    connect_and_bootstrap,
    reverse_migration,
    utc_now_z,
)
from server.groups.store import GROUP_OBJ_KEYS
from server.settings import Settings

GROUP_KEYS = set(GROUP_OBJ_KEYS)


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


def _register(
    client: TestClient,
    username: str,
    password: str = "password1",
) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": password},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _create_ws(
    client: TestClient,
    token: str,
    slug: str = "acme",
    name: str = "Acme Corp",
) -> dict:
    resp = client.post(
        "/api/workspaces",
        headers=_auth(token),
        json={"slug": slug, "name": name},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["workspace"]


def _seed_member(
    tmp_path: Path,
    *,
    workspace_id: str,
    user_id: str,
    role: str,
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (workspace_id, user_id, role, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _setup(tmp_path: Path) -> dict:
    client = _client(tmp_path)
    owner = _register(client, "owner1")
    admin = _register(client, "admin1")
    member = _register(client, "member1")
    guest = _register(client, "guest1")
    stranger = _register(client, "stranger1")
    ws = _create_ws(client, owner["token"])
    _seed_member(
        tmp_path, workspace_id=ws["id"], user_id=admin["user"]["id"], role="admin"
    )
    _seed_member(
        tmp_path,
        workspace_id=ws["id"],
        user_id=member["user"]["id"],
        role="member",
    )
    _seed_member(
        tmp_path, workspace_id=ws["id"], user_id=guest["user"]["id"], role="guest"
    )
    return {
        "client": client,
        "owner": owner,
        "admin": admin,
        "member": member,
        "guest": guest,
        "stranger": stranger,
        "ws": ws,
    }


def test_group_crud_happy_and_ordering(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    member = ctx["member"]
    owner = ctx["owner"]

    created = client.post(
        "/api/workspaces/acme/groups",
        headers=_auth(member["token"]),
        json={
            "handle": "zeta",
            "name": "Zeta Team",
            "user_ids": [owner["user"]["id"], member["user"]["id"]],
            "extra": "ignored",
        },
    )
    assert created.status_code == 201, created.text
    group = created.json()["group"]
    assert set(group.keys()) == GROUP_KEYS
    assert group["handle"] == "zeta"
    assert group["name"] == "Zeta Team"
    assert group["member_user_ids"] == sorted(
        [owner["user"]["id"], member["user"]["id"]]
    )

    client.post(
        "/api/workspaces/acme/groups",
        headers=_auth(owner["token"]),
        json={"handle": "alpha", "name": "Alpha"},
    )
    listed = client.get(
        "/api/workspaces/acme/groups", headers=_auth(member["token"])
    )
    assert listed.status_code == 200
    handles = [g["handle"] for g in listed.json()["groups"]]
    assert handles == ["alpha", "zeta"]

    patched = client.patch(
        "/api/workspaces/acme/groups/zeta",
        headers=_auth(member["token"]),
        json={"name": "Zeta Renamed", "user_ids": [member["user"]["id"]]},
    )
    assert patched.status_code == 200, patched.text
    assert patched.json()["group"]["name"] == "Zeta Renamed"
    assert patched.json()["group"]["member_user_ids"] == [member["user"]["id"]]

    cleared = client.patch(
        "/api/workspaces/acme/groups/zeta",
        headers=_auth(owner["token"]),
        json={"user_ids": []},
    )
    assert cleared.status_code == 200
    assert cleared.json()["group"]["member_user_ids"] == []

    deleted = client.delete(
        "/api/workspaces/acme/groups/zeta",
        headers=_auth(owner["token"]),
    )
    assert deleted.status_code == 200
    assert deleted.json() == {"deleted": True}
    assert (
        client.get(
            "/api/workspaces/acme/groups", headers=_auth(owner["token"])
        ).json()["groups"][0]["handle"]
        == "alpha"
    )


def test_group_authz_matrix(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    member = ctx["member"]
    admin = ctx["admin"]
    guest = ctx["guest"]
    stranger = ctx["stranger"]
    owner = ctx["owner"]

    assert (
        client.post(
            "/api/workspaces/acme/groups",
            headers=_auth(guest["token"]),
            json={"handle": "g1", "name": "G"},
        ).status_code
        == 403
    )
    assert (
        client.post(
            "/api/workspaces/acme/groups",
            headers=_auth(stranger["token"]),
            json={"handle": "g1", "name": "G"},
        ).status_code
        == 404
    )
    assert (
        client.get(
            "/api/workspaces/acme/groups", headers=_auth(stranger["token"])
        ).status_code
        == 404
    )

    created = client.post(
        "/api/workspaces/acme/groups",
        headers=_auth(member["token"]),
        json={"handle": "eng", "name": "Eng"},
    )
    assert created.status_code == 201

    # Admin who is not creator cannot PATCH/DELETE.
    assert (
        client.patch(
            "/api/workspaces/acme/groups/eng",
            headers=_auth(admin["token"]),
            json={"name": "Nope"},
        ).status_code
        == 403
    )
    assert (
        client.delete(
            "/api/workspaces/acme/groups/eng",
            headers=_auth(admin["token"]),
        ).status_code
        == 403
    )

    # Owner can mutate any group.
    assert (
        client.patch(
            "/api/workspaces/acme/groups/eng",
            headers=_auth(owner["token"]),
            json={"name": "Eng 2"},
        ).status_code
        == 200
    )

    assert (
        client.patch(
            "/api/workspaces/acme/groups/missing",
            headers=_auth(owner["token"]),
            json={"name": "X"},
        ).status_code
        == 404
    )
    assert (
        client.delete(
            "/api/workspaces/acme/groups/missing",
            headers=_auth(owner["token"]),
        ).status_code
        == 404
    )


def test_group_validation_and_conflict(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    owner = ctx["owner"]
    stranger = ctx["stranger"]

    for bad in ("Eng", "e", "", "bad handle"):
        resp = client.post(
            "/api/workspaces/acme/groups",
            headers=_auth(owner["token"]),
            json={"handle": bad, "name": "Ok"},
        )
        assert resp.status_code == 400, bad
        assert resp.json()["error"]["code"] == "validation_error"

    assert (
        client.post(
            "/api/workspaces/acme/groups",
            headers=_auth(owner["token"]),
            json={"handle": "ok", "name": "   "},
        ).status_code
        == 400
    )
    assert (
        client.post(
            "/api/workspaces/acme/groups",
            headers=_auth(owner["token"]),
            json={"handle": "ok", "name": "x" * 81},
        ).status_code
        == 400
    )

    assert (
        client.post(
            "/api/workspaces/acme/groups",
            headers=_auth(owner["token"]),
            json={
                "handle": "ok",
                "name": "Ok",
                "user_ids": [stranger["user"]["id"]],
            },
        ).status_code
        == 400
    )
    assert (
        client.post(
            "/api/workspaces/acme/groups",
            headers=_auth(owner["token"]),
            json={
                "handle": "ok",
                "name": "Ok",
                "user_ids": [str(uuid.uuid4())],
            },
        ).status_code
        == 400
    )

    first = client.post(
        "/api/workspaces/acme/groups",
        headers=_auth(owner["token"]),
        json={"handle": "dup", "name": "One"},
    )
    assert first.status_code == 201
    second = client.post(
        "/api/workspaces/acme/groups",
        headers=_auth(owner["token"]),
        json={"handle": "dup", "name": "Two"},
    )
    assert second.status_code == 409
    assert second.json()["error"]["code"] == "conflict"

    assert (
        client.post(
            "/api/workspaces/acme/groups",
            json={"handle": "x", "name": "Y"},
        ).status_code
        == 401
    )


def test_migration_v4_apply_and_reverse(tmp_path: Path) -> None:
    db_path = str(tmp_path / "mig.sqlite")
    conn = connect_and_bootstrap(db_path)
    conn.execute(
        "INSERT INTO schema_migrations (version, applied_at) VALUES (0, ?)",
        (utc_now_z(),),
    )
    conn.commit()
    apply_migrations(conn)
    versions = {
        int(r[0])
        for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 4 in versions
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    assert "user_groups" in tables
    assert "user_group_members" in tables
    assert "workspace_invitations" in tables

    reverse_migration(conn, 4)
    versions = {
        int(r[0])
        for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 4 not in versions
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    assert "user_groups" not in tables
    assert "workspace_invitations" not in tables
    conn.close()
