"""Contract tests for Profiles API (GET /api/users/{id}, PATCH /api/users/me)."""

from __future__ import annotations

import uuid
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from fastapi.testclient import TestClient

from server.app import create_app
from server.auth.users import (
    AVATAR_URL_MAX,
    DISPLAY_NAME_MAX,
    STATUS_EMOJI_MAX,
    STATUS_TEXT_MAX,
    USER_OBJ_KEYS,
)
from server.settings import Settings

USER_KEYS = set(USER_OBJ_KEYS)


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


def _register(
    client: TestClient,
    username: str = "ada",
    password: str = "password1",
) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": password},
    )
    assert resp.status_code == 201
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def test_get_user_by_id_happy(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    user_id = reg["user"]["id"]
    resp = client.get(f"/api/users/{user_id}", headers=_auth(reg["token"]))
    assert resp.status_code == 200
    body = resp.json()
    assert set(body["user"].keys()) == USER_KEYS
    assert "email" not in body["user"]
    assert body["user"] == reg["user"]
    assert "password" not in resp.text.lower() or "password1" not in resp.text
    assert "password_hash" not in resp.text


def test_get_user_not_found(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    missing = str(uuid.uuid4())
    resp = client.get(f"/api/users/{missing}", headers=_auth(reg["token"]))
    assert resp.status_code == 404
    assert resp.json() == {
        "error": {"code": "not_found", "message": "user not found"}
    }


def test_get_path_me_is_not_special(tmp_path: Path) -> None:
    """GET /api/users/me looks up id 'me' → 404 (session self-read is /api/auth/me)."""
    client = _client(tmp_path)
    reg = _register(client)
    resp = client.get("/api/users/me", headers=_auth(reg["token"]))
    assert resp.status_code == 404
    assert resp.json()["error"]["code"] == "not_found"


@pytest.mark.parametrize(
    "method,path",
    [
        ("get", "/api/users/" + "a" * 36),
        ("patch", "/api/users/me"),
    ],
)
def test_unauthorized_without_bearer(tmp_path: Path, method: str, path: str) -> None:
    client = _client(tmp_path)
    if method == "patch":
        resp = client.patch(path, json={})
    else:
        resp = client.get(path)
    assert resp.status_code == 401
    assert resp.json()["error"]["code"] == "unauthorized"


def test_patch_display_name_and_timezone(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    resp = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={"display_name": "Ada", "timezone": "America/New_York"},
    )
    assert resp.status_code == 200
    user = resp.json()["user"]
    assert set(user.keys()) == USER_KEYS
    assert user["display_name"] == "Ada"
    assert user["timezone"] == "America/New_York"
    assert user["id"] == reg["user"]["id"]
    assert user["username"] == "ada"

    me = client.get("/api/auth/me", headers=_auth(reg["token"]))
    assert me.status_code == 200
    assert me.json()["user"] == user

    by_id = client.get(f"/api/users/{user['id']}", headers=_auth(reg["token"]))
    assert by_id.json()["user"] == user


def test_patch_invalid_timezone_leaves_db(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={"timezone": "UTC"},
    )
    bad = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={"timezone": "Not/AZone"},
    )
    assert bad.status_code == 400
    assert bad.json()["error"]["code"] == "validation_error"

    me = client.get("/api/auth/me", headers=_auth(reg["token"]))
    assert me.json()["user"]["timezone"] == "UTC"


@pytest.mark.parametrize(
    "field,value",
    [
        ("display_name", "x" * (DISPLAY_NAME_MAX + 1)),
        ("status_text", "x" * (STATUS_TEXT_MAX + 1)),
        ("status_emoji", "x" * (STATUS_EMOJI_MAX + 1)),
        ("avatar_url", "x" * (AVATAR_URL_MAX + 1)),
        ("timezone", "x" * 65),
    ],
)
def test_patch_over_max_length_400(tmp_path: Path, field: str, value: str) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    resp = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={field: value},
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "validation_error"
    me = client.get("/api/auth/me", headers=_auth(reg["token"]))
    assert me.json()["user"] == reg["user"]


def test_patch_null_clears_nullable_and_resets_display_name(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={
            "display_name": "Ada Lovelace",
            "timezone": "UTC",
            "avatar_url": "https://example.com/a.png",
            "status_text": "busy",
            "status_emoji": "🎧",
        },
    )
    resp = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={
            "display_name": None,
            "timezone": None,
            "avatar_url": "",
            "status_text": None,
            "status_emoji": "",
        },
    )
    assert resp.status_code == 200
    user = resp.json()["user"]
    assert user["display_name"] == "ada"
    assert user["timezone"] is None
    assert user["avatar_url"] is None
    assert user["status_text"] is None
    assert user["status_emoji"] is None


def test_patch_blank_display_name_resets_to_username(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={"display_name": "Ada"},
    )
    resp = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={"display_name": "   "},
    )
    assert resp.status_code == 200
    assert resp.json()["user"]["display_name"] == "ada"


def test_patch_empty_object_noop(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    spy = MagicMock()
    monkeypatch.setattr("server.users.routes.publish_user_updated", spy)
    resp = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={},
    )
    assert resp.status_code == 200
    assert resp.json()["user"] == reg["user"]
    spy.assert_not_called()


def test_patch_ignores_immutable_and_unknown_keys(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    spy = MagicMock()
    monkeypatch.setattr("server.users.routes.publish_user_updated", spy)
    other_id = str(uuid.uuid4())
    resp = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={
            "username": "hacker",
            "id": other_id,
            "password": "password1",
            "email": "x@y.z",
            "extra": {"nested": True},
        },
    )
    assert resp.status_code == 200
    user = resp.json()["user"]
    assert user["username"] == "ada"
    assert user["id"] == reg["user"]["id"]
    assert "email" not in user
    spy.assert_not_called()


def test_patch_mutating_calls_publish(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    spy = MagicMock()
    monkeypatch.setattr("server.users.routes.publish_user_updated", spy)
    resp = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={"status_text": "In a huddle"},
    )
    assert resp.status_code == 200
    spy.assert_called_once()
    published = spy.call_args[0][0]
    assert set(published.keys()) == USER_KEYS
    assert "channel_id" not in published
    assert "seq" not in published


def test_patch_wrong_json_type_400(tmp_path: Path) -> None:
    client = _client(tmp_path)
    reg = _register(client)
    resp = client.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={"timezone": 1},
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "validation_error"
    assert "detail" not in resp.json()


def test_cluster_patch_visible_on_other_node(tmp_path: Path) -> None:
    shared = tmp_path / "shared"
    client_a = _client(shared, node_id=0)
    client_b = _client(shared, node_id=2)
    reg = _register(client_a)
    patch = client_a.patch(
        "/api/users/me",
        headers=_auth(reg["token"]),
        json={"timezone": "Europe/London", "status_emoji": "🎧"},
    )
    assert patch.status_code == 200
    got = client_b.get(
        f"/api/users/{reg['user']['id']}",
        headers=_auth(reg["token"]),
    )
    assert got.status_code == 200
    assert got.json()["user"]["timezone"] == "Europe/London"
    assert got.json()["user"]["status_emoji"] == "🎧"


def test_health_still_unenveloped(tmp_path: Path) -> None:
    client = _client(tmp_path)
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json() == {"status": "ok", "node_id": 0}
    assert "error" not in health.json()


def test_publish_user_updated_payload_contract() -> None:
    """Hook documents channel-less user.updated; no-op must accept UserObj."""
    from server.events import publish_user_updated

    user = {
        "id": "u1",
        "username": "ada",
        "display_name": "Ada",
        "timezone": None,
        "avatar_url": None,
        "status_text": None,
        "status_emoji": None,
    }
    assert publish_user_updated(user) is None
