"""Live-cluster SIGKILL respawn checks for HTTP nodes and Redis.

Verifies MARATHON-2 / epic resilience: supervisor restores a killed HTTP node
within 60s with the same node_id, keeps the other two serving, respawns Redis
so PING works again, and does not require IRC :6667.
"""

from __future__ import annotations

import os
import signal
import socket
import subprocess
import time
from pathlib import Path

import httpx
import pytest

APP_ROOT = Path(__file__).resolve().parents[1]
START_SH = APP_ROOT / "start.sh"
PORTS = (8000, 8001, 8002)
REDIS_PORT = 6379
IRC_PORT = 6667
BOOT_TIMEOUT_S = 60.0
HTTP_RESPAWN_TIMEOUT_S = 60.0
REDIS_RESPAWN_TIMEOUT_S = 60.0
PEER_POLL_INTERVAL_S = 0.25


def _port_free(port: int, host: str = "127.0.0.1") -> bool:
    s = socket.socket()
    try:
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _wait_health(port: int, node_id: int, timeout: float = BOOT_TIMEOUT_S) -> dict:
    deadline = time.monotonic() + timeout
    url = f"http://127.0.0.1:{port}/api/health"
    last_err: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with httpx.Client(timeout=1.0) as client:
                r = client.get(url)
            if r.status_code == 200:
                body = r.json()
                if body == {"status": "ok", "node_id": node_id}:
                    return body
                last_err = AssertionError(f"unexpected health body on {port}: {body!r}")
        except Exception as exc:  # noqa: BLE001 — poll until ready
            last_err = exc
        time.sleep(0.2)
    raise TimeoutError(
        f"health on :{port} did not become {{status:ok,node_id:{node_id}}} "
        f"within {timeout}s; last={last_err!r}"
    )


def _health_ok(port: int, node_id: int) -> bool:
    try:
        with httpx.Client(timeout=1.0) as client:
            r = client.get(f"http://127.0.0.1:{port}/api/health")
        return r.status_code == 200 and r.json() == {"status": "ok", "node_id": node_id}
    except Exception:  # noqa: BLE001
        return False


def _redis_ping() -> bool:
    try:
        result = subprocess.run(
            ["redis-cli", "-h", "127.0.0.1", "-p", str(REDIS_PORT), "PING"],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
        return result.returncode == 0 and result.stdout.strip() == "PONG"
    except (subprocess.TimeoutExpired, OSError):
        return False


def _pids_listening_on(port: int) -> list[int]:
    """Return PIDs with a TCP listener on 127.0.0.1:port (via ss)."""
    result = subprocess.run(
        ["ss", "-tlnp", f"sport = :{port}"],
        capture_output=True,
        text=True,
        check=False,
        timeout=5,
    )
    pids: list[int] = []
    for line in result.stdout.splitlines():
        if f":{port}" not in line:
            continue
        # users:(("proc",pid=123,fd=4))
        marker = "pid="
        start = 0
        while True:
            idx = line.find(marker, start)
            if idx < 0:
                break
            idx += len(marker)
            end = idx
            while end < len(line) and line[end].isdigit():
                end += 1
            if end > idx:
                pids.append(int(line[idx:end]))
            start = end
    return sorted(set(pids))


def _sigkill_pids(pids: list[int]) -> None:
    for pid in pids:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


@pytest.fixture(scope="module")
def cluster() -> subprocess.Popen[bytes]:
    """Boot ./start.sh once for the module; tear down the whole tree after."""
    assert START_SH.is_file(), f"missing {START_SH}"
    assert os.access(START_SH, os.X_OK), f"{START_SH} is not executable"

    subprocess.run(["marathon-freeports"], check=False)

    for port in (*PORTS, REDIS_PORT):
        if not _port_free(port):
            pytest.fail(f"port {port} still busy before start.sh")

    log_path = APP_ROOT / "data" / "run" / "qa-cluster-respawn.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = open(log_path, "wb")  # noqa: SIM115 — closed in finally
    proc = subprocess.Popen(
        [str(START_SH)],
        cwd=str(APP_ROOT),
        stdout=log_f,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    try:
        for node_id, port in enumerate(PORTS):
            _wait_health(port, node_id)
        assert proc.poll() is None, "start.sh exited before health became ready"
        assert _redis_ping(), "redis PING failed after boot"
        yield proc
    finally:
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=5)
        log_f.close()
        subprocess.run(["marathon-freeports"], check=False)


def test_http_node_sigkill_respawns_same_node_id_within_60s(
    cluster: subprocess.Popen[bytes],
) -> None:
    """AC6: SIGKILL one node; same port returns same node_id within 60s."""
    assert cluster.poll() is None
    victim_node_id = 1
    victim_port = 8001
    before = _wait_health(victim_port, victim_node_id, timeout=5.0)
    assert before == {"status": "ok", "node_id": victim_node_id}

    pids = _pids_listening_on(victim_port)
    assert pids, f"no listener on :{victim_port} before SIGKILL"
    _sigkill_pids(pids)

    # Expect a brief outage, then recovery with identical contract payload.
    recovered = _wait_health(victim_port, victim_node_id, timeout=HTTP_RESPAWN_TIMEOUT_S)
    assert recovered == {"status": "ok", "node_id": victim_node_id}
    assert recovered["node_id"] == before["node_id"]
    assert cluster.poll() is None, "start.sh must keep running across HTTP respawn"


def test_peer_http_nodes_stay_healthy_while_one_is_sigkilled(
    cluster: subprocess.Popen[bytes],
) -> None:
    """AC6 / task neg: killing one HTTP node must not stop reads on the other two."""
    assert cluster.poll() is None
    victim_node_id = 0
    victim_port = 8000
    peers = [(1, 8001), (2, 8002)]

    for node_id, port in peers:
        assert _health_ok(port, node_id)

    pids = _pids_listening_on(victim_port)
    assert pids, f"no listener on :{victim_port} before SIGKILL"
    killed_at = time.monotonic()
    _sigkill_pids(pids)

    peer_failures: list[str] = []
    deadline = killed_at + HTTP_RESPAWN_TIMEOUT_S
    victim_back = False
    while time.monotonic() < deadline:
        for node_id, port in peers:
            if not _health_ok(port, node_id):
                peer_failures.append(
                    f"t+{time.monotonic() - killed_at:.2f}s peer :{port} node_id={node_id} unhealthy"
                )
        if _health_ok(victim_port, victim_node_id):
            victim_back = True
            # One more peer sample after victim recovery.
            for node_id, port in peers:
                if not _health_ok(port, node_id):
                    peer_failures.append(
                        f"after victim recovery peer :{port} node_id={node_id} unhealthy"
                    )
            break
        time.sleep(PEER_POLL_INTERVAL_S)

    assert victim_back, (
        f"victim :{victim_port} did not recover within {HTTP_RESPAWN_TIMEOUT_S}s"
    )
    assert not peer_failures, (
        "peer nodes must remain healthy throughout victim SIGKILL/respawn; "
        f"failures={peer_failures[:10]}"
    )
    assert cluster.poll() is None


def test_redis_sigkill_respawns_and_ping_succeeds(
    cluster: subprocess.Popen[bytes],
) -> None:
    """AC7: SIGKILL redis-server; without restarting start.sh, PING works again."""
    assert cluster.poll() is None
    assert _redis_ping()

    pids = _pids_listening_on(REDIS_PORT)
    assert pids, "no redis listener on :6379 before SIGKILL"
    _sigkill_pids(pids)

    # Confirm outage briefly observed (negative: PING must not stay up forever
    # on the killed process — allow a short race if respawn is very fast).
    saw_failure = False
    for _ in range(20):
        if not _redis_ping():
            saw_failure = True
            break
        time.sleep(0.05)

    deadline = time.monotonic() + REDIS_RESPAWN_TIMEOUT_S
    while time.monotonic() < deadline:
        if _redis_ping():
            assert cluster.poll() is None, "start.sh must keep running across Redis respawn"
            # HTTP nodes should still answer after Redis returns (scaffold scope).
            for node_id, port in enumerate(PORTS):
                assert _health_ok(port, node_id), f"node {node_id} unhealthy after redis respawn"
            return
        time.sleep(0.2)

    pytest.fail(
        f"redis PING did not succeed within {REDIS_RESPAWN_TIMEOUT_S}s after SIGKILL "
        f"(saw_transient_failure={saw_failure})"
    )


def test_irc_port_not_required_for_respawn_integration(
    cluster: subprocess.Popen[bytes],
) -> None:
    """Task/AC10: IRC :6667 is out of scope; must stay unbound during this integration."""
    del cluster
    assert _port_free(IRC_PORT), "port 6667 must remain free (IRC not yet in scope)"
    # Cluster remains operable without anything on 6667.
    for node_id, port in enumerate(PORTS):
        assert _health_ok(port, node_id)
    assert _redis_ping()
