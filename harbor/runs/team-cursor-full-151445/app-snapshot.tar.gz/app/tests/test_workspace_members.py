"""Contract tests for workspace members, roles, and ownership transfer."""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from server.app import create_app
from server.db import utc_now_z
from server.settings import Settings
from server.workspaces.store import MEMBER_OBJ_KEYS, WORKSPACE_OBJ_KEYS

WS_KEYS = set(WORKSPACE_OBJ_KEYS)
MEMBER_KEYS = set(MEMBER_OBJ_KEYS)


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


def _register(
    client: TestClient,
    username: str,
    password: str = "password1",
) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": password},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _create_ws(
    client: TestClient,
    token: str,
    slug: str = "acme",
    name: str = "Acme Corp",
) -> dict:
    resp = client.post(
        "/api/workspaces",
        headers=_auth(token),
        json={"slug": slug, "name": name},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["workspace"]


def _seed_member(
    tmp_path: Path,
    *,
    workspace_id: str,
    user_id: str,
    role: str,
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (workspace_id, user_id, role, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _setup_roles(tmp_path: Path) -> dict:
    """Owner + admin + member + guest (+ stranger). Returns tokens/ids/ws."""
    client = _client(tmp_path)
    owner = _register(client, "owner1")
    admin = _register(client, "admin1")
    member = _register(client, "member1")
    guest = _register(client, "guest1")
    stranger = _register(client, "stranger1")
    ws = _create_ws(client, owner["token"])
    _seed_member(
        tmp_path, workspace_id=ws["id"], user_id=admin["user"]["id"], role="admin"
    )
    _seed_member(
        tmp_path,
        workspace_id=ws["id"],
        user_id=member["user"]["id"],
        role="member",
    )
    _seed_member(
        tmp_path, workspace_id=ws["id"], user_id=guest["user"]["id"], role="guest"
    )
    return {
        "client": client,
        "owner": owner,
        "admin": admin,
        "member": member,
        "guest": guest,
        "stranger": stranger,
        "ws": ws,
    }


# --- GET /members ---


def test_list_members_shape_and_ordering(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    # Extra admin with username that sorts before admin1 (case-insensitive).
    early = _register(client, "aad_admin")
    _seed_member(
        tmp_path,
        workspace_id=ctx["ws"]["id"],
        user_id=early["user"]["id"],
        role="admin",
    )

    resp = client.get(
        "/api/workspaces/acme/members",
        headers=_auth(ctx["member"]["token"]),
    )
    assert resp.status_code == 200
    body = resp.json()
    assert set(body.keys()) == {"members"}
    members = body["members"]
    assert len(members) == 5
    for m in members:
        assert set(m.keys()) == MEMBER_KEYS
    roles = [m["role"] for m in members]
    assert roles == ["owner", "admin", "admin", "member", "guest"]
    admins = [m for m in members if m["role"] == "admin"]
    assert [m["username"] for m in admins] == ["aad_admin", "admin1"]
    assert members[0]["user_id"] == ctx["owner"]["user"]["id"]
    assert "email" not in resp.text.lower()
    assert "password" not in resp.text.lower()


def test_list_members_guest_ok(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].get(
        "/api/workspaces/acme/members",
        headers=_auth(ctx["guest"]["token"]),
    )
    assert resp.status_code == 200
    assert len(resp.json()["members"]) == 4


def test_list_members_non_member_404(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].get(
        "/api/workspaces/acme/members",
        headers=_auth(ctx["stranger"]["token"]),
    )
    assert resp.status_code == 404
    assert resp.json()["error"]["code"] == "not_found"


def test_list_members_unknown_slug_404(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].get(
        "/api/workspaces/nope/members",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert resp.status_code == 404


def test_list_members_unauth_401(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].get("/api/workspaces/acme/members")
    assert resp.status_code == 401
    assert resp.json()["error"]["code"] == "unauthorized"


# --- PATCH workspace ---


def test_patch_workspace_owner_and_admin(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]

    resp = client.patch(
        "/api/workspaces/acme",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "Acme Renamed", "extra": True},
    )
    assert resp.status_code == 200
    ws = resp.json()["workspace"]
    assert set(ws.keys()) == WS_KEYS
    assert ws["name"] == "Acme Renamed"
    assert ws["join_mode"] == "open"

    resp = client.patch(
        "/api/workspaces/acme",
        headers=_auth(ctx["admin"]["token"]),
        json={"join_mode": "invite_only"},
    )
    assert resp.status_code == 200
    assert resp.json()["workspace"]["join_mode"] == "invite_only"
    assert resp.json()["workspace"]["name"] == "Acme Renamed"


def test_patch_workspace_empty_noop(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    before = ctx["ws"]
    resp = ctx["client"].patch(
        "/api/workspaces/acme",
        headers=_auth(ctx["owner"]["token"]),
        json={},
    )
    assert resp.status_code == 200
    assert resp.json()["workspace"] == before


def test_patch_workspace_member_guest_403(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    for token in (ctx["member"]["token"], ctx["guest"]["token"]):
        resp = ctx["client"].patch(
            "/api/workspaces/acme",
            headers=_auth(token),
            json={"name": "Nope"},
        )
        assert resp.status_code == 403
        assert resp.json()["error"]["code"] == "forbidden"


def test_patch_workspace_stranger_404(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].patch(
        "/api/workspaces/acme",
        headers=_auth(ctx["stranger"]["token"]),
        json={"name": "Nope"},
    )
    assert resp.status_code == 404


def test_patch_workspace_validation_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    headers = _auth(ctx["owner"]["token"])

    resp = client.patch(
        "/api/workspaces/acme", headers=headers, json={"name": "  "}
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "validation_error"

    resp = client.patch(
        "/api/workspaces/acme",
        headers=headers,
        json={"join_mode": "closed"},
    )
    assert resp.status_code == 400

    resp = client.patch(
        "/api/workspaces/acme", headers=headers, json={"name": None}
    )
    assert resp.status_code == 400

    resp = client.patch(
        "/api/workspaces/acme",
        headers=headers,
        json={"join_mode": None},
    )
    assert resp.status_code == 400


def test_patch_workspace_unauth_401(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].patch("/api/workspaces/acme", json={"name": "X"})
    assert resp.status_code == 401


# --- PATCH members/{user_id} ---


def test_patch_role_owner_and_admin_happy(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    member_id = ctx["member"]["user"]["id"]
    admin_id = ctx["admin"]["user"]["id"]

    # Admin promotes member → admin
    resp = client.patch(
        f"/api/workspaces/acme/members/{member_id}",
        headers=_auth(ctx["admin"]["token"]),
        json={"role": "admin", "x": 1},
    )
    assert resp.status_code == 200
    m = resp.json()["member"]
    assert set(m.keys()) == MEMBER_KEYS
    assert m["role"] == "admin"
    assert m["user_id"] == member_id

    # Owner demotes that admin back to member
    resp = client.patch(
        f"/api/workspaces/acme/members/{member_id}",
        headers=_auth(ctx["owner"]["token"]),
        json={"role": "member"},
    )
    assert resp.status_code == 200
    assert resp.json()["member"]["role"] == "member"

    # Owner demotes original admin to member
    resp = client.patch(
        f"/api/workspaces/acme/members/{admin_id}",
        headers=_auth(ctx["owner"]["token"]),
        json={"role": "member"},
    )
    assert resp.status_code == 200
    assert resp.json()["member"]["role"] == "member"


def test_patch_role_idempotent(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    member_id = ctx["member"]["user"]["id"]
    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{member_id}",
        headers=_auth(ctx["admin"]["token"]),
        json={"role": "member"},
    )
    assert resp.status_code == 200
    assert resp.json()["member"]["role"] == "member"


def test_patch_role_owner_value_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    member_id = ctx["member"]["user"]["id"]
    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{member_id}",
        headers=_auth(ctx["owner"]["token"]),
        json={"role": "owner"},
    )
    assert resp.status_code == 400
    err = resp.json()["error"]
    assert err["code"] == "validation_error"
    assert "transfer_ownership" in err["message"]


def test_patch_role_target_owner_403(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    owner_id = ctx["owner"]["user"]["id"]
    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{owner_id}",
        headers=_auth(ctx["admin"]["token"]),
        json={"role": "member"},
    )
    assert resp.status_code == 403
    assert resp.json()["error"]["code"] == "forbidden"

    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{owner_id}",
        headers=_auth(ctx["owner"]["token"]),
        json={"role": "admin"},
    )
    assert resp.status_code == 403


def test_patch_role_admin_cannot_touch_admin(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    other_admin = _register(client, "admin2")
    _seed_member(
        tmp_path,
        workspace_id=ctx["ws"]["id"],
        user_id=other_admin["user"]["id"],
        role="admin",
    )
    resp = client.patch(
        f"/api/workspaces/acme/members/{other_admin['user']['id']}",
        headers=_auth(ctx["admin"]["token"]),
        json={"role": "member"},
    )
    assert resp.status_code == 403

    # Admin cannot change self
    resp = client.patch(
        f"/api/workspaces/acme/members/{ctx['admin']['user']['id']}",
        headers=_auth(ctx["admin"]["token"]),
        json={"role": "member"},
    )
    assert resp.status_code == 403


def test_patch_role_member_guest_403(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    target = ctx["guest"]["user"]["id"]
    for token in (ctx["member"]["token"], ctx["guest"]["token"]):
        resp = ctx["client"].patch(
            f"/api/workspaces/acme/members/{target}",
            headers=_auth(token),
            json={"role": "member"},
        )
        assert resp.status_code == 403


def test_patch_role_unknown_member_404(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    missing = str(uuid.uuid4())
    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{missing}",
        headers=_auth(ctx["owner"]["token"]),
        json={"role": "member"},
    )
    assert resp.status_code == 404
    assert resp.json()["error"]["message"] == "member not found"


def test_patch_role_invalid_and_missing_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    member_id = ctx["member"]["user"]["id"]
    headers = _auth(ctx["owner"]["token"])

    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{member_id}",
        headers=headers,
        json={"role": "superuser"},
    )
    assert resp.status_code == 400

    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{member_id}",
        headers=headers,
        json={},
    )
    assert resp.status_code == 400


def test_patch_role_stranger_404(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{ctx['member']['user']['id']}",
        headers=_auth(ctx["stranger"]["token"]),
        json={"role": "guest"},
    )
    assert resp.status_code == 404


def test_patch_role_unauth_401(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].patch(
        f"/api/workspaces/acme/members/{ctx['member']['user']['id']}",
        json={"role": "guest"},
    )
    assert resp.status_code == 401


# --- transfer_ownership ---


def test_transfer_ownership_happy_path(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    owner_id = ctx["owner"]["user"]["id"]
    admin_id = ctx["admin"]["user"]["id"]

    resp = client.post(
        "/api/workspaces/acme/transfer_ownership",
        headers=_auth(ctx["owner"]["token"]),
        json={"new_owner_id": admin_id, "x": 1},
    )
    assert resp.status_code == 200
    ws = resp.json()["workspace"]
    assert set(ws.keys()) == WS_KEYS
    assert ws["owner_id"] == admin_id

    detail = client.get(
        "/api/workspaces/acme",
        headers=_auth(ctx["admin"]["token"]),
    )
    assert detail.status_code == 200
    assert detail.json()["workspace"]["owner_id"] == admin_id

    members = client.get(
        "/api/workspaces/acme/members",
        headers=_auth(ctx["admin"]["token"]),
    ).json()["members"]
    by_id = {m["user_id"]: m["role"] for m in members}
    assert by_id[admin_id] == "owner"
    assert by_id[owner_id] == "admin"

    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        row = conn.execute(
            "SELECT owner_id FROM workspaces WHERE id = ?", (ctx["ws"]["id"],)
        ).fetchone()
        assert row[0] == admin_id
        roles = dict(
            conn.execute(
                "SELECT user_id, role FROM workspace_members WHERE workspace_id = ?",
                (ctx["ws"]["id"],),
            ).fetchall()
        )
        assert roles[admin_id] == "owner"
        assert roles[owner_id] == "admin"
        owners = [u for u, r in roles.items() if r == "owner"]
        assert owners == [admin_id]
    finally:
        conn.close()

    # Previous owner (now admin) can still PATCH workspace but cannot transfer
    resp = client.patch(
        "/api/workspaces/acme",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "Still Admin"},
    )
    assert resp.status_code == 200

    resp = client.post(
        "/api/workspaces/acme/transfer_ownership",
        headers=_auth(ctx["owner"]["token"]),
        json={"new_owner_id": ctx["member"]["user"]["id"]},
    )
    assert resp.status_code == 403


def test_transfer_to_member_or_guest_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    headers = _auth(ctx["owner"]["token"])
    for uid in (ctx["member"]["user"]["id"], ctx["guest"]["user"]["id"]):
        resp = ctx["client"].post(
            "/api/workspaces/acme/transfer_ownership",
            headers=headers,
            json={"new_owner_id": uid},
        )
        assert resp.status_code == 400
        assert "admin" in resp.json()["error"]["message"]


def test_transfer_to_non_member_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].post(
        "/api/workspaces/acme/transfer_ownership",
        headers=_auth(ctx["owner"]["token"]),
        json={"new_owner_id": ctx["stranger"]["user"]["id"]},
    )
    assert resp.status_code == 400


def test_transfer_to_self_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].post(
        "/api/workspaces/acme/transfer_ownership",
        headers=_auth(ctx["owner"]["token"]),
        json={"new_owner_id": ctx["owner"]["user"]["id"]},
    )
    assert resp.status_code == 400


def test_transfer_admin_actor_403(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    # Need a second admin as target
    other = _register(ctx["client"], "admin2")
    _seed_member(
        tmp_path,
        workspace_id=ctx["ws"]["id"],
        user_id=other["user"]["id"],
        role="admin",
    )
    resp = ctx["client"].post(
        "/api/workspaces/acme/transfer_ownership",
        headers=_auth(ctx["admin"]["token"]),
        json={"new_owner_id": other["user"]["id"]},
    )
    assert resp.status_code == 403


def test_transfer_stranger_404(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].post(
        "/api/workspaces/acme/transfer_ownership",
        headers=_auth(ctx["stranger"]["token"]),
        json={"new_owner_id": ctx["admin"]["user"]["id"]},
    )
    assert resp.status_code == 404


def test_transfer_missing_body_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].post(
        "/api/workspaces/acme/transfer_ownership",
        headers=_auth(ctx["owner"]["token"]),
        json={},
    )
    assert resp.status_code == 400


def test_transfer_unauth_401(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    resp = ctx["client"].post(
        "/api/workspaces/acme/transfer_ownership",
        json={"new_owner_id": ctx["admin"]["user"]["id"]},
    )
    assert resp.status_code == 401


def test_transfer_visible_across_shared_db_nodes(tmp_path: Path) -> None:
    """Mutate on node 0; observe on node 1 (shared data_dir)."""
    client_a = _client(tmp_path, node_id=0)
    client_b = _client(tmp_path, node_id=1)
    owner = _register(client_a, "ownerx")
    admin = _register(client_a, "adminx")
    ws = _create_ws(client_a, owner["token"], slug="shared")
    _seed_member(
        tmp_path, workspace_id=ws["id"], user_id=admin["user"]["id"], role="admin"
    )

    resp = client_a.post(
        "/api/workspaces/shared/transfer_ownership",
        headers=_auth(owner["token"]),
        json={"new_owner_id": admin["user"]["id"]},
    )
    assert resp.status_code == 200

    detail = client_b.get(
        "/api/workspaces/shared",
        headers=_auth(admin["token"]),
    )
    assert detail.status_code == 200
    assert detail.json()["workspace"]["owner_id"] == admin["user"]["id"]

    members = client_b.get(
        "/api/workspaces/shared/members",
        headers=_auth(admin["token"]),
    ).json()["members"]
    by_id = {m["user_id"]: m["role"] for m in members}
    assert by_id[admin["user"]["id"]] == "owner"
    assert by_id[owner["user"]["id"]] == "admin"
