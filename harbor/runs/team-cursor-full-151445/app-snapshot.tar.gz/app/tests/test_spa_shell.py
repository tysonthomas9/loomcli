"""SPA shell: GET / HTML + static assets + required data-testid selectors."""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from server.app import create_app
from server.settings import Settings

REQUIRED_TESTIDS = (
    "auth-modal",
    "auth-form",
    "auth-submit",
    "auth-toggle",
    "auth-error",
    "auth-username",
    "auth-password",
    "auth-display-name",
    "workspace-create-form",
    "empty-state-create-workspace",
    "join-workspace-form",
    "join-workspace-slug",
    "join-workspace-submit",
    "join-workspace-error",
    "current-user",
    "logout-btn",
    "workspace-header",
    "channel-list",
    "dms-list",
    "message-pane",
    "thread-panel",
    "workspace-slug",
    "workspace-name",
    "workspace-create-submit",
    "workspace-create-error",
    "workspace-settings-modal",
    "channel-settings-modal",
    "create-invitation-form",
    "settings-tab-general",
    "settings-tab-members",
    "settings-tab-invitations",
    "invitation-accept-form",
    "invitation-accept-code",
    "invitation-accept-submit",
    "invitation-accept-error",
)

STATIC_ASSETS = (
    "/static/css/app.css",
    "/static/js/app.js",
    "/static/js/api.js",
    "/static/js/storage.js",
    "/static/js/auth_ui.js",
    "/static/js/shell.js",
    "/static/js/settings_ui.js",
)


@pytest.fixture()
def client(tmp_path: Path) -> TestClient:
    cfg = Settings(
        node_id=0,
        port=8000,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )
    return TestClient(create_app(cfg))


def test_root_serves_spa_html(client: TestClient) -> None:
    root = client.get("/")
    assert root.status_code == 200
    assert "text/html" in root.headers["content-type"]
    assert "Huddle" in root.text
    assert "Cluster node stub" not in root.text
    assert 'src="/static/js/app.js"' in root.text
    assert 'href="/static/css/app.css"' in root.text
    for testid in REQUIRED_TESTIDS:
        assert f'data-testid="{testid}"' in root.text, testid


def test_static_assets_ok(client: TestClient) -> None:
    for path in STATIC_ASSETS:
        resp = client.get(path)
        assert resp.status_code == 200, path


def test_storage_contract_documented_in_js(client: TestClient) -> None:
    js = client.get("/static/js/storage.js")
    assert js.status_code == 200
    body = js.text
    assert "huddle.token" in body
    assert "huddle_token" in body
    assert "huddle.workspaceSlug" in body


def test_api_client_sends_bearer(client: TestClient) -> None:
    js = client.get("/static/js/api.js")
    assert js.status_code == 200
    assert "Authorization" in js.text
    assert "Bearer" in js.text


def test_health_still_json(client: TestClient) -> None:
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"


def test_register_login_still_work_alongside_spa(client: TestClient) -> None:
    reg = client.post(
        "/api/auth/register",
        json={"username": "spa_user", "password": "password1"},
    )
    assert reg.status_code == 201
    token = reg.json()["token"]
    assert len(token) >= 16
    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200
    assert me.json()["user"]["username"] == "spa_user"

    ws = client.post(
        "/api/workspaces",
        headers={"Authorization": f"Bearer {token}"},
        json={"slug": "acme", "name": "Acme"},
    )
    assert ws.status_code == 201
    detail = client.get(
        "/api/workspaces/acme",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert detail.status_code == 200
    channels = detail.json()["channels"]
    assert any(c["name"] == "general" and not c["is_dm"] for c in channels)
