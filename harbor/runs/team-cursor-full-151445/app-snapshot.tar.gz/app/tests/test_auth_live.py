"""Live-cluster Auth contract checks via ./start.sh (MARATHON-21).

Verifies register / login / me envelopes on fixed ports against a real
supervisor process tree — not TestClient.
"""

from __future__ import annotations

import os
import signal
import socket
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any

import httpx
import pytest

APP_ROOT = Path(__file__).resolve().parents[1]
START_SH = APP_ROOT / "start.sh"
PORTS = (8000, 8001, 8002)
REDIS_PORT = 6379
BOOT_TIMEOUT_S = 60.0

USER_OBJ_KEYS = {
    "id",
    "username",
    "display_name",
    "timezone",
    "avatar_url",
    "status_text",
    "status_emoji",
}


def _port_free(port: int, host: str = "127.0.0.1") -> bool:
    s = socket.socket()
    try:
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _wait_health(port: int, node_id: int, timeout: float = BOOT_TIMEOUT_S) -> dict:
    deadline = time.monotonic() + timeout
    url = f"http://127.0.0.1:{port}/api/health"
    last_err: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with httpx.Client(timeout=1.0) as client:
                r = client.get(url)
            if r.status_code == 200:
                body = r.json()
                if body == {"status": "ok", "node_id": node_id}:
                    return body
                last_err = AssertionError(f"unexpected health body on {port}: {body!r}")
        except Exception as exc:  # noqa: BLE001 — poll until ready
            last_err = exc
        time.sleep(0.2)
    raise TimeoutError(
        f"health on :{port} did not become {{status:ok,node_id:{node_id}}} "
        f"within {timeout}s; last={last_err!r}"
    )


def _uniq(prefix: str = "qa") -> str:
    return f"{prefix}{uuid.uuid4().hex[:10]}"


def _assert_user_obj(user: dict[str, Any], *, username: str) -> None:
    assert set(user.keys()) == USER_OBJ_KEYS
    assert "email" not in user
    assert isinstance(user["id"], str) and len(user["id"]) > 0
    assert user["username"] == username
    assert isinstance(user["display_name"], str)
    assert user["timezone"] is None
    assert user["avatar_url"] is None
    assert user["status_text"] is None
    assert user["status_emoji"] is None


def _assert_error_envelope(body: dict[str, Any], *, code: str) -> None:
    assert set(body.keys()) == {"error"}
    assert set(body["error"].keys()) == {"code", "message"}
    assert body["error"]["code"] == code
    assert isinstance(body["error"]["message"], str)
    assert len(body["error"]["message"]) > 0
    assert "detail" not in body


@pytest.fixture(scope="module")
def cluster() -> subprocess.Popen[bytes]:
    """Boot ./start.sh once for the module; tear down the whole tree after."""
    assert START_SH.is_file(), f"missing {START_SH}"
    assert os.access(START_SH, os.X_OK), f"{START_SH} is not executable"

    subprocess.run(["marathon-freeports"], check=False)

    for port in (*PORTS, REDIS_PORT):
        if not _port_free(port):
            pytest.fail(f"port {port} still busy before start.sh")

    log_path = APP_ROOT / "data" / "run" / "qa-auth-live.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = open(log_path, "wb")  # noqa: SIM115 — closed in finally
    proc = subprocess.Popen(
        [str(START_SH)],
        cwd=str(APP_ROOT),
        stdout=log_f,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    try:
        for node_id, port in enumerate(PORTS):
            _wait_health(port, node_id)
        assert proc.poll() is None, "start.sh exited before health became ready"
        yield proc
    finally:
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=5)
        log_f.close()
        subprocess.run(["marathon-freeports"], check=False)


def test_register_valid_returns_201_user_token(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    username = _uniq("reg")
    with httpx.Client(timeout=5.0) as client:
        r = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": username, "password": "password1"},
        )
    assert r.status_code == 201
    body = r.json()
    assert set(body.keys()) == {"user", "token"}
    assert isinstance(body["token"], str) and len(body["token"]) >= 16
    _assert_user_obj(body["user"], username=username)
    assert "email" not in r.text
    assert "password1" not in r.text


def test_register_duplicate_username_409(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    username = _uniq("dup")
    with httpx.Client(timeout=5.0) as client:
        first = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": username, "password": "password1"},
        )
        assert first.status_code == 201
        second = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": username, "password": "password2"},
        )
    assert second.status_code == 409
    _assert_error_envelope(second.json(), code="conflict")


def test_register_username_with_space_400(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": "has space", "password": "password1"},
        )
    assert r.status_code == 400
    _assert_error_envelope(r.json(), code="validation_error")


def test_register_password_too_short_400(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": _uniq("pw"), "password": "short7x"},
        )
    assert r.status_code == 400
    _assert_error_envelope(r.json(), code="validation_error")


def test_login_correct_returns_200_user_token(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    username = _uniq("log")
    with httpx.Client(timeout=5.0) as client:
        reg = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": username, "password": "password1"},
        )
        assert reg.status_code == 201
        login = client.post(
            "http://127.0.0.1:8000/api/auth/login",
            json={"username": username, "password": "password1"},
        )
    assert login.status_code == 200
    body = login.json()
    assert set(body.keys()) == {"user", "token"}
    assert isinstance(body["token"], str) and len(body["token"]) >= 16
    assert body["token"] != reg.json()["token"]
    _assert_user_obj(body["user"], username=username)


def test_login_wrong_password_401_not_404(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    username = _uniq("bad")
    with httpx.Client(timeout=5.0) as client:
        assert (
            client.post(
                "http://127.0.0.1:8000/api/auth/register",
                json={"username": username, "password": "password1"},
            ).status_code
            == 201
        )
        r = client.post(
            "http://127.0.0.1:8000/api/auth/login",
            json={"username": username, "password": "wrongpass"},
        )
    assert r.status_code == 401
    assert r.status_code != 404
    _assert_error_envelope(r.json(), code="unauthorized")


def test_me_with_bearer_200(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    username = _uniq("me")
    with httpx.Client(timeout=5.0) as client:
        reg = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": username, "password": "password1"},
        )
        assert reg.status_code == 201
        token = reg.json()["token"]
        me = client.get(
            "http://127.0.0.1:8000/api/auth/me",
            headers={"Authorization": f"Bearer {token}"},
        )
    assert me.status_code == 200
    body = me.json()
    assert set(body.keys()) == {"user"}
    assert body["user"] == reg.json()["user"]
    _assert_user_obj(body["user"], username=username)


def test_me_missing_token_401(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.get("http://127.0.0.1:8000/api/auth/me")
    assert r.status_code == 401
    _assert_error_envelope(r.json(), code="unauthorized")


def test_me_invalid_token_401(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.get(
            "http://127.0.0.1:8000/api/auth/me",
            headers={"Authorization": "Bearer definitely-not-a-real-token"},
        )
    assert r.status_code == 401
    _assert_error_envelope(r.json(), code="unauthorized")


def test_token_from_8000_accepted_on_8001_and_8002(
    cluster: subprocess.Popen[bytes],
) -> None:
    """Design AC8: shared SQLite — token minted on :8000 works on peers."""
    del cluster
    username = _uniq("xnode")
    with httpx.Client(timeout=5.0) as client:
        reg = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": username, "password": "password1"},
        )
        assert reg.status_code == 201
        token = reg.json()["token"]
        for port in (8001, 8002):
            me = client.get(
                f"http://127.0.0.1:{port}/api/auth/me",
                headers={"Authorization": f"Bearer {token}"},
            )
            assert me.status_code == 200, f"port {port}"
            assert me.json()["user"]["username"] == username
            assert "email" not in me.json()["user"]
