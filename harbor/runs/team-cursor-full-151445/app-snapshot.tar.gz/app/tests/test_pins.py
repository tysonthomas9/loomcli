"""Contract tests for message pins (SQL-seeded messages)."""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from server.app import create_app
from server.auth.users import USER_OBJ_KEYS
from server.db import utc_now_z
from server.messages.store import MESSAGE_OBJ_KEYS
from server.settings import Settings

USER_KEYS = set(USER_OBJ_KEYS)
MSG_KEYS = set(MESSAGE_OBJ_KEYS)
PIN_KEYS = {"message_id", "pinned_by", "pinned_at"}
PIN_LIST_KEYS = {"message", "pinned_by", "pinned_at"}


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


def _register(client: TestClient, username: str) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": "password1"},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _create_ws(client: TestClient, token: str, slug: str = "acme") -> dict:
    resp = client.post(
        "/api/workspaces",
        headers=_auth(token),
        json={"slug": slug, "name": "Acme"},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["workspace"]


def _seed_message(
    tmp_path: Path,
    *,
    channel_id: str,
    author_id: str,
    body: str = "hello",
    message_id: str | None = None,
    created_at: str | None = None,
) -> str:
    mid = message_id or str(uuid.uuid4())
    now = created_at or utc_now_z()
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO messages (
                id, channel_id, author_id, body, parent_id,
                created_at, edited_at, deleted_at
            ) VALUES (?, ?, ?, ?, NULL, ?, NULL, NULL)
            """,
            (mid, channel_id, author_id, body, now),
        )
        conn.commit()
    finally:
        conn.close()
    return mid


def _seed_ws_member(
    tmp_path: Path, *, workspace_id: str, user_id: str, role: str = "member"
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (workspace_id, user_id, role, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _setup(tmp_path: Path) -> dict:
    client = _client(tmp_path)
    owner = _register(client, "owner1")
    member = _register(client, "member1")
    stranger = _register(client, "stranger1")
    ws = _create_ws(client, owner["token"])
    _seed_ws_member(
        tmp_path, workspace_id=ws["id"], user_id=member["user"]["id"]
    )
    created = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(owner["token"]),
        json={"name": "eng"},
    )
    assert created.status_code == 201
    channel = created.json()["channel"]
    client.post(
        f"/api/channels/{channel['id']}/join",
        headers=_auth(member["token"]),
    )
    return {
        "client": client,
        "owner": owner,
        "member": member,
        "stranger": stranger,
        "ws": ws,
        "channel": channel,
    }


def test_pin_unpin_list_idempotent(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    channel_id = ctx["channel"]["id"]
    mid1 = _seed_message(
        tmp_path,
        channel_id=channel_id,
        author_id=ctx["owner"]["user"]["id"],
        body="first",
        created_at="2026-08-22T10:00:00Z",
    )
    mid2 = _seed_message(
        tmp_path,
        channel_id=channel_id,
        author_id=ctx["member"]["user"]["id"],
        body="second",
        created_at="2026-08-22T11:00:00Z",
    )

    pin1 = client.post(
        f"/api/messages/{mid1}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert pin1.status_code == 200, pin1.text
    pin_obj = pin1.json()["pin"]
    assert set(pin_obj.keys()) == PIN_KEYS
    assert pin_obj["message_id"] == mid1
    assert pin_obj["pinned_by"] == ctx["member"]["user"]["id"]
    first_at = pin_obj["pinned_at"]

    pin1b = client.post(
        f"/api/messages/{mid1}/pin",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert pin1b.status_code == 200
    assert pin1b.json()["pin"]["pinned_by"] == ctx["member"]["user"]["id"]
    assert pin1b.json()["pin"]["pinned_at"] == first_at

    # Force older pinned_at so newest-first ordering is deterministic at second resolution.
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            "UPDATE channel_pins SET pinned_at = ? WHERE message_id = ?",
            ("2026-08-22T09:00:00Z", mid1),
        )
        conn.commit()
    finally:
        conn.close()

    pin2 = client.post(
        f"/api/messages/{mid2}/pin",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert pin2.status_code == 200

    listed = client.get(
        f"/api/channels/{channel_id}/pins",
        headers=_auth(ctx["member"]["token"]),
    )
    assert listed.status_code == 200
    pins = listed.json()["pins"]
    assert len(pins) == 2
    assert [p["message"]["id"] for p in pins] == [mid2, mid1]
    for p in pins:
        assert set(p.keys()) == PIN_LIST_KEYS
        assert set(p["message"].keys()) == MSG_KEYS
        assert set(p["message"]["author"].keys()) == USER_KEYS
        assert p["message"]["files"] == []
        assert p["message"]["reactions"] == []
        assert p["message"]["mentions"] == []
        assert p["message"]["reply_count"] == 0

    other = _client(tmp_path, node_id=1)
    remote = other.get(
        f"/api/channels/{channel_id}/pins",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert remote.status_code == 200
    assert len(remote.json()["pins"]) == 2

    unpinned = client.delete(
        f"/api/messages/{mid1}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert unpinned.status_code == 200
    assert unpinned.json() == {"unpinned": True}
    again = client.delete(
        f"/api/messages/{mid1}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert again.status_code == 200
    assert again.json() == {"unpinned": True}

    listed2 = client.get(
        f"/api/channels/{channel_id}/pins",
        headers=_auth(ctx["member"]["token"]),
    )
    assert [p["message"]["id"] for p in listed2.json()["pins"]] == [mid2]


def test_pin_private_and_membership_gates(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    priv = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "vault", "is_private": True},
    )
    assert priv.status_code == 201
    priv_id = priv.json()["channel"]["id"]
    mid = _seed_message(
        tmp_path,
        channel_id=priv_id,
        author_id=ctx["owner"]["user"]["id"],
    )

    denied_list = client.get(
        f"/api/channels/{priv_id}/pins",
        headers=_auth(ctx["member"]["token"]),
    )
    assert denied_list.status_code == 403

    denied_pin = client.post(
        f"/api/messages/{mid}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert denied_pin.status_code == 403

    client.post(
        f"/api/channels/{ctx['channel']['id']}/leave",
        headers=_auth(ctx["member"]["token"]),
    )
    pub_mid = _seed_message(
        tmp_path,
        channel_id=ctx["channel"]["id"],
        author_id=ctx["owner"]["user"]["id"],
        body="left",
    )
    need_join = client.post(
        f"/api/messages/{pub_mid}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert need_join.status_code == 403

    stranger = client.get(
        f"/api/channels/{ctx['channel']['id']}/pins",
        headers=_auth(ctx["stranger"]["token"]),
    )
    assert stranger.status_code == 404


def test_pin_archived_423_and_unknown_404(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    channel_id = ctx["channel"]["id"]
    mid = _seed_message(
        tmp_path,
        channel_id=channel_id,
        author_id=ctx["owner"]["user"]["id"],
    )

    client.post(
        f"/api/channels/{channel_id}/archive",
        headers=_auth(ctx["owner"]["token"]),
    )
    listed = client.get(
        f"/api/channels/{channel_id}/pins",
        headers=_auth(ctx["member"]["token"]),
    )
    assert listed.status_code == 200

    locked = client.post(
        f"/api/messages/{mid}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert locked.status_code == 423
    assert locked.json()["error"]["code"] == "archived"

    locked_del = client.delete(
        f"/api/messages/{mid}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert locked_del.status_code == 423

    client.post(
        f"/api/channels/{channel_id}/unarchive",
        headers=_auth(ctx["owner"]["token"]),
    )
    ok = client.post(
        f"/api/messages/{mid}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert ok.status_code == 200

    missing = client.post(
        f"/api/messages/{uuid.uuid4()}/pin",
        headers=_auth(ctx["member"]["token"]),
    )
    assert missing.status_code == 404
