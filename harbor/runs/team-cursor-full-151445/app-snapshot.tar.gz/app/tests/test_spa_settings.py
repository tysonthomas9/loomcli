"""SPA settings: required ids/testids and settings_ui asset wiring."""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from server.app import create_app
from server.settings import Settings

REQUIRED_IDS = (
    "workspace-settings-modal",
    "channel-settings-modal",
    "create-invitation-form",
)

REQUIRED_TESTIDS = (
    "workspace-settings-modal",
    "channel-settings-modal",
    "create-invitation-form",
    "workspace-settings-btn",
    "channel-settings-btn",
    "workspace-settings-close",
    "channel-settings-close",
    "settings-tab-general",
    "settings-tab-members",
    "settings-tab-invitations",
    "settings-panel-general",
    "settings-panel-members",
    "settings-panel-invitations",
    "settings-name",
    "settings-join-mode",
    "settings-general-save",
    "settings-general-error",
    "settings-members-list",
    "settings-members-error",
    "settings-transfer-owner",
    "settings-transfer-owner-select",
    "settings-transfer-owner-submit",
    "settings-transfer-error",
    "invitation-max-uses",
    "invitation-expires-seconds",
    "invitation-username",
    "invitation-create-submit",
    "invitation-create-error",
    "invitation-list",
    "invitation-list-error",
    "invitation-accept-form",
    "invitation-accept-code",
    "invitation-accept-submit",
    "invitation-accept-error",
    "settings-topic",
    "settings-topic-save",
    "settings-topic-error",
    "settings-archive",
    "settings-unarchive",
    "settings-archive-error",
    "channel-members-list",
    "channel-members-error",
    "channel-add-member-input",
    "channel-add-member-submit",
    "channel-add-member-error",
)

API_PATH_MARKERS = (
    "/api/workspaces/",
    "/members",
    "/transfer_ownership",
    "/invitations",
    "/api/invitations/",
    "/api/channels/",
    "/archive",
    "/unarchive",
)


@pytest.fixture()
def client(tmp_path: Path) -> TestClient:
    cfg = Settings(
        node_id=0,
        port=8000,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )
    return TestClient(create_app(cfg))


def test_settings_ids_and_testids_in_html(client: TestClient) -> None:
    root = client.get("/")
    assert root.status_code == 200
    html = root.text
    for dom_id in REQUIRED_IDS:
        assert f'id="{dom_id}"' in html, dom_id
    for testid in REQUIRED_TESTIDS:
        assert f'data-testid="{testid}"' in html, testid


def test_settings_ui_asset_served(client: TestClient) -> None:
    resp = client.get("/static/js/settings_ui.js")
    assert resp.status_code == 200
    body = resp.text
    assert "initSettingsUi" in body
    for marker in API_PATH_MARKERS:
        assert marker in body, marker
    assert "settings-member-row" in body
    assert "role-badge" in body
    assert "role-select" in body
    assert "invitation-code" in body
    assert "channel-member-row" in body


def test_app_js_imports_settings_ui(client: TestClient) -> None:
    resp = client.get("/static/js/app.js")
    assert resp.status_code == 200
    assert "settings_ui.js" in resp.text
    assert "initSettingsUi" in resp.text
