"""POST /api/channels/{id}/members — authz matrix and idempotent add."""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from server.app import create_app
from server.auth.users import USER_OBJ_KEYS
from server.db import utc_now_z
from server.settings import Settings

USER_KEYS = set(USER_OBJ_KEYS)


def _settings(tmp_path: Path) -> Settings:
    return Settings(
        node_id=0,
        port=8000,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path) -> TestClient:
    return TestClient(create_app(_settings(tmp_path)))


def _register(client: TestClient, username: str) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": "password1"},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _seed_ws_member(
    tmp_path: Path, *, workspace_id: str, user_id: str, role: str
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (workspace_id, user_id, role, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _seed_channel_member(
    tmp_path: Path, *, channel_id: str, user_id: str
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO channel_members (channel_id, user_id, created_at)
            VALUES (?, ?, ?)
            """,
            (channel_id, user_id, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _setup(tmp_path: Path) -> dict:
    client = _client(tmp_path)
    owner = _register(client, "owner1")
    admin = _register(client, "admin1")
    member = _register(client, "member1")
    guest = _register(client, "guest1")
    outsider = _register(client, "outsider1")
    ws = client.post(
        "/api/workspaces",
        headers=_auth(owner["token"]),
        json={"slug": "acme", "name": "Acme"},
    ).json()["workspace"]
    _seed_ws_member(
        tmp_path, workspace_id=ws["id"], user_id=admin["user"]["id"], role="admin"
    )
    _seed_ws_member(
        tmp_path,
        workspace_id=ws["id"],
        user_id=member["user"]["id"],
        role="member",
    )
    _seed_ws_member(
        tmp_path, workspace_id=ws["id"], user_id=guest["user"]["id"], role="guest"
    )
    pub = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(owner["token"]),
        json={"name": "eng"},
    ).json()["channel"]
    priv = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(owner["token"]),
        json={"name": "vault", "is_private": True},
    ).json()["channel"]
    return {
        "client": client,
        "owner": owner,
        "admin": admin,
        "member": member,
        "guest": guest,
        "outsider": outsider,
        "ws": ws,
        "pub": pub,
        "priv": priv,
        "tmp_path": tmp_path,
    }


def test_owner_adds_member_by_username(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    resp = client.post(
        f"/api/channels/{ctx['pub']['id']}/members",
        headers=_auth(ctx["owner"]["token"]),
        json={"username": "member1"},
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert set(body.keys()) == {"members"}
    ids = {m["id"] for m in body["members"]}
    assert ctx["member"]["user"]["id"] in ids
    assert ctx["owner"]["user"]["id"] in ids
    for m in body["members"]:
        assert set(m.keys()) == USER_KEYS


def test_admin_adds_to_private_without_membership(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    resp = client.post(
        f"/api/channels/{ctx['priv']['id']}/members",
        headers=_auth(ctx["admin"]["token"]),
        json={"username": "member1"},
    )
    assert resp.status_code == 200, resp.text
    ids = {m["id"] for m in resp.json()["members"]}
    assert ctx["member"]["user"]["id"] in ids


def test_channel_member_can_add(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    _seed_channel_member(
        tmp_path,
        channel_id=ctx["pub"]["id"],
        user_id=ctx["member"]["user"]["id"],
    )
    resp = client.post(
        f"/api/channels/{ctx['pub']['id']}/members",
        headers=_auth(ctx["member"]["token"]),
        json={"user_id": ctx["admin"]["user"]["id"]},
    )
    assert resp.status_code == 200, resp.text
    ids = {m["id"] for m in resp.json()["members"]}
    assert ctx["admin"]["user"]["id"] in ids


def test_member_not_on_channel_cannot_add(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    # member1 is not on private vault; cannot add
    resp = client.post(
        f"/api/channels/{ctx['priv']['id']}/members",
        headers=_auth(ctx["member"]["token"]),
        json={"username": "admin1"},
    )
    assert resp.status_code == 403


def test_guest_cannot_add_even_as_channel_member(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    _seed_channel_member(
        tmp_path,
        channel_id=ctx["pub"]["id"],
        user_id=ctx["guest"]["user"]["id"],
    )
    resp = ctx["client"].post(
        f"/api/channels/{ctx['pub']['id']}/members",
        headers=_auth(ctx["guest"]["token"]),
        json={"username": "member1"},
    )
    assert resp.status_code == 403


def test_outsider_username_400(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    resp = ctx["client"].post(
        f"/api/channels/{ctx['pub']['id']}/members",
        headers=_auth(ctx["owner"]["token"]),
        json={"username": "outsider1"},
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "validation_error"


def test_stranger_caller_404(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    stranger = _register(ctx["client"], "stranger1")
    resp = ctx["client"].post(
        f"/api/channels/{ctx['pub']['id']}/members",
        headers=_auth(stranger["token"]),
        json={"username": "member1"},
    )
    assert resp.status_code == 404


def test_unknown_channel_404(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    resp = ctx["client"].post(
        f"/api/channels/{uuid.uuid4()}/members",
        headers=_auth(ctx["owner"]["token"]),
        json={"username": "member1"},
    )
    assert resp.status_code == 404


def test_idempotent_add(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    path = f"/api/channels/{ctx['pub']['id']}/members"
    first = client.post(
        path,
        headers=_auth(ctx["owner"]["token"]),
        json={"username": "member1"},
    )
    second = client.post(
        path,
        headers=_auth(ctx["owner"]["token"]),
        json={"username": "member1"},
    )
    assert first.status_code == 200
    assert second.status_code == 200
    assert len(first.json()["members"]) == len(second.json()["members"])


def test_mismatched_username_and_user_id_400(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    resp = ctx["client"].post(
        f"/api/channels/{ctx['pub']['id']}/members",
        headers=_auth(ctx["owner"]["token"]),
        json={
            "username": "member1",
            "user_id": ctx["admin"]["user"]["id"],
        },
    )
    assert resp.status_code == 400


def test_missing_target_400(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    resp = ctx["client"].post(
        f"/api/channels/{ctx['pub']['id']}/members",
        headers=_auth(ctx["owner"]["token"]),
        json={},
    )
    assert resp.status_code == 400


def test_dm_channel_403(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    dm_id = str(uuid.uuid4())
    now = utc_now_z()
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO channels (
              id, workspace_id, name, is_private, is_dm, topic, is_archived,
              created_at, updated_at
            ) VALUES (?, ?, ?, 1, 1, '', 0, ?, ?)
            """,
            (dm_id, ctx["ws"]["id"], "dm-owner-member", now, now),
        )
        conn.execute(
            """
            INSERT INTO channel_members (channel_id, user_id, created_at)
            VALUES (?, ?, ?), (?, ?, ?)
            """,
            (
                dm_id,
                ctx["owner"]["user"]["id"],
                now,
                dm_id,
                ctx["member"]["user"]["id"],
                now,
            ),
        )
        conn.commit()
    finally:
        conn.close()

    resp = ctx["client"].post(
        f"/api/channels/{dm_id}/members",
        headers=_auth(ctx["owner"]["token"]),
        json={"username": "admin1"},
    )
    assert resp.status_code == 403


def test_add_on_archived_allowed(tmp_path: Path) -> None:
    ctx = _setup(tmp_path)
    client = ctx["client"]
    archive = client.post(
        f"/api/channels/{ctx['pub']['id']}/archive",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert archive.status_code == 200
    resp = client.post(
        f"/api/channels/{ctx['pub']['id']}/members",
        headers=_auth(ctx["owner"]["token"]),
        json={"username": "admin1"},
    )
    assert resp.status_code == 200, resp.text
    ids = {m["id"] for m in resp.json()["members"]}
    assert ctx["admin"]["user"]["id"] in ids
