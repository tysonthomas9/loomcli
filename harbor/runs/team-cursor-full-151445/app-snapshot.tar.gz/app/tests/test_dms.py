"""Contract tests for POST /api/dms get-or-create (MARATHON-9)."""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from server.app import create_app
from server.channels.store import CHANNEL_OBJ_KEYS
from server.db import utc_now_z
from server.dms.store import canonical_dm_name
from server.settings import Settings

CH_KEYS = set(CHANNEL_OBJ_KEYS)


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


def _register(
    client: TestClient,
    username: str,
    password: str = "password1",
) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": password},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _create_ws(
    client: TestClient,
    token: str,
    slug: str = "acme",
    name: str = "Acme Corp",
) -> dict:
    resp = client.post(
        "/api/workspaces",
        headers=_auth(token),
        json={"slug": slug, "name": name},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["workspace"]


def _seed_ws_member(
    tmp_path: Path,
    *,
    workspace_id: str,
    user_id: str,
    role: str = "member",
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (workspace_id, user_id, role, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _setup_trio(tmp_path: Path) -> dict:
    """Owner A, members B and C in one workspace."""
    client = _client(tmp_path)
    a = _register(client, "alice")
    b = _register(client, "bob")
    c = _register(client, "carol")
    outsider = _register(client, "outsider")
    ws = _create_ws(client, a["token"])
    _seed_ws_member(
        tmp_path, workspace_id=ws["id"], user_id=b["user"]["id"], role="member"
    )
    _seed_ws_member(
        tmp_path, workspace_id=ws["id"], user_id=c["user"]["id"], role="member"
    )
    return {
        "client": client,
        "a": a,
        "b": b,
        "c": c,
        "outsider": outsider,
        "ws": ws,
    }


def test_create_idempotent_and_symmetric(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    ws = ctx["ws"]
    a, b = ctx["a"], ctx["b"]

    r1 = client.post(
        "/api/dms",
        headers=_auth(a["token"]),
        json={"user_id": b["user"]["id"], "workspace_id": ws["id"], "x": 1},
    )
    assert r1.status_code == 200, r1.text
    body1 = r1.json()
    assert set(body1.keys()) == {"channel_id"}
    assert "channel" not in body1
    channel_id = body1["channel_id"]
    uuid.UUID(channel_id)

    r2 = client.post(
        "/api/dms",
        headers=_auth(a["token"]),
        json={"user_id": b["user"]["id"], "workspace_id": ws["id"]},
    )
    assert r2.status_code == 200, r2.text
    assert r2.json()["channel_id"] == channel_id

    r3 = client.post(
        "/api/dms",
        headers=_auth(b["token"]),
        json={"user_id": a["user"]["id"], "workspace_id": ws["id"]},
    )
    assert r3.status_code == 200, r3.text
    assert r3.json()["channel_id"] == channel_id

    expected_name = canonical_dm_name(
        workspace_id=ws["id"],
        user_a=a["user"]["id"],
        user_b=b["user"]["id"],
    )
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute(
            "SELECT * FROM channels WHERE id = ?", (channel_id,)
        ).fetchone()
        assert row is not None
        assert int(row["is_dm"]) == 1
        assert int(row["is_private"]) == 1
        assert row["name"] == expected_name
        members = {
            r["user_id"]
            for r in conn.execute(
                "SELECT user_id FROM channel_members WHERE channel_id = ?",
                (channel_id,),
            )
        }
        assert members == {a["user"]["id"], b["user"]["id"]}
        count = conn.execute(
            "SELECT COUNT(*) AS n FROM channels WHERE workspace_id = ? AND is_dm = 1",
            (ws["id"],),
        ).fetchone()["n"]
        assert count == 1
    finally:
        conn.close()


def test_workspace_detail_visibility(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    ws = ctx["ws"]
    a, b, c = ctx["a"], ctx["b"], ctx["c"]

    resp = client.post(
        "/api/dms",
        headers=_auth(a["token"]),
        json={"user_id": b["user"]["id"], "workspace_id": ws["id"]},
    )
    assert resp.status_code == 200, resp.text
    channel_id = resp.json()["channel_id"]

    for user in (a, b):
        detail = client.get(
            f"/api/workspaces/{ws['slug']}",
            headers=_auth(user["token"]),
        )
        assert detail.status_code == 200, detail.text
        channels = detail.json()["channels"]
        dm = next(ch for ch in channels if ch["id"] == channel_id)
        assert set(dm.keys()) >= CH_KEYS
        assert dm["is_dm"] is True
        assert dm["is_private"] is True

    detail_c = client.get(
        f"/api/workspaces/{ws['slug']}",
        headers=_auth(c["token"]),
    )
    assert detail_c.status_code == 200, detail_c.text
    ids = {ch["id"] for ch in detail_c.json()["channels"]}
    assert channel_id not in ids


def test_self_dm_rejected(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    a, ws = ctx["a"], ctx["ws"]
    before = _dm_count(tmp_path, ws["id"])
    resp = client.post(
        "/api/dms",
        headers=_auth(a["token"]),
        json={"user_id": a["user"]["id"], "workspace_id": ws["id"]},
    )
    assert resp.status_code == 400, resp.text
    err = resp.json()["error"]
    assert err["code"] == "validation_error"
    assert "yourself" in err["message"]
    assert _dm_count(tmp_path, ws["id"]) == before


def test_unknown_peer_404(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    a, ws = ctx["a"], ctx["ws"]
    before = _dm_count(tmp_path, ws["id"])
    resp = client.post(
        "/api/dms",
        headers=_auth(a["token"]),
        json={"user_id": str(uuid.uuid4()), "workspace_id": ws["id"]},
    )
    assert resp.status_code == 404, resp.text
    assert resp.json()["error"]["code"] == "not_found"
    assert resp.json()["error"]["message"] == "user not found"
    assert _dm_count(tmp_path, ws["id"]) == before


def test_peer_not_in_workspace_404(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    a, outsider, ws = ctx["a"], ctx["outsider"], ctx["ws"]
    before = _dm_count(tmp_path, ws["id"])
    resp = client.post(
        "/api/dms",
        headers=_auth(a["token"]),
        json={"user_id": outsider["user"]["id"], "workspace_id": ws["id"]},
    )
    assert resp.status_code == 404, resp.text
    assert resp.json()["error"]["message"] == "user not found"
    assert _dm_count(tmp_path, ws["id"]) == before


def test_caller_not_in_workspace_404(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    outsider, b, ws = ctx["outsider"], ctx["b"], ctx["ws"]
    before = _dm_count(tmp_path, ws["id"])
    resp = client.post(
        "/api/dms",
        headers=_auth(outsider["token"]),
        json={"user_id": b["user"]["id"], "workspace_id": ws["id"]},
    )
    assert resp.status_code == 404, resp.text
    assert resp.json()["error"]["message"] == "workspace not found"
    assert _dm_count(tmp_path, ws["id"]) == before


def test_unauthenticated_401(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    resp = client.post(
        "/api/dms",
        json={
            "user_id": ctx["b"]["user"]["id"],
            "workspace_id": ctx["ws"]["id"],
        },
    )
    assert resp.status_code == 401, resp.text
    assert resp.json()["error"]["code"] == "unauthorized"


def test_leave_then_get_or_create_restores_membership(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    a, b, ws = ctx["a"], ctx["b"], ctx["ws"]

    r1 = client.post(
        "/api/dms",
        headers=_auth(a["token"]),
        json={"user_id": b["user"]["id"], "workspace_id": ws["id"]},
    )
    assert r1.status_code == 200, r1.text
    channel_id = r1.json()["channel_id"]

    leave = client.post(
        f"/api/channels/{channel_id}/leave",
        headers=_auth(a["token"]),
    )
    assert leave.status_code == 200, leave.text
    assert not _is_channel_member(tmp_path, channel_id, a["user"]["id"])

    r2 = client.post(
        "/api/dms",
        headers=_auth(a["token"]),
        json={"user_id": b["user"]["id"], "workspace_id": ws["id"]},
    )
    assert r2.status_code == 200, r2.text
    assert r2.json()["channel_id"] == channel_id
    assert _is_channel_member(tmp_path, channel_id, a["user"]["id"])
    assert _is_channel_member(tmp_path, channel_id, b["user"]["id"])

    members = client.get(
        f"/api/channels/{channel_id}/members",
        headers=_auth(a["token"]),
    )
    assert members.status_code == 200, members.text
    ids = {m["id"] for m in members.json()["members"]}
    assert a["user"]["id"] in ids
    assert b["user"]["id"] in ids


def test_owner_without_membership_denied_on_dm(tmp_path: Path) -> None:
    """Workspace owner who is not a DM participant cannot read members."""
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    a, b, c, ws = ctx["a"], ctx["b"], ctx["c"], ctx["ws"]

    # A is owner; create DM between B and C so A is not a channel member.
    resp = client.post(
        "/api/dms",
        headers=_auth(b["token"]),
        json={"user_id": c["user"]["id"], "workspace_id": ws["id"]},
    )
    assert resp.status_code == 200, resp.text
    channel_id = resp.json()["channel_id"]
    assert not _is_channel_member(tmp_path, channel_id, a["user"]["id"])

    members = client.get(
        f"/api/channels/{channel_id}/members",
        headers=_auth(a["token"]),
    )
    assert members.status_code == 403, members.text
    assert members.json()["error"]["code"] == "forbidden"

    pins = client.get(
        f"/api/channels/{channel_id}/pins",
        headers=_auth(a["token"]),
    )
    assert pins.status_code == 403, pins.text

    patch = client.patch(
        f"/api/channels/{channel_id}",
        headers=_auth(a["token"]),
        json={"topic": "nope"},
    )
    assert patch.status_code == 403, patch.text


def test_normal_channel_create_still_forces_is_dm_false(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    resp = client.post(
        f"/api/workspaces/{ctx['ws']['slug']}/channels",
        headers=_auth(ctx["a"]["token"]),
        json={"name": "eng", "is_dm": True},
    )
    assert resp.status_code == 201, resp.text
    assert resp.json()["channel"]["is_dm"] is False


def test_validation_missing_fields(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    resp = client.post(
        "/api/dms",
        headers=_auth(ctx["a"]["token"]),
        json={"workspace_id": ctx["ws"]["id"]},
    )
    assert resp.status_code == 400, resp.text
    assert resp.json()["error"]["code"] == "validation_error"


def test_guest_may_dm_member(tmp_path: Path) -> None:
    ctx = _setup_trio(tmp_path)
    client = ctx["client"]
    guest = _register(client, "guest1")
    _seed_ws_member(
        tmp_path,
        workspace_id=ctx["ws"]["id"],
        user_id=guest["user"]["id"],
        role="guest",
    )
    resp = client.post(
        "/api/dms",
        headers=_auth(guest["token"]),
        json={
            "user_id": ctx["b"]["user"]["id"],
            "workspace_id": ctx["ws"]["id"],
        },
    )
    assert resp.status_code == 200, resp.text
    uuid.UUID(resp.json()["channel_id"])


def _dm_count(tmp_path: Path, workspace_id: str) -> int:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        row = conn.execute(
            "SELECT COUNT(*) FROM channels WHERE workspace_id = ? AND is_dm = 1",
            (workspace_id,),
        ).fetchone()
        return int(row[0])
    finally:
        conn.close()


def _is_channel_member(tmp_path: Path, channel_id: str, user_id: str) -> bool:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        row = conn.execute(
            """
            SELECT 1 FROM channel_members
            WHERE channel_id = ? AND user_id = ?
            """,
            (channel_id, user_id),
        ).fetchone()
        return row is not None
    finally:
        conn.close()
