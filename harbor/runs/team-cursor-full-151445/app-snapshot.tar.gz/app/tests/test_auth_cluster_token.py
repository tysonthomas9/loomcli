"""Live-cluster: bearer token accepted on all HTTP nodes (MARATHON-22).

Register/login on :8000; GET /api/auth/me with the same Bearer on :8001 and
:8002 must return 200 {user} matching the registered user. /api/health on each
node stays unauthenticated {status,node_id}.
"""

from __future__ import annotations

import os
import signal
import socket
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any

import httpx
import pytest

APP_ROOT = Path(__file__).resolve().parents[1]
START_SH = APP_ROOT / "start.sh"
PORTS = (8000, 8001, 8002)
PEER_PORTS = (8001, 8002)
REDIS_PORT = 6379
BOOT_TIMEOUT_S = 60.0

USER_OBJ_KEYS = {
    "id",
    "username",
    "display_name",
    "timezone",
    "avatar_url",
    "status_text",
    "status_emoji",
}


def _port_free(port: int, host: str = "127.0.0.1") -> bool:
    s = socket.socket()
    try:
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _wait_health(port: int, node_id: int, timeout: float = BOOT_TIMEOUT_S) -> dict:
    deadline = time.monotonic() + timeout
    url = f"http://127.0.0.1:{port}/api/health"
    last_err: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with httpx.Client(timeout=1.0) as client:
                r = client.get(url)
            if r.status_code == 200:
                body = r.json()
                if body == {"status": "ok", "node_id": node_id}:
                    return body
                last_err = AssertionError(f"unexpected health body on {port}: {body!r}")
        except Exception as exc:  # noqa: BLE001 — poll until ready
            last_err = exc
        time.sleep(0.2)
    raise TimeoutError(
        f"health on :{port} did not become {{status:ok,node_id:{node_id}}} "
        f"within {timeout}s; last={last_err!r}"
    )


def _uniq(prefix: str = "qa") -> str:
    return f"{prefix}{uuid.uuid4().hex[:10]}"


def _assert_user_obj(user: dict[str, Any], *, expected: dict[str, Any]) -> None:
    assert set(user.keys()) == USER_OBJ_KEYS
    assert "email" not in user
    assert user == expected


def _assert_error_envelope(body: dict[str, Any], *, code: str) -> None:
    assert set(body.keys()) == {"error"}
    assert set(body["error"].keys()) == {"code", "message"}
    assert body["error"]["code"] == code
    assert isinstance(body["error"]["message"], str)
    assert len(body["error"]["message"]) > 0
    assert "detail" not in body


@pytest.fixture(scope="module")
def cluster() -> subprocess.Popen[bytes]:
    """Boot ./start.sh once for the module; tear down the whole tree after."""
    assert START_SH.is_file(), f"missing {START_SH}"
    assert os.access(START_SH, os.X_OK), f"{START_SH} is not executable"

    subprocess.run(["marathon-freeports"], check=False)

    for port in (*PORTS, REDIS_PORT):
        if not _port_free(port):
            pytest.fail(f"port {port} still busy before start.sh")

    log_path = APP_ROOT / "data" / "run" / "qa-auth-cluster-token.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = open(log_path, "wb")  # noqa: SIM115 — closed in finally
    proc = subprocess.Popen(
        [str(START_SH)],
        cwd=str(APP_ROOT),
        stdout=log_f,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    try:
        for node_id, port in enumerate(PORTS):
            _wait_health(port, node_id)
        assert proc.poll() is None, "start.sh exited before health became ready"
        yield proc
    finally:
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=5)
        log_f.close()
        subprocess.run(["marathon-freeports"], check=False)


def test_register_token_from_8000_accepted_on_peer_nodes(
    cluster: subprocess.Popen[bytes],
) -> None:
    """AC8: token minted via register on :8000 works on :8001 and :8002."""
    del cluster
    username = _uniq("regx")
    with httpx.Client(timeout=5.0) as client:
        reg = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": username, "password": "password1"},
        )
        assert reg.status_code == 201
        body = reg.json()
        token = body["token"]
        expected_user = body["user"]
        assert isinstance(token, str) and len(token) >= 16

        for port in PEER_PORTS:
            me = client.get(
                f"http://127.0.0.1:{port}/api/auth/me",
                headers={"Authorization": f"Bearer {token}"},
            )
            assert me.status_code == 200, f"port {port}: {me.status_code} {me.text}"
            payload = me.json()
            assert set(payload.keys()) == {"user"}
            _assert_user_obj(payload["user"], expected=expected_user)
            assert "email" not in me.text
            assert "password1" not in me.text


def test_login_token_from_8000_accepted_on_peer_nodes(
    cluster: subprocess.Popen[bytes],
) -> None:
    """AC8: token minted via login on :8000 works on :8001 and :8002."""
    del cluster
    username = _uniq("logx")
    with httpx.Client(timeout=5.0) as client:
        reg = client.post(
            "http://127.0.0.1:8000/api/auth/register",
            json={"username": username, "password": "password1"},
        )
        assert reg.status_code == 201
        login = client.post(
            "http://127.0.0.1:8000/api/auth/login",
            json={"username": username, "password": "password1"},
        )
        assert login.status_code == 200
        token = login.json()["token"]
        expected_user = login.json()["user"]
        assert token != reg.json()["token"]

        for port in PEER_PORTS:
            me = client.get(
                f"http://127.0.0.1:{port}/api/auth/me",
                headers={"Authorization": f"Bearer {token}"},
            )
            assert me.status_code == 200, f"port {port}"
            payload = me.json()
            assert set(payload.keys()) == {"user"}
            _assert_user_obj(payload["user"], expected=expected_user)


@pytest.mark.parametrize("node_id,port", [(0, 8000), (1, 8001), (2, 8002)])
def test_health_on_each_node_unauthenticated_status_node_id(
    cluster: subprocess.Popen[bytes], node_id: int, port: int
) -> None:
    """AC10: /api/health stays unenveloped {status,node_id} without auth."""
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.get(f"http://127.0.0.1:{port}/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body == {"status": "ok", "node_id": node_id}
    assert set(body.keys()) == {"status", "node_id"}
    assert "error" not in body
    assert "user" not in body


@pytest.mark.parametrize("node_id,port", [(0, 8000), (1, 8001), (2, 8002)])
def test_health_ignores_bearer_and_stays_unenveloped(
    cluster: subprocess.Popen[bytes], node_id: int, port: int
) -> None:
    """Negative: Authorization must not change /api/health contract."""
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.get(
            f"http://127.0.0.1:{port}/api/health",
            headers={"Authorization": "Bearer definitely-not-a-real-token"},
        )
    assert r.status_code == 200
    assert r.json() == {"status": "ok", "node_id": node_id}
    assert "error" not in r.json()


@pytest.mark.parametrize("port", list(PEER_PORTS))
def test_invalid_token_rejected_on_peer_nodes(
    cluster: subprocess.Popen[bytes], port: int
) -> None:
    """Negative: peer nodes must not accept an unknown bearer."""
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.get(
            f"http://127.0.0.1:{port}/api/auth/me",
            headers={"Authorization": "Bearer definitely-not-a-real-token"},
        )
    assert r.status_code == 401
    _assert_error_envelope(r.json(), code="unauthorized")


@pytest.mark.parametrize("port", list(PEER_PORTS))
def test_missing_bearer_rejected_on_peer_nodes(
    cluster: subprocess.Popen[bytes], port: int
) -> None:
    """Negative: peer /me without Authorization stays 401."""
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.get(f"http://127.0.0.1:{port}/api/auth/me")
    assert r.status_code == 401
    _assert_error_envelope(r.json(), code="unauthorized")
