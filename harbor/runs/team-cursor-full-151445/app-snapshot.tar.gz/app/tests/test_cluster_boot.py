"""Live-cluster checks for start.sh boot health, Redis, and stub GET /.

Verifies MARATHON-2 / epic health+boot contract on fixed ports via a real
./start.sh process tree (not TestClient).
"""

from __future__ import annotations

import json
import os
import signal
import socket
import subprocess
import time
from pathlib import Path

import httpx
import pytest

APP_ROOT = Path(__file__).resolve().parents[1]
START_SH = APP_ROOT / "start.sh"
PORTS = (8000, 8001, 8002)
REDIS_PORT = 6379
IRC_PORT = 6667
BOOT_TIMEOUT_S = 60.0


def _port_free(port: int, host: str = "127.0.0.1") -> bool:
    s = socket.socket()
    try:
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _wait_health(port: int, node_id: int, timeout: float = BOOT_TIMEOUT_S) -> dict:
    deadline = time.monotonic() + timeout
    url = f"http://127.0.0.1:{port}/api/health"
    last_err: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with httpx.Client(timeout=1.0) as client:
                r = client.get(url)
            if r.status_code == 200:
                body = r.json()
                if body == {"status": "ok", "node_id": node_id}:
                    return body
                last_err = AssertionError(f"unexpected health body on {port}: {body!r}")
        except Exception as exc:  # noqa: BLE001 — poll until ready
            last_err = exc
        time.sleep(0.2)
    raise TimeoutError(
        f"health on :{port} did not become {{status:ok,node_id:{node_id}}} "
        f"within {timeout}s; last={last_err!r}"
    )


@pytest.fixture(scope="module")
def cluster() -> subprocess.Popen[bytes]:
    """Boot ./start.sh once for the module; tear down the whole tree after."""
    assert START_SH.is_file(), f"missing {START_SH}"
    assert os.access(START_SH, os.X_OK), f"{START_SH} is not executable"

    # Prefer a clean slate; marathon-freeports is also run by the outer harness.
    subprocess.run(["marathon-freeports"], check=False)

    for port in (*PORTS, REDIS_PORT):
        if not _port_free(port):
            pytest.fail(f"port {port} still busy before start.sh")

    log_path = APP_ROOT / "data" / "run" / "qa-cluster-boot.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_f = open(log_path, "wb")  # noqa: SIM115 — closed in finally via terminate path
    proc = subprocess.Popen(
        [str(START_SH)],
        cwd=str(APP_ROOT),
        stdout=log_f,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    try:
        for node_id, port in enumerate(PORTS):
            _wait_health(port, node_id)
        # Confirm supervisor is still the parent of the live tree.
        assert proc.poll() is None, "start.sh exited before health became ready"
        yield proc
    finally:
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=5)
        log_f.close()
        subprocess.run(["marathon-freeports"], check=False)


def test_start_sh_stays_alive_while_children_serve(cluster: subprocess.Popen[bytes]) -> None:
    assert cluster.poll() is None
    time.sleep(1.5)
    assert cluster.poll() is None, "start.sh exited while children should still serve"
    for node_id, port in enumerate(PORTS):
        body = _wait_health(port, node_id, timeout=5.0)
        assert body == {"status": "ok", "node_id": node_id}


@pytest.mark.parametrize("node_id,port", [(0, 8000), (1, 8001), (2, 8002)])
def test_health_returns_ok_with_matching_node_id(
    cluster: subprocess.Popen[bytes], node_id: int, port: int
) -> None:
    del cluster  # fixture ensures cluster is up
    with httpx.Client(timeout=5.0) as client:
        r = client.get(f"http://127.0.0.1:{port}/api/health")
    assert r.status_code == 200
    assert "application/json" in r.headers.get("content-type", "")
    assert r.json() == {"status": "ok", "node_id": node_id}
    # Exact key set / types (contract shape, not merely status 200).
    payload = r.json()
    assert set(payload.keys()) == {"status", "node_id"}
    assert isinstance(payload["status"], str)
    assert isinstance(payload["node_id"], int)


@pytest.mark.parametrize("port", PORTS)
def test_health_does_not_require_authorization(
    cluster: subprocess.Popen[bytes], port: int
) -> None:
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.get(f"http://127.0.0.1:{port}/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"
    # Explicit negative: unauthenticated request must not be 401/403.
    assert r.status_code not in (401, 403)


def test_node_ids_are_not_swapped_across_ports(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    observed: dict[int, int] = {}
    with httpx.Client(timeout=5.0) as client:
        for port in PORTS:
            body = client.get(f"http://127.0.0.1:{port}/api/health").json()
            observed[port] = body["node_id"]
    assert observed == {8000: 0, 8001: 1, 8002: 2}
    # Negative: no port may advertise another node's id.
    for port, node_id in observed.items():
        for other_port, other_id in observed.items():
            if port != other_port:
                assert node_id != other_id


def test_local_redis_ping_pong(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    result = subprocess.run(
        ["redis-cli", "-h", "127.0.0.1", "-p", "6379", "PING"],
        check=True,
        capture_output=True,
        text=True,
        timeout=5,
    )
    assert result.stdout.strip() == "PONG"


@pytest.mark.parametrize("port", PORTS)
def test_root_returns_200_html(cluster: subprocess.Popen[bytes], port: int) -> None:
    del cluster
    with httpx.Client(timeout=5.0) as client:
        r = client.get(f"http://127.0.0.1:{port}/")
    assert r.status_code == 200
    ctype = r.headers.get("content-type", "")
    assert "text/html" in ctype
    assert "<html" in r.text.lower() or "<!doctype html" in r.text.lower()
    assert "Huddle" in r.text


def test_cluster_does_not_bind_irc_port(cluster: subprocess.Popen[bytes]) -> None:
    """MARATHON-2 negative: boot must not bind :6667 (IRC is a later task)."""
    del cluster
    assert _port_free(IRC_PORT), "port 6667 must remain free after cluster boot"


def test_start_sh_has_no_docker_or_remote_redis_dependency() -> None:
    """Static negative: supervisor must be self-contained on localhost."""
    text = START_SH.read_text(encoding="utf-8")
    lowered = text.lower()
    assert "docker" not in lowered
    assert "docker-compose" not in lowered
    assert "podman" not in lowered
    # Redis must be local redis-server, not a remote hostname/service name.
    assert "redis-server" in text
    assert "127.0.0.1" in text


def test_durable_data_layout_after_boot(cluster: subprocess.Popen[bytes]) -> None:
    del cluster
    data = APP_ROOT / "data"
    assert data.is_dir()
    assert (data / "huddle.sqlite").is_file()
    assert (data / "redis").is_dir()
    assert (data / "run").is_dir()
