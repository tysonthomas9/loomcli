"""Contract tests for channels lifecycle and workspace join."""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from server.app import create_app
from server.auth.users import USER_OBJ_KEYS
from server.channels.store import CHANNEL_OBJ_KEYS
from server.db import (
    apply_migrations,
    connect_and_bootstrap,
    reverse_migration,
    utc_now_z,
)
from server.settings import Settings
from server.workspaces.store import WORKSPACE_OBJ_KEYS

WS_KEYS = set(WORKSPACE_OBJ_KEYS)
CH_KEYS = set(CHANNEL_OBJ_KEYS)
USER_KEYS = set(USER_OBJ_KEYS)


def _settings(tmp_path: Path, node_id: int = 0) -> Settings:
    return Settings(
        node_id=node_id,
        port=8000 + node_id,
        data_dir=str(tmp_path),
        redis_url="redis://127.0.0.1:6379/0",
    )


def _client(tmp_path: Path, node_id: int = 0) -> TestClient:
    return TestClient(create_app(_settings(tmp_path, node_id)))


def _register(
    client: TestClient,
    username: str,
    password: str = "password1",
) -> dict:
    resp = client.post(
        "/api/auth/register",
        json={"username": username, "password": password},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


def _auth(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _create_ws(
    client: TestClient,
    token: str,
    slug: str = "acme",
    name: str = "Acme Corp",
) -> dict:
    resp = client.post(
        "/api/workspaces",
        headers=_auth(token),
        json={"slug": slug, "name": name},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["workspace"]


def _seed_ws_member(
    tmp_path: Path,
    *,
    workspace_id: str,
    user_id: str,
    role: str,
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (workspace_id, user_id, role, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _seed_channel_member(
    tmp_path: Path, *, channel_id: str, user_id: str
) -> None:
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        conn.execute(
            """
            INSERT INTO channel_members (channel_id, user_id, created_at)
            VALUES (?, ?, ?)
            """,
            (channel_id, user_id, utc_now_z()),
        )
        conn.commit()
    finally:
        conn.close()


def _setup_roles(tmp_path: Path) -> dict:
    client = _client(tmp_path)
    owner = _register(client, "owner1")
    admin = _register(client, "admin1")
    member = _register(client, "member1")
    guest = _register(client, "guest1")
    stranger = _register(client, "stranger1")
    ws = _create_ws(client, owner["token"])
    _seed_ws_member(
        tmp_path, workspace_id=ws["id"], user_id=admin["user"]["id"], role="admin"
    )
    _seed_ws_member(
        tmp_path,
        workspace_id=ws["id"],
        user_id=member["user"]["id"],
        role="member",
    )
    _seed_ws_member(
        tmp_path, workspace_id=ws["id"], user_id=guest["user"]["id"], role="guest"
    )
    return {
        "client": client,
        "owner": owner,
        "admin": admin,
        "member": member,
        "guest": guest,
        "stranger": stranger,
        "ws": ws,
    }


def test_create_public_channel_as_member(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    resp = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["member"]["token"]),
        json={"name": "eng", "description": "ignored", "x": 1},
    )
    assert resp.status_code == 201, resp.text
    body = resp.json()
    assert set(body.keys()) == {"channel"}
    ch = body["channel"]
    assert set(ch.keys()) == CH_KEYS
    assert ch["name"] == "eng"
    assert ch["workspace_id"] == ctx["ws"]["id"]
    assert ch["is_private"] is False
    assert ch["is_dm"] is False
    assert ch["topic"] == ""
    assert ch["is_archived"] is False

    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        row = conn.execute(
            "SELECT 1 FROM channel_members WHERE channel_id = ? AND user_id = ?",
            (ch["id"], ctx["member"]["user"]["id"]),
        ).fetchone()
        assert row is not None
    finally:
        conn.close()


def test_create_channel_duplicate_409(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    first = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "eng"},
    )
    assert first.status_code == 201
    # duplicate general
    general = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "general"},
    )
    assert general.status_code == 409
    assert general.json()["error"]["code"] == "conflict"
    resp = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["member"]["token"]),
        json={"name": "eng"},
    )
    assert resp.status_code == 409
    assert resp.json()["error"]["code"] == "conflict"


def test_create_channel_invalid_name_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    for bad in ("General", "eng_ops", "e", "", "ENG"):
        resp = client.post(
            "/api/workspaces/acme/channels",
            headers=_auth(ctx["owner"]["token"]),
            json={"name": bad},
        )
        assert resp.status_code == 400, bad
        assert resp.json()["error"]["code"] == "validation_error"


def test_create_channel_topic_too_long_400(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    resp = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "topic-long", "topic": "x" * 251},
    )
    assert resp.status_code == 400
    assert resp.json()["error"]["code"] == "validation_error"
    ok = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "topic-ok", "topic": "x" * 250},
    )
    assert ok.status_code == 201
    assert ok.json()["channel"]["topic"] == "x" * 250


def test_create_channel_role_matrix(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]

    guest = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["guest"]["token"]),
        json={"name": "gchan"},
    )
    assert guest.status_code == 403
    assert guest.json()["error"]["code"] == "forbidden"

    member_priv = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["member"]["token"]),
        json={"name": "secret", "is_private": True},
    )
    assert member_priv.status_code == 403

    stranger = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["stranger"]["token"]),
        json={"name": "nope"},
    )
    assert stranger.status_code == 404

    admin_priv = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["admin"]["token"]),
        json={"name": "secret", "is_private": True},
    )
    assert admin_priv.status_code == 201
    assert admin_priv.json()["channel"]["is_private"] is True

    owner_priv = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "owners-only", "is_private": True},
    )
    assert owner_priv.status_code == 201


def test_create_channel_unauthenticated_401(tmp_path: Path) -> None:
    client = _client(tmp_path)
    resp = client.post("/api/workspaces/acme/channels", json={"name": "eng"})
    assert resp.status_code == 401


def test_workspace_join_open_invite_only_idempotent(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    stranger = ctx["stranger"]

    join = client.post(
        "/api/workspaces/acme/join",
        headers=_auth(stranger["token"]),
        json={},
    )
    assert join.status_code == 200, join.text
    body = join.json()
    assert set(body["workspace"].keys()) == WS_KEYS
    assert "channels" in body
    assert "read_state" in body
    assert any(c["name"] == "general" for c in body["channels"])

    detail = client.get("/api/workspaces/acme", headers=_auth(stranger["token"]))
    assert detail.status_code == 200

    again = client.post(
        "/api/workspaces/acme/join",
        headers=_auth(stranger["token"]),
        json={},
    )
    assert again.status_code == 200
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        n = conn.execute(
            """
            SELECT COUNT(*) FROM workspace_members
            WHERE workspace_id = ? AND user_id = ?
            """,
            (ctx["ws"]["id"], stranger["user"]["id"]),
        ).fetchone()[0]
        assert n == 1
        role = conn.execute(
            """
            SELECT role FROM workspace_members
            WHERE workspace_id = ? AND user_id = ?
            """,
            (ctx["ws"]["id"], stranger["user"]["id"]),
        ).fetchone()[0]
        assert role == "member"
    finally:
        conn.close()

    patch = client.patch(
        "/api/workspaces/acme",
        headers=_auth(ctx["owner"]["token"]),
        json={"join_mode": "invite_only"},
    )
    assert patch.status_code == 200
    other = _register(client, "outsider2")
    blocked = client.post(
        "/api/workspaces/acme/join",
        headers=_auth(other["token"]),
        json={},
    )
    assert blocked.status_code == 403

    missing = client.post(
        "/api/workspaces/nope/join",
        headers=_auth(stranger["token"]),
        json={},
    )
    assert missing.status_code == 404


def test_channel_join_auto_onboard_and_gates(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    created = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "eng"},
    )
    assert created.status_code == 201
    channel_id = created.json()["channel"]["id"]

    stranger = ctx["stranger"]
    joined = client.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(stranger["token"]),
    )
    assert joined.status_code == 200
    assert set(joined.json()["channel"].keys()) == CH_KEYS
    detail = client.get("/api/workspaces/acme", headers=_auth(stranger["token"]))
    assert detail.status_code == 200
    again = client.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(stranger["token"]),
    )
    assert again.status_code == 200

    guest = client.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(ctx["guest"]["token"]),
    )
    assert guest.status_code == 403

    client.patch(
        "/api/workspaces/acme",
        headers=_auth(ctx["owner"]["token"]),
        json={"join_mode": "invite_only"},
    )
    outsider = _register(client, "lockedout")
    blocked = client.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(outsider["token"]),
    )
    assert blocked.status_code == 403

    priv = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "vault", "is_private": True},
    )
    assert priv.status_code == 201
    priv_id = priv.json()["channel"]["id"]
    denied = client.post(
        f"/api/channels/{priv_id}/join",
        headers=_auth(ctx["member"]["token"]),
    )
    assert denied.status_code == 403

    _seed_channel_member(
        tmp_path, channel_id=priv_id, user_id=ctx["member"]["user"]["id"]
    )
    ok = client.post(
        f"/api/channels/{priv_id}/join",
        headers=_auth(ctx["member"]["token"]),
    )
    assert ok.status_code == 200

    missing = client.post(
        f"/api/channels/{uuid.uuid4()}/join",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert missing.status_code == 404


def test_leave_idempotent(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    created = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "eng"},
    )
    channel_id = created.json()["channel"]["id"]
    client.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(ctx["member"]["token"]),
    )
    first = client.post(
        f"/api/channels/{channel_id}/leave",
        headers=_auth(ctx["member"]["token"]),
    )
    assert first.status_code == 200
    assert set(first.json()["channel"].keys()) == CH_KEYS
    second = client.post(
        f"/api/channels/{channel_id}/leave",
        headers=_auth(ctx["member"]["token"]),
    )
    assert second.status_code == 200
    conn = sqlite3.connect(str(tmp_path / "huddle.sqlite"))
    try:
        row = conn.execute(
            "SELECT 1 FROM channel_members WHERE channel_id = ? AND user_id = ?",
            (channel_id, ctx["member"]["user"]["id"]),
        ).fetchone()
        assert row is None
    finally:
        conn.close()

    detail = client.get(
        "/api/workspaces/acme", headers=_auth(ctx["owner"]["token"])
    )
    general_id = next(
        c["id"] for c in detail.json()["channels"] if c["name"] == "general"
    )
    leave_g = client.post(
        f"/api/channels/{general_id}/leave",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert leave_g.status_code == 200


def test_list_channel_members_shape(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    created = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "eng"},
    )
    channel_id = created.json()["channel"]["id"]
    client.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(ctx["member"]["token"]),
    )
    early = _register(client, "aad_user")
    client.post("/api/workspaces/acme/join", headers=_auth(early["token"]), json={})
    client.post(
        f"/api/channels/{channel_id}/join", headers=_auth(early["token"])
    )

    resp = client.get(
        f"/api/channels/{channel_id}/members",
        headers=_auth(ctx["member"]["token"]),
    )
    assert resp.status_code == 200
    members = resp.json()["members"]
    assert len(members) == 3
    for m in members:
        assert set(m.keys()) == USER_KEYS
    assert [m["username"] for m in members] == ["aad_user", "member1", "owner1"]

    priv = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["admin"]["token"]),
        json={"name": "vault", "is_private": True},
    )
    priv_id = priv.json()["channel"]["id"]
    denied = client.get(
        f"/api/channels/{priv_id}/members",
        headers=_auth(ctx["member"]["token"]),
    )
    assert denied.status_code == 403
    owner_list = client.get(
        f"/api/channels/{priv_id}/members",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert owner_list.status_code == 200


def test_patch_topic_and_archived_423(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    created = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "eng"},
    )
    channel_id = created.json()["channel"]["id"]
    client.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(ctx["member"]["token"]),
    )

    patched = client.patch(
        f"/api/channels/{channel_id}",
        headers=_auth(ctx["member"]["token"]),
        json={"topic": "Ship week", "description": "nope"},
    )
    assert patched.status_code == 200
    assert patched.json()["channel"]["topic"] == "Ship week"

    too_long = client.patch(
        f"/api/channels/{channel_id}",
        headers=_auth(ctx["member"]["token"]),
        json={"topic": "y" * 251},
    )
    assert too_long.status_code == 400

    null_topic = client.patch(
        f"/api/channels/{channel_id}",
        headers=_auth(ctx["member"]["token"]),
        json={"topic": None},
    )
    assert null_topic.status_code == 400

    client.post(
        f"/api/channels/{channel_id}/leave",
        headers=_auth(ctx["owner"]["token"]),
    )
    owner_patch = client.patch(
        f"/api/channels/{channel_id}",
        headers=_auth(ctx["owner"]["token"]),
        json={"topic": "owner topic"},
    )
    assert owner_patch.status_code == 200

    denied = client.patch(
        f"/api/channels/{channel_id}",
        headers=_auth(ctx["admin"]["token"]),
        json={"topic": "no"},
    )
    assert denied.status_code == 403

    archived = client.post(
        f"/api/channels/{channel_id}/archive",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert archived.status_code == 200
    assert archived.json()["channel"]["is_archived"] is True

    locked = client.patch(
        f"/api/channels/{channel_id}",
        headers=_auth(ctx["member"]["token"]),
        json={"topic": "locked"},
    )
    assert locked.status_code == 423
    assert locked.json()["error"]["code"] == "archived"


def test_archive_unarchive_owner_only(tmp_path: Path) -> None:
    ctx = _setup_roles(tmp_path)
    client = ctx["client"]
    created = client.post(
        "/api/workspaces/acme/channels",
        headers=_auth(ctx["owner"]["token"]),
        json={"name": "eng"},
    )
    channel_id = created.json()["channel"]["id"]

    admin = client.post(
        f"/api/channels/{channel_id}/archive",
        headers=_auth(ctx["admin"]["token"]),
    )
    assert admin.status_code == 403

    member = client.post(
        f"/api/channels/{channel_id}/archive",
        headers=_auth(ctx["member"]["token"]),
    )
    assert member.status_code == 403

    stranger = client.post(
        f"/api/channels/{channel_id}/archive",
        headers=_auth(ctx["stranger"]["token"]),
    )
    assert stranger.status_code == 404

    first = client.post(
        f"/api/channels/{channel_id}/archive",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert first.status_code == 200
    assert first.json()["channel"]["is_archived"] is True
    again = client.post(
        f"/api/channels/{channel_id}/archive",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert again.status_code == 200

    un = client.post(
        f"/api/channels/{channel_id}/unarchive",
        headers=_auth(ctx["owner"]["token"]),
    )
    assert un.status_code == 200
    assert un.json()["channel"]["is_archived"] is False


def test_cluster_create_join_members(tmp_path: Path) -> None:
    a = _client(tmp_path, node_id=0)
    b = _client(tmp_path, node_id=1)
    owner = _register(a, "ownerx")
    joiner = _register(a, "joinerx")
    ws = _create_ws(a, owner["token"], slug="shared")
    created = a.post(
        "/api/workspaces/shared/channels",
        headers=_auth(owner["token"]),
        json={"name": "eng"},
    )
    assert created.status_code == 201
    channel_id = created.json()["channel"]["id"]

    joined = a.post(
        f"/api/channels/{channel_id}/join",
        headers=_auth(joiner["token"]),
    )
    assert joined.status_code == 200

    members = b.get(
        f"/api/channels/{channel_id}/members",
        headers=_auth(owner["token"]),
    )
    assert members.status_code == 200
    ids = {m["id"] for m in members.json()["members"]}
    assert owner["user"]["id"] in ids
    assert joiner["user"]["id"] in ids
    assert ws["slug"] == "shared"


def test_migration_v3_idempotent_and_reversible(tmp_path: Path) -> None:
    sqlite_path = str(tmp_path / "mig.sqlite")
    conn = connect_and_bootstrap(sqlite_path)
    conn.execute(
        "INSERT INTO schema_migrations (version, applied_at) VALUES (0, ?)",
        ("2026-01-01T00:00:00Z",),
    )
    conn.commit()
    apply_migrations(conn)
    versions = {
        int(r[0]) for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 3 in versions
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    assert "messages" in tables
    assert "channel_pins" in tables
    msg_cols = {
        r[1] for r in conn.execute("PRAGMA table_info(messages)").fetchall()
    }
    assert {
        "id",
        "channel_id",
        "author_id",
        "body",
        "parent_id",
        "created_at",
        "edited_at",
        "deleted_at",
    } <= msg_cols
    pin_cols = {
        r[1] for r in conn.execute("PRAGMA table_info(channel_pins)").fetchall()
    }
    assert {"message_id", "channel_id", "pinned_by", "pinned_at"} <= pin_cols
    apply_migrations(conn)
    reverse_migration(conn, 3)
    versions = {
        int(r[0]) for r in conn.execute("SELECT version FROM schema_migrations")
    }
    assert 3 not in versions
    tables = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    assert "messages" not in tables
    assert "channel_pins" not in tables
    conn.close()
