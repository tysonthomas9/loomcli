/** Huddle SPA boot: token → /me → workspaces → shell or auth. */

import { api, ApiClientError } from "./api.js";
import { initAuthUi } from "./auth_ui.js";
import { initShell } from "./shell.js";
import { initSettingsUi } from "./settings_ui.js";
import { clearTokens, getToken } from "./storage.js";

const bootEl = document.getElementById("boot-placeholder");

/** @type {object|null} */
let user = null;
/** @type {string|null} */
let token = null;

function showBoot(show) {
  bootEl.hidden = !show;
}

const authUi = initAuthUi({
  onAuthenticated({ user: nextUser, token: nextToken }) {
    user = nextUser;
    token = nextToken;
    authUi.hide();
    void afterAuth();
  },
});

/** @type {ReturnType<typeof initSettingsUi>|null} */
let settingsUi = null;

const shell = initShell({
  getToken: () => token || getToken(),
  getUser: () => user,
  onLogout() {
    user = null;
    token = null;
    if (settingsUi) settingsUi.closeAll();
    shell.hideAll();
    authUi.show();
  },
  onUnauthorized() {
    clearTokens();
    user = null;
    token = null;
    if (settingsUi) settingsUi.closeAll();
    shell.hideAll();
    authUi.show();
  },
  onWorkspaceChanged() {
    if (settingsUi) settingsUi.closeAll();
  },
});

settingsUi = initSettingsUi({
  getToken: () => token || getToken(),
  getUser: () => user,
  onUnauthorized() {
    clearTokens();
    user = null;
    token = null;
    settingsUi.closeAll();
    shell.hideAll();
    authUi.show();
  },
  getWorkspace: () => shell.getWorkspace(),
  getActiveChannel: () => shell.getActiveChannel(),
  getCallerRole: () => shell.getCallerRole(),
  setCallerRole: (role) => shell.setCallerRole(role),
  refreshWorkspaceDetail: () => shell.refreshWorkspaceDetail(),
  enterWorkspace: (slug) => shell.enterWorkspace(slug),
  showShell: (workspace, channels) => shell.showShell(workspace, channels),
  updateWorkspaceHeader: (workspace) => shell.updateWorkspaceHeader(workspace),
  replaceChannels: (channels) => shell.replaceChannels(channels),
  clearActiveChannel: () => shell.clearActiveChannel(),
});

async function afterAuth() {
  showBoot(true);
  try {
    await shell.loadAndPresent();
  } catch (err) {
    if (err instanceof ApiClientError && err.status === 401) {
      clearTokens();
      user = null;
      token = null;
      shell.hideAll();
      authUi.show();
      return;
    }
    shell.showOnboarding();
  } finally {
    showBoot(false);
  }
}

async function boot() {
  showBoot(true);
  authUi.hide();
  shell.hideAll();

  token = getToken();
  if (!token) {
    showBoot(false);
    authUi.show();
    return;
  }

  try {
    const data = await api("GET", "/api/auth/me", { token });
    user = data.user;
    await shell.loadAndPresent();
  } catch (err) {
    if (err instanceof ApiClientError && err.status === 401) {
      clearTokens();
      user = null;
      token = null;
      authUi.show();
    } else {
      user = null;
      authUi.show();
    }
  } finally {
    showBoot(false);
  }
}

void boot();
