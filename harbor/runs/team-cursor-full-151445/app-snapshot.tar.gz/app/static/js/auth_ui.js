/** Auth modal: register (default) / login toggle, submit, visible errors. */

import { api, ApiClientError } from "./api.js";
import { setToken } from "./storage.js";

const USERNAME_RE = /^[a-z0-9][a-z0-9_-]{1,31}$/;

/**
 * @param {{ onAuthenticated: (payload: { user: object, token: string }) => void }} handlers
 */
export function initAuthUi(handlers) {
  const modal = document.getElementById("auth-modal");
  const form = document.getElementById("auth-form");
  const toggle = document.getElementById("auth-toggle");
  const submit = form.querySelector('[data-testid="auth-submit"]');
  const errorEl = document.getElementById("auth-error");
  const subtitle = document.getElementById("auth-subtitle");
  const displayField = document.getElementById("auth-display-name-field");
  const usernameInput = form.querySelector('[data-testid="auth-username"]');
  const passwordInput = form.querySelector('[data-testid="auth-password"]');
  const displayInput = form.querySelector('[data-testid="auth-display-name"]');

  /** @type {"register" | "login"} */
  let mode = "register";

  function setMode(next) {
    mode = next;
    const isRegister = mode === "register";
    subtitle.textContent = isRegister ? "Create your account" : "Welcome back";
    submit.textContent = isRegister ? "Sign up" : "Log in";
    toggle.textContent = isRegister
      ? "Already have an account? Log in"
      : "Need an account? Sign up";
    displayField.hidden = !isRegister;
    passwordInput.autocomplete = isRegister ? "new-password" : "current-password";
    clearError();
  }

  function clearError() {
    errorEl.textContent = "";
    errorEl.hidden = true;
  }

  function showError(message) {
    errorEl.textContent = message;
    errorEl.hidden = false;
  }

  function clientValidate(username, password) {
    if (!username) return "username is required";
    if (mode === "register" && !USERNAME_RE.test(username)) {
      return "invalid username";
    }
    if (!password) return "password is required";
    if (mode === "register") {
      if (password.length < 8) return "password must be at least 8 characters";
      if (password.length > 128) return "password must be at most 128 characters";
    }
    return null;
  }

  toggle.addEventListener("click", () => {
    setMode(mode === "register" ? "login" : "register");
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearError();

    const username = usernameInput.value.trim();
    const password = passwordInput.value;
    const displayName = displayInput.value.trim();

    const clientError = clientValidate(username, password);
    if (clientError) {
      showError(clientError);
      return;
    }

    submit.disabled = true;
    try {
      let data;
      if (mode === "register") {
        const body = { username, password };
        if (displayName) body.display_name = displayName;
        data = await api("POST", "/api/auth/register", { body });
      } else {
        data = await api("POST", "/api/auth/login", {
          body: { username, password },
        });
      }
      const token = data && data.token;
      const user = data && data.user;
      if (!token || !user) {
        showError("Unexpected server response");
        return;
      }
      setToken(token);
      form.reset();
      clearError();
      handlers.onAuthenticated({ user, token });
    } catch (err) {
      const message =
        err instanceof ApiClientError
          ? err.message
          : "Something went wrong. Please try again.";
      showError(message);
    } finally {
      submit.disabled = false;
    }
  });

  return {
    show() {
      setMode(mode);
      modal.hidden = false;
    },
    hide() {
      modal.hidden = true;
      clearError();
    },
    setMode,
    showError,
  };
}
