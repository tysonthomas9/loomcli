/** Workspace onboarding + three-pane shell chrome. */

import { api, ApiClientError } from "./api.js";
import {
  clearTokens,
  clearWorkspaceSlug,
  getWorkspaceSlug,
  setWorkspaceSlug,
} from "./storage.js";

/**
 * @param {{
 *   getToken: () => string|null,
 *   getUser: () => object|null,
 *   onLogout: () => void,
 *   onUnauthorized: () => void,
 *   onWorkspaceChanged?: () => void,
 * }} ctx
 */
export function initShell(ctx) {
  const onboarding = document.getElementById("onboarding");
  const shell = document.getElementById("shell");
  const sessionChrome = document.getElementById("session-chrome");
  const sessionUser = document.getElementById("session-user");
  const logoutBtn = document.getElementById("logout-btn");
  const onboardingSlot = document.getElementById("onboarding-session-slot");
  const shellSlot = document.getElementById("shell-session-slot");
  const workspaceHeaderLabel = document.getElementById("workspace-header-label");
  const workspaceSettingsBtn = document.querySelector(
    '[data-testid="workspace-settings-btn"]'
  );
  const channelList = document.getElementById("channel-list");
  const dmsList = document.getElementById("dms-list");
  const createForm = document.getElementById("workspace-create-form");
  const createError = document.getElementById("workspace-create-error");
  const createSubmit = createForm.querySelector(
    '[data-testid="workspace-create-submit"]'
  );
  const joinForm = document.getElementById("join-workspace-form");
  const joinError = document.getElementById("join-workspace-error");
  const joinSubmit = joinForm.querySelector(
    '[data-testid="join-workspace-submit"]'
  );
  const emptyState = document.getElementById("empty-state-create-workspace");
  const threadPanel = document.getElementById("thread-panel");
  const messagePaneHeader = document.getElementById("message-pane-header");
  const messagePaneTitle = document.getElementById("message-pane-title");
  const channelSettingsBtn = document.querySelector(
    '[data-testid="channel-settings-btn"]'
  );
  const messagePanePlaceholder = document.querySelector(
    ".message-pane__placeholder"
  );

  /** @type {object|null} */
  let currentWorkspace = null;
  /** @type {object[]} */
  let channels = [];
  /** @type {object|null} */
  let activeChannel = null;
  /** @type {string|null} */
  let callerRole = null;

  function userLabel(user) {
    if (!user) return "";
    return user.display_name || user.username || "";
  }

  function placeSessionChrome(target) {
    sessionChrome.hidden = false;
    target.appendChild(sessionUser);
    target.appendChild(logoutBtn);
  }

  function updateSessionUser() {
    sessionUser.textContent = userLabel(ctx.getUser());
  }

  function hideAll() {
    onboarding.hidden = true;
    shell.hidden = true;
  }

  function setHash(slug) {
    const next = slug ? `#/w/${encodeURIComponent(slug)}` : "#/";
    if (location.hash !== next) {
      location.hash = next;
    }
  }

  function parseHashSlug() {
    const match = /^#\/w\/([^/]+)$/.exec(location.hash || "");
    if (!match) return null;
    try {
      return decodeURIComponent(match[1]);
    } catch {
      return match[1];
    }
  }

  function showCreateError(message) {
    createError.textContent = message;
    createError.hidden = false;
  }

  function clearCreateError() {
    createError.textContent = "";
    createError.hidden = true;
  }

  function showJoinError(message) {
    joinError.textContent = message;
    joinError.hidden = false;
  }

  function clearJoinError() {
    joinError.textContent = "";
    joinError.hidden = true;
  }

  function updateWorkspaceHeader(workspace) {
    if (workspace) {
      currentWorkspace = { ...currentWorkspace, ...workspace };
    }
    const w = currentWorkspace;
    if (!w) {
      workspaceHeaderLabel.textContent = "";
      workspaceSettingsBtn.hidden = true;
      return;
    }
    workspaceHeaderLabel.textContent = w.name
      ? `${w.name} (${w.slug})`
      : w.slug;
    workspaceSettingsBtn.hidden = false;
  }

  function clearActiveChannel() {
    activeChannel = null;
    messagePaneHeader.hidden = true;
    channelSettingsBtn.hidden = true;
    if (messagePanePlaceholder) messagePanePlaceholder.hidden = false;
    channelList
      .querySelectorAll("button.is-active")
      .forEach((b) => b.classList.remove("is-active"));
    dmsList
      .querySelectorAll("button.is-active")
      .forEach((b) => b.classList.remove("is-active"));
  }

  function setActiveChannel(channel) {
    activeChannel = channel;
    channelList
      .querySelectorAll("button.is-active")
      .forEach((b) => b.classList.remove("is-active"));
    dmsList
      .querySelectorAll("button.is-active")
      .forEach((b) => b.classList.remove("is-active"));

    if (!channel) {
      clearActiveChannel();
      return;
    }

    const list = channel.is_dm ? dmsList : channelList;
    const btn = list.querySelector(
      `button[data-channel-id="${CSS.escape(channel.id)}"]`
    );
    if (btn) btn.classList.add("is-active");

    messagePaneHeader.hidden = false;
    messagePaneTitle.textContent = channel.is_dm
      ? channel.name
      : `#${channel.name}`;
    channelSettingsBtn.hidden = !!channel.is_dm;
    if (messagePanePlaceholder) messagePanePlaceholder.hidden = true;
  }

  function renderChannelLists(channelObjs) {
    channelList.replaceChildren();
    dmsList.replaceChildren();
    for (const ch of channelObjs) {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.dataset.channelId = ch.id;
      btn.dataset.channelName = ch.name;
      btn.setAttribute("data-channel-id", ch.id);
      btn.setAttribute("data-channel-name", ch.name);
      if (ch.is_dm) {
        btn.textContent = ch.name;
        dmsList.appendChild(li);
      } else {
        btn.textContent = `#${ch.name}`;
        channelList.appendChild(li);
      }
      btn.addEventListener("click", () => {
        setActiveChannel(ch);
      });
      li.appendChild(btn);
    }
    if (activeChannel) {
      const still = channelObjs.find((c) => c.id === activeChannel.id);
      if (still) setActiveChannel(still);
      else clearActiveChannel();
    }
  }

  function replaceChannels(channelObjs) {
    channels = channelObjs || [];
    renderChannelLists(channels);
  }

  function showShell(workspace, channelObjs) {
    const prevSlug = currentWorkspace && currentWorkspace.slug;
    currentWorkspace = workspace;
    channels = channelObjs || [];
    callerRole = null;
    hideAll();
    updateSessionUser();
    placeSessionChrome(shellSlot);
    updateWorkspaceHeader(workspace);
    if (prevSlug && prevSlug !== workspace.slug) {
      clearActiveChannel();
      if (typeof ctx.onWorkspaceChanged === "function") {
        ctx.onWorkspaceChanged();
      }
    }
    renderChannelLists(channels);
    threadPanel.hidden = true;
    threadPanel.setAttribute("aria-hidden", "true");
    shell.hidden = false;
    setHash(workspace.slug);
  }

  function showOnboarding() {
    currentWorkspace = null;
    channels = [];
    callerRole = null;
    clearActiveChannel();
    hideAll();
    updateSessionUser();
    placeSessionChrome(onboardingSlot);
    clearCreateError();
    clearJoinError();
    emptyState.hidden = false;
    onboarding.hidden = false;
    workspaceSettingsBtn.hidden = true;
    setHash(null);
    if (typeof ctx.onWorkspaceChanged === "function") {
      ctx.onWorkspaceChanged();
    }
  }

  async function fetchWorkspaceDetail(slug) {
    const token = ctx.getToken();
    const data = await api("GET", `/api/workspaces/${encodeURIComponent(slug)}`, {
      token,
    });
    return data;
  }

  async function enterWorkspace(slug) {
    try {
      const data = await fetchWorkspaceDetail(slug);
      const workspace = data.workspace;
      setWorkspaceSlug(workspace.slug);
      showShell(workspace, data.channels || []);
      return true;
    } catch (err) {
      if (err instanceof ApiClientError && err.status === 401) {
        ctx.onUnauthorized();
        return false;
      }
      if (err instanceof ApiClientError && err.status === 404) {
        clearWorkspaceSlug();
        return false;
      }
      throw err;
    }
  }

  async function refreshWorkspaceDetail() {
    if (!currentWorkspace) return null;
    try {
      const data = await fetchWorkspaceDetail(currentWorkspace.slug);
      currentWorkspace = data.workspace;
      channels = data.channels || [];
      updateWorkspaceHeader(currentWorkspace);
      renderChannelLists(channels);
      return data;
    } catch (err) {
      if (err instanceof ApiClientError && err.status === 401) {
        ctx.onUnauthorized();
        return null;
      }
      throw err;
    }
  }

  /**
   * After auth: list workspaces, restore slug or show empty state.
   * @param {object[]} workspaces
   */
  async function presentWorkspaces(workspaces) {
    updateSessionUser();
    if (!workspaces || workspaces.length === 0) {
      showOnboarding();
      return;
    }

    const stored = getWorkspaceSlug();
    const hashSlug = parseHashSlug();
    const preferred =
      (hashSlug && workspaces.find((w) => w.slug === hashSlug)) ||
      (stored && workspaces.find((w) => w.slug === stored)) ||
      workspaces[0];

    const ok = await enterWorkspace(preferred.slug);
    if (!ok) {
      const remaining = workspaces.filter((w) => w.slug !== preferred.slug);
      if (remaining.length === 0) {
        showOnboarding();
        return;
      }
      const second = await enterWorkspace(remaining[0].slug);
      if (!second) showOnboarding();
    }
  }

  async function loadAndPresent() {
    const token = ctx.getToken();
    const data = await api("GET", "/api/workspaces", { token });
    await presentWorkspaces(data.workspaces || []);
  }

  logoutBtn.addEventListener("click", () => {
    clearTokens();
    currentWorkspace = null;
    channels = [];
    callerRole = null;
    clearActiveChannel();
    hideAll();
    sessionChrome.hidden = true;
    workspaceSettingsBtn.hidden = true;
    document.body.appendChild(sessionChrome);
    sessionChrome.appendChild(sessionUser);
    sessionChrome.appendChild(logoutBtn);
    if (typeof ctx.onWorkspaceChanged === "function") {
      ctx.onWorkspaceChanged();
    }
    ctx.onLogout();
  });

  createForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearCreateError();
    const slug = createForm.elements.slug.value.trim();
    const name = createForm.elements.name.value.trim();
    if (!slug || !name) {
      showCreateError("slug and name are required");
      return;
    }
    createSubmit.disabled = true;
    try {
      const data = await api("POST", "/api/workspaces", {
        token: ctx.getToken(),
        body: { slug, name },
      });
      const workspace = data.workspace;
      setWorkspaceSlug(workspace.slug);
      const entered = await enterWorkspace(workspace.slug);
      if (!entered) {
        const channelsGuess = data.general_channel
          ? [data.general_channel]
          : [];
        showShell(workspace, channelsGuess);
      }
      createForm.reset();
    } catch (err) {
      if (err instanceof ApiClientError && err.status === 401) {
        ctx.onUnauthorized();
        return;
      }
      const message =
        err instanceof ApiClientError
          ? err.message
          : "Could not create workspace";
      showCreateError(message);
    } finally {
      createSubmit.disabled = false;
    }
  });

  joinForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearJoinError();
    const slug = joinForm.elements.slug.value.trim();
    if (!slug) {
      showJoinError("workspace slug is required");
      return;
    }
    joinSubmit.disabled = true;
    try {
      const data = await api(
        "POST",
        `/api/workspaces/${encodeURIComponent(slug)}/join`,
        { token: ctx.getToken(), body: {} }
      );
      const workspace = data.workspace;
      if (!workspace || !workspace.slug) {
        showJoinError("Unexpected server response");
        return;
      }
      setWorkspaceSlug(workspace.slug);
      if (data.channels) {
        showShell(workspace, data.channels);
      } else {
        const ok = await enterWorkspace(workspace.slug);
        if (!ok) showShell(workspace, []);
      }
      joinForm.reset();
    } catch (err) {
      if (err instanceof ApiClientError && err.status === 401) {
        ctx.onUnauthorized();
        return;
      }
      const message =
        err instanceof ApiClientError
          ? err.message
          : "Could not join workspace";
      showJoinError(message);
    } finally {
      joinSubmit.disabled = false;
    }
  });

  emptyState.addEventListener("click", () => {
    createForm.querySelector('[data-testid="workspace-slug"]').focus();
  });

  window.addEventListener("hashchange", async () => {
    if (!ctx.getToken() || !ctx.getUser()) return;
    const slug = parseHashSlug();
    if (!slug) return;
    if (currentWorkspace && currentWorkspace.slug === slug) return;
    try {
      await enterWorkspace(slug);
    } catch {
      // Ignore navigation failures; stay on current view.
    }
  });

  return {
    showOnboarding,
    showShell,
    presentWorkspaces,
    loadAndPresent,
    enterWorkspace,
    refreshWorkspaceDetail,
    updateSessionUser,
    updateWorkspaceHeader,
    replaceChannels,
    clearActiveChannel,
    setActiveChannel,
    hideAll,
    getWorkspace: () => currentWorkspace,
    getActiveChannel: () => activeChannel,
    getCallerRole: () => callerRole,
    setCallerRole: (role) => {
      callerRole = role;
    },
  };
}
