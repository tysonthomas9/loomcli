/** Same-origin JSON API client with bearer auth and error envelope parsing. */

const DEFAULT_TIMEOUT_MS = 15000;

export class ApiClientError extends Error {
  constructor(status, code, message, body) {
    super(message);
    this.name = "ApiClientError";
    this.status = status;
    this.code = code;
    this.body = body;
  }
}

/**
 * @param {string} method
 * @param {string} path - absolute path e.g. /api/auth/login
 * @param {{ token?: string|null, body?: unknown, timeoutMs?: number }} [opts]
 */
export async function api(method, path, opts = {}) {
  const { token = null, body = undefined, timeoutMs = DEFAULT_TIMEOUT_MS } = opts;
  const headers = {};
  if (body !== undefined) {
    headers["Content-Type"] = "application/json";
  }
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let response;
  try {
    response = await fetch(path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    if (err && err.name === "AbortError") {
      throw new ApiClientError(0, "timeout", "Request timed out", null);
    }
    throw new ApiClientError(0, "network_error", "Network request failed", null);
  } finally {
    clearTimeout(timer);
  }

  let data = null;
  const text = await response.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }

  if (!response.ok) {
    const envelope = data && data.error;
    const code = (envelope && envelope.code) || "http_error";
    const message =
      (envelope && envelope.message) ||
      `Request failed (${response.status})`;
    throw new ApiClientError(response.status, code, message, data);
  }

  return data;
}
