/** Browser storage for bearer token and last workspace slug. */

const TOKEN_PRIMARY = "huddle.token";
const TOKEN_FALLBACKS = ["huddle_token", "token"];
const WORKSPACE_SLUG_KEY = "huddle.workspaceSlug";

function nonEmpty(value) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

/** Read bearer: huddle.token, then huddle_token, then token. */
export function getToken() {
  const primary = nonEmpty(localStorage.getItem(TOKEN_PRIMARY));
  if (primary) return primary;
  for (const key of TOKEN_FALLBACKS) {
    const value = nonEmpty(localStorage.getItem(key));
    if (value) return value;
  }
  return null;
}

/** Write canonical huddle.token; drop stale fallbacks. */
export function setToken(token) {
  localStorage.setItem(TOKEN_PRIMARY, token);
  for (const key of TOKEN_FALLBACKS) {
    localStorage.removeItem(key);
  }
}

/** Clear all accepted token keys (logout / 401). Keeps workspace slug. */
export function clearTokens() {
  localStorage.removeItem(TOKEN_PRIMARY);
  for (const key of TOKEN_FALLBACKS) {
    localStorage.removeItem(key);
  }
}

export function getWorkspaceSlug() {
  return nonEmpty(localStorage.getItem(WORKSPACE_SLUG_KEY));
}

export function setWorkspaceSlug(slug) {
  localStorage.setItem(WORKSPACE_SLUG_KEY, slug);
}

export function clearWorkspaceSlug() {
  localStorage.removeItem(WORKSPACE_SLUG_KEY);
}
