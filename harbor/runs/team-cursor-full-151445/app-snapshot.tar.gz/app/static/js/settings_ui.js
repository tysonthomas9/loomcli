/** Workspace + channel settings modals. */

import { api, ApiClientError } from "./api.js";
import { setWorkspaceSlug } from "./storage.js";

/**
 * @param {{
 *   getToken: () => string|null,
 *   getUser: () => object|null,
 *   onUnauthorized: () => void,
 *   getWorkspace: () => object|null,
 *   getActiveChannel: () => object|null,
 *   getCallerRole: () => string|null,
 *   setCallerRole: (role: string|null) => void,
 *   refreshWorkspaceDetail: () => Promise<object|null>,
 *   enterWorkspace: (slug: string) => Promise<boolean>,
 *   showShell: (workspace: object, channels: object[]) => void,
 *   updateWorkspaceHeader: (workspace: object) => void,
 *   replaceChannels: (channels: object[]) => void,
 *   clearActiveChannel: () => void,
 * }} ctx
 */
export function initSettingsUi(ctx) {
  const wsModal = document.getElementById("workspace-settings-modal");
  const chModal = document.getElementById("channel-settings-modal");
  const wsClose = wsModal.querySelector('[data-testid="workspace-settings-close"]');
  const chClose = chModal.querySelector('[data-testid="channel-settings-close"]');
  const wsSettingsBtn = document.querySelector(
    '[data-testid="workspace-settings-btn"]'
  );
  const chSettingsBtn = document.querySelector(
    '[data-testid="channel-settings-btn"]'
  );

  const tabs = {
    general: document.querySelector('[data-testid="settings-tab-general"]'),
    members: document.querySelector('[data-testid="settings-tab-members"]'),
    invitations: document.querySelector(
      '[data-testid="settings-tab-invitations"]'
    ),
  };
  const panels = {
    general: document.querySelector('[data-testid="settings-panel-general"]'),
    members: document.querySelector('[data-testid="settings-panel-members"]'),
    invitations: document.querySelector(
      '[data-testid="settings-panel-invitations"]'
    ),
  };

  const nameInput = document.querySelector('[data-testid="settings-name"]');
  const joinModeSelect = document.querySelector(
    '[data-testid="settings-join-mode"]'
  );
  const generalForm = document.getElementById("settings-general-form");
  const generalSave = document.querySelector(
    '[data-testid="settings-general-save"]'
  );
  const generalError = document.querySelector(
    '[data-testid="settings-general-error"]'
  );
  const generalSuccess = document.querySelector(
    '[data-testid="settings-general-success"]'
  );

  const membersList = document.querySelector(
    '[data-testid="settings-members-list"]'
  );
  const membersError = document.querySelector(
    '[data-testid="settings-members-error"]'
  );
  const membersLoading = document.querySelector(
    '[data-testid="settings-members-loading"]'
  );
  const transferBlock = document.querySelector(
    '[data-testid="settings-transfer-owner"]'
  );
  const transferSelect = document.querySelector(
    '[data-testid="settings-transfer-owner-select"]'
  );
  const transferSubmit = document.querySelector(
    '[data-testid="settings-transfer-owner-submit"]'
  );
  const transferError = document.querySelector(
    '[data-testid="settings-transfer-error"]'
  );

  const inviteForm = document.getElementById("create-invitation-form");
  const inviteCreateError = document.querySelector(
    '[data-testid="invitation-create-error"]'
  );
  const inviteListError = document.querySelector(
    '[data-testid="invitation-list-error"]'
  );
  const inviteList = document.querySelector('[data-testid="invitation-list"]');
  const inviteAdminOnly = document.getElementById("invitations-admin-only");
  const inviteCreateSubmit = document.querySelector(
    '[data-testid="invitation-create-submit"]'
  );

  const acceptForm = document.getElementById("invitation-accept-form");
  const acceptError = document.querySelector(
    '[data-testid="invitation-accept-error"]'
  );
  const acceptSubmit = document.querySelector(
    '[data-testid="invitation-accept-submit"]'
  );

  const topicInput = document.querySelector('[data-testid="settings-topic"]');
  const topicSave = document.querySelector('[data-testid="settings-topic-save"]');
  const topicError = document.querySelector('[data-testid="settings-topic-error"]');
  const archiveBtn = document.querySelector('[data-testid="settings-archive"]');
  const unarchiveBtn = document.querySelector(
    '[data-testid="settings-unarchive"]'
  );
  const archiveError = document.querySelector(
    '[data-testid="settings-archive-error"]'
  );
  const channelMembersList = document.querySelector(
    '[data-testid="channel-members-list"]'
  );
  const channelMembersError = document.querySelector(
    '[data-testid="channel-members-error"]'
  );
  const addMemberForm = document.getElementById("channel-add-member-form");
  const addMemberInput = document.querySelector(
    '[data-testid="channel-add-member-input"]'
  );
  const addMemberSubmit = document.querySelector(
    '[data-testid="channel-add-member-submit"]'
  );
  const addMemberError = document.querySelector(
    '[data-testid="channel-add-member-error"]'
  );

  /** @type {object[]} */
  let workspaceMembers = [];
  /** @type {object[]} */
  let invitations = [];
  /** @type {object[]} */
  let channelMembers = [];
  /** @type {object|null} */
  let channelSettingsChannel = null;
  /** @type {"general"|"members"|"invitations"} */
  let activeTab = "general";

  function token() {
    return ctx.getToken();
  }

  function handleAuthError(err) {
    if (err instanceof ApiClientError && err.status === 401) {
      closeAll();
      ctx.onUnauthorized();
      return true;
    }
    return false;
  }

  function showEl(el, message) {
    if (!el) return;
    el.textContent = message || "";
    el.hidden = !message;
  }

  function clearEl(el) {
    showEl(el, "");
  }

  function closeWorkspaceModal() {
    wsModal.hidden = true;
  }

  function closeChannelModal() {
    chModal.hidden = true;
    channelSettingsChannel = null;
  }

  function closeAll() {
    closeWorkspaceModal();
    closeChannelModal();
  }

  function setTab(name) {
    activeTab = name;
    for (const [key, tab] of Object.entries(tabs)) {
      const selected = key === name;
      tab.setAttribute("aria-selected", selected ? "true" : "false");
      panels[key].hidden = !selected;
    }
    if (name === "members") void loadMembers();
    if (name === "invitations") void loadInvitations();
  }

  function canEditGeneral(role) {
    return role === "owner" || role === "admin";
  }

  function canManageInvites(role) {
    return role === "owner" || role === "admin";
  }

  function canEditRole(actorRole, targetRole) {
    if (targetRole === "owner") return false;
    if (actorRole === "owner") return true;
    if (actorRole === "admin") return targetRole === "member" || targetRole === "guest";
    return false;
  }

  function seedGeneralForm(workspace) {
    nameInput.value = workspace.name || "";
    joinModeSelect.value =
      workspace.join_mode === "invite_only" ? "invite_only" : "open";
    clearEl(generalError);
    clearEl(generalSuccess);
    const role = ctx.getCallerRole();
    const editable = canEditGeneral(role);
    nameInput.disabled = !editable;
    joinModeSelect.disabled = !editable;
    generalSave.disabled = !editable;
  }

  async function openWorkspaceSettings() {
    const workspace = ctx.getWorkspace();
    if (!workspace) return;
    closeChannelModal();
    setTab("general");
    // Disable privileged controls until role is known.
    nameInput.disabled = true;
    joinModeSelect.disabled = true;
    generalSave.disabled = true;
    nameInput.value = workspace.name || "";
    joinModeSelect.value =
      workspace.join_mode === "invite_only" ? "invite_only" : "open";
    clearEl(generalError);
    clearEl(generalSuccess);
    wsModal.hidden = false;
    await loadMembers({ quiet: true });
    seedGeneralForm(ctx.getWorkspace() || workspace);
  }

  async function loadMembers(opts = {}) {
    const workspace = ctx.getWorkspace();
    if (!workspace) return;
    clearEl(membersError);
    if (!opts.quiet) membersLoading.hidden = false;
    try {
      const data = await api(
        "GET",
        `/api/workspaces/${encodeURIComponent(workspace.slug)}/members`,
        { token: token() }
      );
      workspaceMembers = data.members || [];
      const me = ctx.getUser();
      const mine = workspaceMembers.find((m) => me && m.user_id === me.id);
      ctx.setCallerRole(mine ? mine.role : null);
      renderMembers();
      renderTransfer();
    } catch (err) {
      if (handleAuthError(err)) return;
      if (err instanceof ApiClientError && err.status === 404) {
        closeAll();
        return;
      }
      showEl(
        membersError,
        err instanceof ApiClientError ? err.message : "Could not load members"
      );
    } finally {
      membersLoading.hidden = true;
    }
  }

  function renderMembers() {
    membersList.replaceChildren();
    const actorRole = ctx.getCallerRole();
    for (const member of workspaceMembers) {
      const li = document.createElement("li");
      li.className = "settings-member-row";
      li.setAttribute("data-testid", "settings-member-row");
      li.setAttribute("data-user-id", member.user_id);

      const left = document.createElement("div");
      const name = document.createElement("span");
      name.textContent =
        member.display_name || member.username || member.user_id;
      left.appendChild(name);

      const badge = document.createElement("span");
      badge.setAttribute("data-testid", "role-badge");
      badge.className = "role-badge";
      badge.textContent = member.role;
      left.appendChild(document.createTextNode(" "));
      left.appendChild(badge);

      li.appendChild(left);

      if (canEditRole(actorRole, member.role)) {
        const select = document.createElement("select");
        select.setAttribute("data-testid", "role-select");
        select.className = "role-select";
        for (const role of ["admin", "member", "guest"]) {
          const opt = document.createElement("option");
          opt.value = role;
          opt.textContent = role;
          if (role === member.role) opt.selected = true;
          select.appendChild(opt);
        }
        select.addEventListener("change", () => {
          void patchMemberRole(member.user_id, select.value, select, member.role);
        });
        li.appendChild(select);
      }

      membersList.appendChild(li);
    }
  }

  function renderTransfer() {
    const actorRole = ctx.getCallerRole();
    if (actorRole !== "owner") {
      transferBlock.hidden = true;
      return;
    }
    transferBlock.hidden = false;
    clearEl(transferError);
    transferSelect.replaceChildren();
    const admins = workspaceMembers.filter((m) => m.role === "admin");
    if (admins.length === 0) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "No admins available";
      transferSelect.appendChild(opt);
      transferSubmit.disabled = true;
      return;
    }
    transferSubmit.disabled = false;
    for (const admin of admins) {
      const opt = document.createElement("option");
      opt.value = admin.user_id;
      opt.textContent = admin.display_name || admin.username || admin.user_id;
      transferSelect.appendChild(opt);
    }
  }

  async function patchMemberRole(userId, newRole, selectEl, previousRole) {
    const workspace = ctx.getWorkspace();
    if (!workspace) return;
    clearEl(membersError);
    selectEl.disabled = true;
    try {
      await api(
        "PATCH",
        `/api/workspaces/${encodeURIComponent(workspace.slug)}/members/${encodeURIComponent(userId)}`,
        { token: token(), body: { role: newRole } }
      );
      await loadMembers({ quiet: true });
    } catch (err) {
      if (handleAuthError(err)) return;
      selectEl.value = previousRole;
      showEl(
        membersError,
        err instanceof ApiClientError ? err.message : "Could not update role"
      );
    } finally {
      selectEl.disabled = false;
    }
  }

  async function loadInvitations() {
    const workspace = ctx.getWorkspace();
    if (!workspace) return;
    clearEl(inviteListError);
    clearEl(inviteCreateError);
    const role = ctx.getCallerRole();
    if (!canManageInvites(role)) {
      inviteForm.hidden = true;
      inviteAdminOnly.hidden = false;
      inviteList.replaceChildren();
      return;
    }
    inviteForm.hidden = false;
    inviteAdminOnly.hidden = true;
    try {
      const data = await api(
        "GET",
        `/api/workspaces/${encodeURIComponent(workspace.slug)}/invitations`,
        { token: token() }
      );
      invitations = data.invitations || [];
      renderInvitations();
    } catch (err) {
      if (handleAuthError(err)) return;
      if (err instanceof ApiClientError && err.status === 403) {
        inviteForm.hidden = true;
        inviteAdminOnly.hidden = false;
        showEl(inviteListError, err.message);
        return;
      }
      showEl(
        inviteListError,
        err instanceof ApiClientError
          ? err.message
          : "Could not load invitations"
      );
    }
  }

  function renderInvitations() {
    inviteList.replaceChildren();
    for (const inv of invitations) {
      const li = document.createElement("li");
      li.className = "invitation-row";
      li.setAttribute("data-testid", "invitation-row");
      li.setAttribute("data-invitation-code", inv.code);
      if (inv.id) li.setAttribute("data-invitation-id", inv.id);

      const codeEl = document.createElement("span");
      codeEl.setAttribute("data-testid", "invitation-code");
      codeEl.className = "invitation-code";
      codeEl.textContent = inv.code;
      li.appendChild(codeEl);

      const revoke = document.createElement("button");
      revoke.type = "button";
      revoke.className = "btn btn-ghost";
      revoke.setAttribute("data-testid", "invitation-revoke");
      revoke.textContent = "Revoke";
      revoke.addEventListener("click", () => {
        void revokeInvitation(inv.code);
      });
      li.appendChild(revoke);

      inviteList.appendChild(li);
    }
  }

  async function revokeInvitation(code) {
    clearEl(inviteListError);
    try {
      await api("DELETE", `/api/invitations/${encodeURIComponent(code)}`, {
        token: token(),
      });
      invitations = invitations.filter((i) => i.code !== code);
      renderInvitations();
    } catch (err) {
      if (handleAuthError(err)) return;
      if (err instanceof ApiClientError && err.status === 404) {
        await loadInvitations();
        return;
      }
      showEl(
        inviteListError,
        err instanceof ApiClientError ? err.message : "Could not revoke"
      );
    }
  }

  function updateArchiveButtons(channel) {
    const role = ctx.getCallerRole();
    const isOwner = role === "owner";
    if (!isOwner) {
      archiveBtn.hidden = true;
      unarchiveBtn.hidden = true;
      return;
    }
    if (channel.is_archived) {
      archiveBtn.hidden = true;
      unarchiveBtn.hidden = false;
    } else {
      archiveBtn.hidden = false;
      unarchiveBtn.hidden = true;
    }
  }

  function renderChannelMembers() {
    channelMembersList.replaceChildren();
    for (const user of channelMembers) {
      const li = document.createElement("li");
      li.className = "channel-member-row";
      li.setAttribute("data-testid", "channel-member-row");
      li.setAttribute("data-user-id", user.id);
      li.textContent = user.display_name || user.username || user.id;
      channelMembersList.appendChild(li);
    }
  }

  async function loadChannelMembers(channelId) {
    clearEl(channelMembersError);
    try {
      const data = await api(
        "GET",
        `/api/channels/${encodeURIComponent(channelId)}/members`,
        { token: token() }
      );
      channelMembers = data.members || [];
      renderChannelMembers();
    } catch (err) {
      if (handleAuthError(err)) return;
      showEl(
        channelMembersError,
        err instanceof ApiClientError
          ? err.message
          : "Could not load channel members"
      );
    }
  }

  async function openChannelSettings(channel) {
    if (!channel || channel.is_dm) return;
    closeWorkspaceModal();
    channelSettingsChannel = { ...channel };
    topicInput.value = channel.topic || "";
    topicInput.disabled = !!channel.is_archived;
    topicSave.disabled = !!channel.is_archived;
    clearEl(topicError);
    clearEl(archiveError);
    clearEl(addMemberError);
    clearEl(channelMembersError);
    addMemberInput.value = "";
    updateArchiveButtons(channel);
    chModal.hidden = false;
    // Ensure caller role is known for archive visibility.
    if (!ctx.getCallerRole()) {
      await loadMembers({ quiet: true });
      updateArchiveButtons(channelSettingsChannel);
    }
    await loadChannelMembers(channel.id);
  }

  // --- Event wiring ---

  wsSettingsBtn.addEventListener("click", () => {
    void openWorkspaceSettings();
  });

  chSettingsBtn.addEventListener("click", () => {
    const channel = ctx.getActiveChannel();
    if (channel) void openChannelSettings(channel);
  });

  wsClose.addEventListener("click", closeWorkspaceModal);
  chClose.addEventListener("click", closeChannelModal);

  wsModal.addEventListener("click", (event) => {
    if (event.target === wsModal) closeWorkspaceModal();
  });
  chModal.addEventListener("click", (event) => {
    if (event.target === chModal) closeChannelModal();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (!wsModal.hidden) closeWorkspaceModal();
    else if (!chModal.hidden) closeChannelModal();
  });

  for (const [name, tab] of Object.entries(tabs)) {
    tab.addEventListener("click", () => setTab(/** @type {any} */ (name)));
  }

  generalForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const workspace = ctx.getWorkspace();
    if (!workspace) return;
    clearEl(generalError);
    clearEl(generalSuccess);
    const name = nameInput.value.trim();
    const join_mode = joinModeSelect.value;
    if (!name) {
      showEl(generalError, "name is required");
      return;
    }
    generalSave.disabled = true;
    try {
      const data = await api(
        "PATCH",
        `/api/workspaces/${encodeURIComponent(workspace.slug)}`,
        { token: token(), body: { name, join_mode } }
      );
      const updated = data.workspace;
      ctx.updateWorkspaceHeader(updated);
      seedGeneralForm(updated);
      showEl(generalSuccess, "Saved");
    } catch (err) {
      if (handleAuthError(err)) return;
      if (err instanceof ApiClientError && err.status === 404) {
        closeAll();
        return;
      }
      showEl(
        generalError,
        err instanceof ApiClientError ? err.message : "Could not save"
      );
    } finally {
      generalSave.disabled = !canEditGeneral(ctx.getCallerRole());
    }
  });

  transferSubmit.addEventListener("click", async () => {
    const workspace = ctx.getWorkspace();
    if (!workspace) return;
    const newOwnerId = transferSelect.value;
    if (!newOwnerId) return;
    if (!window.confirm("Transfer ownership to the selected admin?")) return;
    clearEl(transferError);
    transferSubmit.disabled = true;
    try {
      await api(
        "POST",
        `/api/workspaces/${encodeURIComponent(workspace.slug)}/transfer_ownership`,
        { token: token(), body: { new_owner_id: newOwnerId } }
      );
      await ctx.refreshWorkspaceDetail();
      await loadMembers({ quiet: true });
      seedGeneralForm(ctx.getWorkspace() || workspace);
    } catch (err) {
      if (handleAuthError(err)) return;
      showEl(
        transferError,
        err instanceof ApiClientError ? err.message : "Transfer failed"
      );
    } finally {
      transferSubmit.disabled = false;
    }
  });

  inviteForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const workspace = ctx.getWorkspace();
    if (!workspace) return;
    clearEl(inviteCreateError);
    const maxUsesRaw = inviteForm.elements.max_uses.value.trim();
    const expiresRaw = inviteForm.elements.expires_in_seconds.value.trim();
    const username = inviteForm.elements.invited_username.value.trim();
    /** @type {Record<string, unknown>} */
    const body = {};
    if (maxUsesRaw) body.max_uses = Number(maxUsesRaw);
    if (expiresRaw) body.expires_in_seconds = Number(expiresRaw);
    if (username) body.invited_username = username;

    inviteCreateSubmit.disabled = true;
    try {
      const data = await api(
        "POST",
        `/api/workspaces/${encodeURIComponent(workspace.slug)}/invitations`,
        { token: token(), body }
      );
      const invitation = data.invitation;
      if (invitation) {
        invitations = [invitation, ...invitations.filter((i) => i.code !== invitation.code)];
        renderInvitations();
      } else {
        await loadInvitations();
      }
      inviteForm.reset();
    } catch (err) {
      if (handleAuthError(err)) return;
      showEl(
        inviteCreateError,
        err instanceof ApiClientError
          ? err.message
          : "Could not create invitation"
      );
    } finally {
      inviteCreateSubmit.disabled = false;
    }
  });

  acceptForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearEl(acceptError);
    const code = acceptForm.elements.code.value.trim();
    if (!code) {
      showEl(acceptError, "invitation code is required");
      return;
    }
    acceptSubmit.disabled = true;
    try {
      const data = await api(
        "POST",
        `/api/invitations/${encodeURIComponent(code)}/accept`,
        { token: token(), body: {} }
      );
      const workspace = data.workspace;
      if (!workspace || !workspace.slug) {
        showEl(acceptError, "Unexpected server response");
        return;
      }
      setWorkspaceSlug(workspace.slug);
      const ok = await ctx.enterWorkspace(workspace.slug);
      if (!ok) {
        if (data.channels) {
          ctx.showShell(workspace, data.channels);
        } else {
          showEl(acceptError, "Could not open workspace");
          return;
        }
      }
      acceptForm.reset();
    } catch (err) {
      if (handleAuthError(err)) return;
      showEl(
        acceptError,
        err instanceof ApiClientError
          ? err.message
          : "Could not accept invitation"
      );
    } finally {
      acceptSubmit.disabled = false;
    }
  });

  topicSave.addEventListener("click", async () => {
    if (!channelSettingsChannel) return;
    clearEl(topicError);
    const previous = topicInput.value;
    topicSave.disabled = true;
    try {
      const data = await api(
        "PATCH",
        `/api/channels/${encodeURIComponent(channelSettingsChannel.id)}`,
        { token: token(), body: { topic: topicInput.value } }
      );
      channelSettingsChannel = data.channel || {
        ...channelSettingsChannel,
        topic: topicInput.value,
      };
      topicInput.value = channelSettingsChannel.topic || "";
      const active = ctx.getActiveChannel();
      if (active && active.id === channelSettingsChannel.id) {
        // Keep shell active channel topic in sync via replace of channel list item state.
        Object.assign(active, channelSettingsChannel);
      }
    } catch (err) {
      if (handleAuthError(err)) return;
      topicInput.value = previous;
      showEl(
        topicError,
        err instanceof ApiClientError ? err.message : "Could not save topic"
      );
      if (err instanceof ApiClientError && err.status === 423) {
        topicInput.disabled = true;
        topicSave.disabled = true;
        if (channelSettingsChannel) {
          channelSettingsChannel.is_archived = true;
          updateArchiveButtons(channelSettingsChannel);
        }
      }
    } finally {
      if (!(channelSettingsChannel && channelSettingsChannel.is_archived)) {
        topicSave.disabled = false;
      }
    }
  });

  async function setArchived(archived) {
    if (!channelSettingsChannel) return;
    clearEl(archiveError);
    const url = archived
      ? `/api/channels/${encodeURIComponent(channelSettingsChannel.id)}/archive`
      : `/api/channels/${encodeURIComponent(channelSettingsChannel.id)}/unarchive`;
    const btn = archived ? archiveBtn : unarchiveBtn;
    btn.disabled = true;
    try {
      const data = await api("POST", url, { token: token(), body: {} });

      channelSettingsChannel = data.channel || {
        ...channelSettingsChannel,
        is_archived: archived,
      };
      updateArchiveButtons(channelSettingsChannel);
      topicInput.disabled = !!channelSettingsChannel.is_archived;
      topicSave.disabled = !!channelSettingsChannel.is_archived;
      clearEl(topicError);
      await ctx.refreshWorkspaceDetail();
      const active = ctx.getActiveChannel();
      if (active && active.id === channelSettingsChannel.id) {
        Object.assign(active, channelSettingsChannel);
      }
    } catch (err) {
      if (handleAuthError(err)) return;
      showEl(
        archiveError,
        err instanceof ApiClientError
          ? err.message
          : "Could not update archive state"
      );
    } finally {
      btn.disabled = false;
    }
  }

  archiveBtn.addEventListener("click", () => {
    void setArchived(true);
  });
  unarchiveBtn.addEventListener("click", () => {
    void setArchived(false);
  });

  addMemberForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!channelSettingsChannel) return;
    clearEl(addMemberError);
    const username = addMemberInput.value.trim();
    if (!username) {
      showEl(addMemberError, "username is required");
      return;
    }
    addMemberSubmit.disabled = true;
    try {
      const data = await api(
        "POST",
        `/api/channels/${encodeURIComponent(channelSettingsChannel.id)}/members`,
        { token: token(), body: { username } }
      );
      channelMembers = data.members || [];
      renderChannelMembers();
      addMemberInput.value = "";
    } catch (err) {
      if (handleAuthError(err)) return;
      showEl(
        addMemberError,
        err instanceof ApiClientError
          ? err.message
          : "Could not add member"
      );
    } finally {
      addMemberSubmit.disabled = false;
    }
  });

  return {
    openWorkspaceSettings,
    openChannelSettings,
    closeAll,
    setTab,
  };
}
