#!/usr/bin/env bash
# Huddle cluster supervisor: Redis + three HTTP nodes (foreground).
set -uo pipefail

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_ROOT"

DATA_DIR="${HUDDLE_DATA_DIR:-$APP_ROOT/data}"
REDIS_CONF="$DATA_DIR/redis/redis.conf"
REDIS_PIDFILE="$DATA_DIR/run/redis.pid"
VENV_DIR="$APP_ROOT/.venv"
PYTHON_BIN="$VENV_DIR/bin/python"
UVICORN_BIN="$VENV_DIR/bin/uvicorn"

REDIS_PID=""
declare -a NODE_PIDS=("" "" "")
SHUTTING_DOWN=0

log() {
  echo "[start.sh] $*" >&2
}

port_in_use() {
  local port="$1"
  python3 - "$port" <<'PY'
import socket, sys
port = int(sys.argv[1])
s = socket.socket()
try:
    s.bind(("127.0.0.1", port))
except OSError:
    sys.exit(0)
s.close()
sys.exit(1)
PY
}

fail_if_ports_busy() {
  local p
  for p in 8000 8001 8002 6379; do
    if port_in_use "$p"; then
      log "ERROR: port $p already in use; refusing to start"
      exit 1
    fi
  done
}

ensure_layout() {
  mkdir -p "$DATA_DIR/redis" "$DATA_DIR/files" "$DATA_DIR/run"
  cat >"$REDIS_CONF" <<EOF
bind 127.0.0.1
port 6379
protected-mode yes
daemonize no
dir $DATA_DIR/redis
pidfile $REDIS_PIDFILE
dbfilename dump.rdb
save ""
appendonly no
EOF
}

ensure_venv() {
  if [[ ! -x "$PYTHON_BIN" ]]; then
    log "creating venv at $VENV_DIR"
    python3 -m venv "$VENV_DIR"
  fi
  local req_hash stamp
  req_hash="$(cksum "$APP_ROOT/requirements.txt" | awk '{print $1" "$2}')"
  stamp="$VENV_DIR/.requirements.cksum"
  if [[ ! -f "$stamp" ]] || [[ "$(cat "$stamp" 2>/dev/null || true)" != "$req_hash" ]]; then
    log "installing Python dependencies"
    "$PYTHON_BIN" -m pip install -q --upgrade pip
    "$PYTHON_BIN" -m pip install -q -r "$APP_ROOT/requirements.txt"
    echo "$req_hash" >"$stamp"
  fi
}

start_redis() {
  local i
  for i in 1 2 3 4 5; do
    if port_in_use 6379; then
      sleep 0.2
    else
      break
    fi
  done
  if port_in_use 6379; then
    log "ERROR: port 6379 busy when starting redis"
    return 1
  fi
  rm -f "$REDIS_PIDFILE"
  log "starting redis-server"
  redis-server "$REDIS_CONF" &
  REDIS_PID=$!
  for i in $(seq 1 50); do
    if redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
      log "redis ready (pid=$REDIS_PID)"
      return 0
    fi
    if ! kill -0 "$REDIS_PID" 2>/dev/null; then
      log "ERROR: redis exited during startup"
      return 1
    fi
    sleep 0.1
  done
  log "ERROR: redis failed to become ready"
  return 1
}

start_node() {
  local node_id="$1"
  local port=$((8000 + node_id))
  local i
  for i in 1 2 3 4 5; do
    if port_in_use "$port"; then
      sleep 0.2
    else
      break
    fi
  done
  if port_in_use "$port"; then
    log "ERROR: port $port busy when starting node $node_id"
    return 1
  fi
  log "starting HTTP node $node_id on 127.0.0.1:$port"
  env \
    HUDDLE_NODE_ID="$node_id" \
    HUDDLE_PORT="$port" \
    HUDDLE_DATA_DIR="$DATA_DIR" \
    HUDDLE_REDIS_URL="${HUDDLE_REDIS_URL:-redis://127.0.0.1:6379/0}" \
    "$UVICORN_BIN" server.app:app --host 127.0.0.1 --port "$port" --log-level info &
  NODE_PIDS[$node_id]=$!
  log "node $node_id pid=${NODE_PIDS[$node_id]}"
}

stop_children() {
  SHUTTING_DOWN=1
  local pid
  for pid in "${NODE_PIDS[@]}" ${REDIS_PID:-}; do
    if [[ -n "${pid}" ]] && kill -0 "$pid" 2>/dev/null; then
      kill -TERM "$pid" 2>/dev/null || true
    fi
  done
  sleep 1
  for pid in "${NODE_PIDS[@]}" ${REDIS_PID:-}; do
    if [[ -n "${pid}" ]] && kill -0 "$pid" 2>/dev/null; then
      kill -KILL "$pid" 2>/dev/null || true
    fi
  done
  # Reap any remaining jobs started by this shell.
  local jp
  for jp in $(jobs -p 2>/dev/null); do
    kill -KILL "$jp" 2>/dev/null || true
  done
  wait 2>/dev/null || true
}

on_signal() {
  log "received shutdown signal"
  stop_children
  exit 0
}

trap on_signal INT TERM

ensure_layout
ensure_venv
fail_if_ports_busy

start_redis || exit 1
start_node 0 || { stop_children; exit 1; }
start_node 1 || { stop_children; exit 1; }
start_node 2 || { stop_children; exit 1; }

boot_deadline=$((SECONDS + 30))
while (( SECONDS < boot_deadline )); do
  ok=1
  for p in 0 1 2; do
    if ! curl -sf "http://127.0.0.1:800${p}/api/health" >/dev/null 2>&1; then
      ok=0
      break
    fi
  done
  if (( ok == 1 )); then
    log "all nodes healthy"
    break
  fi
  sleep 0.2
done

log "supervisor entering respawn loop"

while true; do
  if (( SHUTTING_DOWN == 1 )); then
    break
  fi

  if [[ -n "${REDIS_PID:-}" ]] && ! kill -0 "$REDIS_PID" 2>/dev/null; then
    log "redis (pid=$REDIS_PID) died; respawning"
    wait "$REDIS_PID" 2>/dev/null || true
    sleep 0.2
    start_redis || log "redis respawn failed; will retry"
  fi

  for node_id in 0 1 2; do
    pid="${NODE_PIDS[$node_id]}"
    if [[ -n "${pid:-}" ]] && ! kill -0 "$pid" 2>/dev/null; then
      log "node $node_id (pid=$pid) died; respawning"
      wait "$pid" 2>/dev/null || true
      sleep 0.2
      start_node "$node_id" || log "node $node_id respawn failed; will retry"
    fi
  done

  sleep 0.5
done
