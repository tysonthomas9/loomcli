"""Message CRUD, threads, reactions, and pin routes (MARATHON-8)."""

from __future__ import annotations

from typing import Any
from urllib.parse import unquote

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict

from server import db, events
from server.auth.deps import get_current_user
from server.channels import store as channels_store
from server.errors import ApiError
from server.messages import store as messages_store
from server.settings import Settings

router = APIRouter(prefix="/api/messages", tags=["messages"])


class PatchMessageBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    body: str


class ReactionBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    emoji: str


def _settings(request: Request) -> Settings:
    return request.app.state.settings


def _workspace_owner_id(conn: Any, workspace_id: str) -> str | None:
    row = conn.execute(
        "SELECT owner_id FROM workspaces WHERE id = ?", (workspace_id,)
    ).fetchone()
    return str(row["owner_id"]) if row is not None else None


def _load_message_and_channel(
    conn: Any, message_id: str
) -> tuple[Any, dict[str, Any]]:
    msg_row = messages_store.get_message_row(conn, message_id)
    if msg_row is None:
        raise ApiError(404, "not_found", "message not found")
    channel = channels_store.get_channel(conn, msg_row["channel_id"])
    if channel is None:
        raise ApiError(404, "not_found", "message not found")
    return msg_row, channel


def _require_message_channel_access(
    conn: Any,
    *,
    message_id: str,
    user_id: str,
    mode: str,
) -> tuple[Any, dict[str, Any]]:
    """Load message + channel; enforce read or write access."""
    msg_row, channel = _load_message_and_channel(conn, message_id)
    if mode == "write":
        messages_store.require_channel_message_write(
            conn,
            channel=channel,
            user_id=user_id,
            not_found="message not found",
        )
    else:
        messages_store.require_channel_message_read(
            conn,
            channel=channel,
            user_id=user_id,
            not_found="message not found",
        )
    return msg_row, channel


@router.post("/{message_id}/pin")
def pin_message(
    message_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        _msg_row, channel = _require_message_channel_access(
            conn, message_id=message_id, user_id=caller["id"], mode="write"
        )
        pin = channels_store.insert_pin(
            conn,
            message_id=message_id,
            channel_id=channel["id"],
            pinned_by=caller["id"],
        )
        conn.commit()
        return {
            "pin": {
                "message_id": pin["message_id"],
                "pinned_by": pin["pinned_by"],
                "pinned_at": pin["pinned_at"],
            }
        }
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.delete("/{message_id}/pin")
def unpin_message(
    message_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        _msg_row, channel = _require_message_channel_access(
            conn, message_id=message_id, user_id=caller["id"], mode="write"
        )
        channels_store.delete_pin(conn, message_id=message_id)
        conn.commit()
        return {"unpinned": True}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.patch("/{message_id}")
def patch_message(
    message_id: str,
    body: PatchMessageBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        msg_row, channel = _require_message_channel_access(
            conn, message_id=message_id, user_id=caller["id"], mode="write"
        )
        if msg_row["deleted_at"] is not None:
            raise ApiError(409, "conflict", "message is deleted")
        if msg_row["author_id"] != caller["id"]:
            raise ApiError(403, "forbidden", "only the author can edit")
        message = messages_store.update_message_body(
            conn, message_id=message_id, body=body.body
        )
        conn.commit()
        events.publish_message_updated(
            channel_id=channel["id"], message=message
        )
        return {"message": message}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.delete("/{message_id}")
def delete_message(
    message_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        msg_row, channel = _require_message_channel_access(
            conn, message_id=message_id, user_id=caller["id"], mode="read"
        )
        owner_id = _workspace_owner_id(conn, channel["workspace_id"])
        is_author = msg_row["author_id"] == caller["id"]
        is_owner = owner_id is not None and owner_id == caller["id"]
        if not (is_author or is_owner):
            raise ApiError(403, "forbidden", "not allowed to delete message")
        channels_store.assert_channel_writable(channel)
        messages_store.soft_delete_message(conn, message_id=message_id)
        conn.commit()
        events.publish_message_deleted(
            channel_id=channel["id"], message_id=message_id
        )
        return {"deleted": True}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.get("/{parent_id}/replies")
def list_message_replies(
    parent_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        msg_row, channel = _require_message_channel_access(
            conn, message_id=parent_id, user_id=caller["id"], mode="read"
        )
        if msg_row["deleted_at"] is not None:
            raise ApiError(404, "not_found", "message not found")
        replies = messages_store.list_replies(conn, parent_id=parent_id)
        return {"replies": replies}
    finally:
        conn.close()


@router.post("/{message_id}/reactions")
def add_reaction(
    message_id: str,
    body: ReactionBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        msg_row, channel = _require_message_channel_access(
            conn, message_id=message_id, user_id=caller["id"], mode="write"
        )
        if msg_row["deleted_at"] is not None:
            raise ApiError(409, "conflict", "message is deleted")
        reactions = messages_store.add_reaction(
            conn,
            message_id=message_id,
            user_id=caller["id"],
            emoji=body.emoji,
        )
        conn.commit()
        events.publish_reaction_changed(
            channel_id=channel["id"],
            message_id=message_id,
            reactions=reactions,
        )
        return {"reactions": reactions}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.delete("/{message_id}/reactions/{emoji}")
def delete_reaction(
    message_id: str,
    emoji: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    decoded = unquote(emoji)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        msg_row, channel = _require_message_channel_access(
            conn, message_id=message_id, user_id=caller["id"], mode="write"
        )
        if msg_row["deleted_at"] is not None:
            raise ApiError(409, "conflict", "message is deleted")
        reactions = messages_store.remove_reaction(
            conn,
            message_id=message_id,
            user_id=caller["id"],
            emoji=decoded,
        )
        conn.commit()
        events.publish_reaction_changed(
            channel_id=channel["id"],
            message_id=message_id,
            reactions=reactions,
        )
        return {"reactions": reactions}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
