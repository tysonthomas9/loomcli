"""Message persistence: CRUD, threads, reactions, mention resolve (MARATHON-8)."""

from __future__ import annotations

import json
import re
import sqlite3
import uuid
from typing import Any

from server.auth.users import get_user_by_id, get_user_row_by_username
from server.channels import store as channels_store
from server.db import utc_now_z
from server.errors import ApiError
from server.workspaces import store as workspaces_store

MESSAGE_OBJ_KEYS = (
    "id",
    "channel_id",
    "author_id",
    "author",
    "body",
    "parent_id",
    "reply_count",
    "created_at",
    "edited_at",
    "files",
    "reactions",
    "mentions",
)

BODY_MAX = 4000
EMOJI_MAX = 32

# Word-boundary @username (no mid-word); username charset matches auth rules.
MENTION_RE = re.compile(r"(?<![A-Za-z0-9_])@([a-z0-9][a-z0-9_-]{1,31})(?![A-Za-z0-9_])")


def require_channel_message_read(
    conn: sqlite3.Connection,
    *,
    channel: dict[str, Any],
    user_id: str,
    not_found: str = "channel not found",
) -> None:
    """Same rules as GET /api/channels/{id}/pins."""
    role = workspaces_store.get_member_role(
        conn, workspace_id=channel["workspace_id"], user_id=user_id
    )
    is_member = channels_store.is_channel_member(
        conn, channel_id=channel["id"], user_id=user_id
    )

    if channel["is_private"] or channel["is_dm"]:
        if not is_member:
            if role is not None:
                raise ApiError(403, "forbidden", "private channel access denied")
            raise ApiError(404, "not_found", not_found)
    else:
        if role is None:
            raise ApiError(404, "not_found", not_found)


def require_channel_message_write(
    conn: sqlite3.Connection,
    *,
    channel: dict[str, Any],
    user_id: str,
    not_found: str = "channel not found",
) -> None:
    """Channel member required; then assert writable (423 archived)."""
    is_member = channels_store.is_channel_member(
        conn, channel_id=channel["id"], user_id=user_id
    )
    if not is_member:
        role = workspaces_store.get_member_role(
            conn, workspace_id=channel["workspace_id"], user_id=user_id
        )
        if channel["is_private"] or channel["is_dm"]:
            if role is None:
                raise ApiError(404, "not_found", not_found)
            raise ApiError(403, "forbidden", "channel membership required")
        if role is None:
            raise ApiError(404, "not_found", not_found)
        raise ApiError(403, "forbidden", "channel membership required")
    channels_store.assert_channel_writable(channel)


def validate_message_body(body: Any) -> str:
    if not isinstance(body, str):
        raise ApiError(400, "validation_error", "body must be a string")
    stripped = body.strip()
    if not stripped:
        raise ApiError(400, "validation_error", "body is required")
    if len(stripped) > BODY_MAX:
        raise ApiError(400, "validation_error", "body is too long")
    return stripped


def validate_emoji(emoji: Any) -> str:
    if not isinstance(emoji, str):
        raise ApiError(400, "validation_error", "emoji must be a string")
    if not emoji or not emoji.strip():
        raise ApiError(400, "validation_error", "emoji is required")
    if len(emoji) > EMOJI_MAX:
        raise ApiError(400, "validation_error", "emoji is too long")
    return emoji


def _author_from_joined(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    get = row.__getitem__
    try:
        return {
            "id": get("author_id"),
            "username": get("author_username"),
            "display_name": get("author_display_name"),
            "timezone": get("author_timezone"),
            "avatar_url": get("author_avatar_url"),
            "status_text": get("author_status_text"),
            "status_emoji": get("author_status_emoji"),
        }
    except (KeyError, IndexError):
        return {
            "id": get("author_id"),
            "username": "",
            "display_name": "",
            "timezone": None,
            "avatar_url": None,
            "status_text": None,
            "status_emoji": None,
        }


def count_replies(conn: sqlite3.Connection, message_id: str) -> int:
    row = conn.execute(
        """
        SELECT COUNT(*) FROM messages
        WHERE parent_id = ? AND deleted_at IS NULL
        """,
        (message_id,),
    ).fetchone()
    return int(row[0]) if row is not None else 0


def aggregate_reactions(
    conn: sqlite3.Connection, message_id: str
) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT emoji, user_id, created_at
        FROM message_reactions
        WHERE message_id = ?
        ORDER BY created_at ASC, user_id ASC
        """,
        (message_id,),
    ).fetchall()
    groups: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    for row in rows:
        emoji = row["emoji"]
        if emoji not in groups:
            groups[emoji] = {
                "emoji": emoji,
                "user_ids": [],
                "_first_at": row["created_at"],
            }
            order.append(emoji)
        groups[emoji]["user_ids"].append(row["user_id"])
    result: list[dict[str, Any]] = []
    for emoji in sorted(
        order, key=lambda e: (groups[e]["_first_at"], e)
    ):
        g = groups[emoji]
        result.append(
            {
                "emoji": g["emoji"],
                "count": len(g["user_ids"]),
                "user_ids": g["user_ids"],
            }
        )
    return result


def resolve_mentions(
    conn: sqlite3.Connection,
    *,
    body: str,
    workspace_id: str,
    author_id: str,
) -> list[str]:
    """Resolve @username mentions to workspace-member user ids (deduped)."""
    seen: set[str] = set()
    out: list[str] = []
    for match in MENTION_RE.finditer(body):
        username = match.group(1)
        row = get_user_row_by_username(conn, username)
        if row is None:
            continue
        uid = row["id"]
        if uid == author_id:
            continue
        if uid in seen:
            continue
        member = conn.execute(
            """
            SELECT 1 FROM workspace_members
            WHERE workspace_id = ? AND user_id = ?
            """,
            (workspace_id, uid),
        ).fetchone()
        if member is None:
            continue
        seen.add(uid)
        out.append(uid)
    return out


def _files_table_exists(conn: sqlite3.Connection) -> bool:
    row = conn.execute(
        """
        SELECT 1 FROM sqlite_master
        WHERE type = 'table' AND name = 'files'
        """
    ).fetchone()
    return row is not None


def list_message_files(
    conn: sqlite3.Connection, message_id: str
) -> list[dict[str, Any]]:
    """FileObj embeds; empty until MARATHON-10 ``files`` rows are resolvable."""
    if not _files_table_exists(conn):
        return []
    rows = conn.execute(
        """
        SELECT f.id, f.uploader_id, f.filename, f.content_type, f.size, f.created_at
        FROM message_files mf
        INNER JOIN files f ON f.id = mf.file_id
        WHERE mf.message_id = ?
        ORDER BY mf.created_at ASC, mf.file_id ASC
        """,
        (message_id,),
    ).fetchall()
    return [
        {
            "id": r["id"],
            "uploader_id": r["uploader_id"],
            "filename": r["filename"],
            "content_type": r["content_type"],
            "size": r["size"],
            "created_at": r["created_at"],
        }
        for r in rows
    ]


def _workspace_id_for_channel(
    conn: sqlite3.Connection, channel_id: str
) -> str | None:
    row = conn.execute(
        "SELECT workspace_id FROM channels WHERE id = ?", (channel_id,)
    ).fetchone()
    return str(row["workspace_id"]) if row is not None else None


def row_to_message_obj(
    row: sqlite3.Row | dict[str, Any],
    *,
    author: dict[str, Any] | None = None,
    reply_count: int = 0,
    reactions: list[dict[str, Any]] | None = None,
    mentions: list[str] | None = None,
    files: list[dict[str, Any]] | None = None,
    tombstone: bool = False,
) -> dict[str, Any]:
    get = row.__getitem__
    author_obj = author if author is not None else _author_from_joined(row)
    deleted = False
    try:
        deleted = get("deleted_at") is not None
    except (KeyError, IndexError):
        deleted = False
    if tombstone or deleted:
        return {
            "id": get("id"),
            "channel_id": get("channel_id"),
            "author_id": get("author_id"),
            "author": author_obj,
            "body": "",
            "parent_id": get("parent_id"),
            "reply_count": reply_count,
            "created_at": get("created_at"),
            "edited_at": get("edited_at"),
            "files": [],
            "reactions": [],
            "mentions": [],
        }
    return {
        "id": get("id"),
        "channel_id": get("channel_id"),
        "author_id": get("author_id"),
        "author": author_obj,
        "body": get("body"),
        "parent_id": get("parent_id"),
        "reply_count": reply_count,
        "created_at": get("created_at"),
        "edited_at": get("edited_at"),
        "files": files if files is not None else [],
        "reactions": reactions if reactions is not None else [],
        "mentions": mentions if mentions is not None else [],
    }


def enrich_message_obj(
    conn: sqlite3.Connection,
    row: sqlite3.Row | dict[str, Any],
    *,
    author: dict[str, Any] | None = None,
) -> dict[str, Any]:
    get = row.__getitem__
    message_id = get("id")
    channel_id = get("channel_id")
    reply_count = count_replies(conn, message_id)
    deleted = get("deleted_at") is not None
    if deleted:
        return row_to_message_obj(
            row, author=author, reply_count=reply_count, tombstone=True
        )
    workspace_id = _workspace_id_for_channel(conn, channel_id) or ""
    mentions = resolve_mentions(
        conn,
        body=get("body"),
        workspace_id=workspace_id,
        author_id=get("author_id"),
    )
    return row_to_message_obj(
        row,
        author=author,
        reply_count=reply_count,
        reactions=aggregate_reactions(conn, message_id),
        mentions=mentions,
        files=list_message_files(conn, message_id),
    )


def get_message(
    conn: sqlite3.Connection, message_id: str
) -> dict[str, Any] | None:
    """Return enriched MessageObj for id (tombstone if soft-deleted), or None."""
    row = conn.execute(
        """
        SELECT m.*,
               u.username AS author_username,
               u.display_name AS author_display_name,
               u.timezone AS author_timezone,
               u.avatar_url AS author_avatar_url,
               u.status_text AS author_status_text,
               u.status_emoji AS author_status_emoji
        FROM messages m
        INNER JOIN users u ON u.id = m.author_id
        WHERE m.id = ?
        """,
        (message_id,),
    ).fetchone()
    if row is None:
        return None
    return enrich_message_obj(conn, row)


def get_message_row(
    conn: sqlite3.Connection, message_id: str
) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM messages WHERE id = ?", (message_id,)
    ).fetchone()


def build_message_obj_from_row(
    conn: sqlite3.Connection, row: sqlite3.Row
) -> dict[str, Any]:
    author = get_user_by_id(conn, row["author_id"])
    if author is None:
        author = {
            "id": row["author_id"],
            "username": "",
            "display_name": "",
            "timezone": None,
            "avatar_url": None,
            "status_text": None,
            "status_emoji": None,
        }
    return enrich_message_obj(conn, row, author=author)


def _validate_parent(
    conn: sqlite3.Connection, *, channel_id: str, parent_id: str
) -> None:
    parent = get_message_row(conn, parent_id)
    if parent is None:
        raise ApiError(400, "validation_error", "invalid parent_id")
    if parent["channel_id"] != channel_id:
        raise ApiError(400, "validation_error", "invalid parent_id")
    if parent["deleted_at"] is not None:
        raise ApiError(400, "validation_error", "invalid parent_id")
    if parent["parent_id"] is not None:
        raise ApiError(400, "validation_error", "invalid parent_id")


def validate_file_ids(
    conn: sqlite3.Connection, *, file_ids: list[Any], uploader_id: str
) -> list[str]:
    """Validate attachable file ids; refuse non-empty until MARATHON-10 files exist."""
    if not isinstance(file_ids, list):
        raise ApiError(400, "validation_error", "file_ids must be a list")
    ids: list[str] = []
    for item in file_ids:
        if not isinstance(item, str) or not item:
            raise ApiError(400, "validation_error", "invalid file_ids")
        ids.append(item)
    if not ids:
        return []
    if not _files_table_exists(conn):
        raise ApiError(400, "validation_error", "file attachments unavailable")
    for fid in ids:
        row = conn.execute(
            "SELECT id, uploader_id FROM files WHERE id = ?", (fid,)
        ).fetchone()
        if row is None:
            raise ApiError(400, "validation_error", "invalid file_ids")
        if row["uploader_id"] != uploader_id:
            raise ApiError(400, "validation_error", "invalid file_ids")
        attached = conn.execute(
            "SELECT 1 FROM message_files WHERE file_id = ?", (fid,)
        ).fetchone()
        if attached is not None:
            raise ApiError(400, "validation_error", "invalid file_ids")
    return ids


def create_message(
    conn: sqlite3.Connection,
    *,
    channel_id: str,
    author_id: str,
    body: str,
    parent_id: str | None = None,
    file_ids: list[str] | None = None,
    blocks: Any = None,
) -> dict[str, Any]:
    body = validate_message_body(body)
    if parent_id is not None:
        if not isinstance(parent_id, str) or not parent_id:
            raise ApiError(400, "validation_error", "invalid parent_id")
        _validate_parent(conn, channel_id=channel_id, parent_id=parent_id)

    blocks_json: str | None = None
    if blocks is not None:
        if not isinstance(blocks, list):
            raise ApiError(400, "validation_error", "blocks must be a list")
        blocks_json = json.dumps(blocks)

    validated_files = validate_file_ids(
        conn, file_ids=file_ids or [], uploader_id=author_id
    )

    message_id = str(uuid.uuid4())
    now = utc_now_z()
    conn.execute(
        """
        INSERT INTO messages (
            id, channel_id, author_id, body, parent_id,
            created_at, edited_at, deleted_at, blocks_json
        ) VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, ?)
        """,
        (
            message_id,
            channel_id,
            author_id,
            body,
            parent_id,
            now,
            blocks_json,
        ),
    )
    for fid in validated_files:
        conn.execute(
            """
            INSERT INTO message_files (message_id, file_id, created_at)
            VALUES (?, ?, ?)
            """,
            (message_id, fid, now),
        )
    row = get_message_row(conn, message_id)
    assert row is not None
    return build_message_obj_from_row(conn, row)


def list_channel_messages(
    conn: sqlite3.Connection,
    *,
    channel_id: str,
    limit: int = 50,
    before: str | None = None,
) -> list[dict[str, Any]]:
    if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1 or limit > 100:
        raise ApiError(400, "validation_error", "invalid limit")

    params: list[Any] = [channel_id]
    cursor_sql = ""
    if before is not None:
        if not isinstance(before, str) or not before:
            raise ApiError(400, "validation_error", "invalid before")
        cursor = get_message_row(conn, before)
        if cursor is None or cursor["channel_id"] != channel_id:
            raise ApiError(400, "validation_error", "invalid before")
        cursor_sql = """
            AND (m.created_at < ? OR (m.created_at = ? AND m.id < ?))
        """
        params.extend([cursor["created_at"], cursor["created_at"], cursor["id"]])

    params.append(limit)
    rows = conn.execute(
        f"""
        SELECT m.*,
               u.username AS author_username,
               u.display_name AS author_display_name,
               u.timezone AS author_timezone,
               u.avatar_url AS author_avatar_url,
               u.status_text AS author_status_text,
               u.status_emoji AS author_status_emoji
        FROM messages m
        INNER JOIN users u ON u.id = m.author_id
        WHERE m.channel_id = ?
          AND m.parent_id IS NULL
          AND m.deleted_at IS NULL
          {cursor_sql}
        ORDER BY m.created_at DESC, m.id DESC
        LIMIT ?
        """,
        params,
    ).fetchall()
    return [enrich_message_obj(conn, row) for row in rows]


def list_replies(
    conn: sqlite3.Connection, *, parent_id: str
) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT m.*,
               u.username AS author_username,
               u.display_name AS author_display_name,
               u.timezone AS author_timezone,
               u.avatar_url AS author_avatar_url,
               u.status_text AS author_status_text,
               u.status_emoji AS author_status_emoji
        FROM messages m
        INNER JOIN users u ON u.id = m.author_id
        WHERE m.parent_id = ?
          AND m.deleted_at IS NULL
        ORDER BY m.created_at ASC, m.id ASC
        """,
        (parent_id,),
    ).fetchall()
    return [enrich_message_obj(conn, row) for row in rows]


def update_message_body(
    conn: sqlite3.Connection, *, message_id: str, body: str
) -> dict[str, Any]:
    body = validate_message_body(body)
    now = utc_now_z()
    conn.execute(
        """
        UPDATE messages SET body = ?, edited_at = ?
        WHERE id = ?
        """,
        (body, now, message_id),
    )
    row = get_message_row(conn, message_id)
    assert row is not None
    return build_message_obj_from_row(conn, row)


def soft_delete_message(conn: sqlite3.Connection, *, message_id: str) -> bool:
    """Soft-delete message and clear reactions. Returns True if newly deleted."""
    row = get_message_row(conn, message_id)
    if row is None:
        return False
    if row["deleted_at"] is not None:
        return False
    now = utc_now_z()
    conn.execute(
        "UPDATE messages SET deleted_at = ? WHERE id = ?",
        (now, message_id),
    )
    conn.execute(
        "DELETE FROM message_reactions WHERE message_id = ?",
        (message_id,),
    )
    return True


def add_reaction(
    conn: sqlite3.Connection,
    *,
    message_id: str,
    user_id: str,
    emoji: str,
) -> list[dict[str, Any]]:
    emoji = validate_emoji(emoji)
    now = utc_now_z()
    try:
        conn.execute(
            """
            INSERT INTO message_reactions (message_id, user_id, emoji, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (message_id, user_id, emoji, now),
        )
    except sqlite3.IntegrityError:
        pass
    return aggregate_reactions(conn, message_id)


def remove_reaction(
    conn: sqlite3.Connection,
    *,
    message_id: str,
    user_id: str,
    emoji: str,
) -> list[dict[str, Any]]:
    emoji = validate_emoji(emoji)
    conn.execute(
        """
        DELETE FROM message_reactions
        WHERE message_id = ? AND user_id = ? AND emoji = ?
        """,
        (message_id, user_id, emoji),
    )
    return aggregate_reactions(conn, message_id)
