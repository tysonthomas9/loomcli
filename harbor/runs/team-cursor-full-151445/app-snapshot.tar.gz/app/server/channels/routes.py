"""Channel HTTP routes: join, leave, topic, members, archive, pins."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, ConfigDict

from server import db, events
from server.auth.deps import get_current_user
from server.auth import users as auth_users
from server.channels import store as channels_store
from server.errors import ApiError
from server.messages import store as messages_store
from server.settings import Settings
from server.workspaces import store as workspaces_store

router = APIRouter(prefix="/api/channels", tags=["channels"])


class PatchChannelBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    topic: str | None = None


class PostMessageBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    body: str
    parent_id: str | None = None
    file_ids: list[str] | None = None
    blocks: Any = None


class AddChannelMemberBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    username: str | None = None
    user_id: str | None = None


def _settings(request: Request) -> Settings:
    return request.app.state.settings


def _get_workspace_row(
    conn: Any, workspace_id: str
) -> dict[str, Any] | None:
    row = conn.execute(
        "SELECT * FROM workspaces WHERE id = ?", (workspace_id,)
    ).fetchone()
    if row is None:
        return None
    return workspaces_store.row_to_workspace_obj(row)


def _require_channel(conn: Any, channel_id: str) -> dict[str, Any]:
    channel = channels_store.get_channel(conn, channel_id)
    if channel is None:
        raise ApiError(404, "not_found", "channel not found")
    return channel


def _workspace_role(conn: Any, *, workspace_id: str, user_id: str) -> str | None:
    return workspaces_store.get_member_role(
        conn, workspace_id=workspace_id, user_id=user_id
    )


def _require_channel_read_access(
    conn: Any, *, channel: dict[str, Any], user_id: str
) -> None:
    """Public: workspace member. Private non-DM: member or owner. DM: member only."""
    role = _workspace_role(
        conn, workspace_id=channel["workspace_id"], user_id=user_id
    )
    is_member = channels_store.is_channel_member(
        conn, channel_id=channel["id"], user_id=user_id
    )
    workspace = _get_workspace_row(conn, channel["workspace_id"])
    is_owner = workspace is not None and workspace["owner_id"] == user_id

    if channel["is_dm"]:
        if is_member:
            return
        if role is not None:
            raise ApiError(403, "forbidden", "private channel access denied")
        raise ApiError(404, "not_found", "channel not found")

    if channel["is_private"]:
        if is_member or is_owner:
            return
        if role is not None:
            raise ApiError(403, "forbidden", "private channel access denied")
        raise ApiError(404, "not_found", "channel not found")

    if role is None:
        raise ApiError(404, "not_found", "channel not found")


@router.post("/{channel_id}/join")
def join_channel(
    channel_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        channel = _require_channel(conn, channel_id)

        if channels_store.is_channel_member(
            conn, channel_id=channel["id"], user_id=caller["id"]
        ):
            conn.commit()
            return {"channel": channel}

        # Private / DM: no invite table yet → 403 without membership.
        if channel["is_private"] or channel["is_dm"]:
            raise ApiError(403, "forbidden", "private channel invite required")

        workspace = _get_workspace_row(conn, channel["workspace_id"])
        if workspace is None:
            raise ApiError(404, "not_found", "channel not found")

        role = _workspace_role(
            conn, workspace_id=workspace["id"], user_id=caller["id"]
        )
        if role is None:
            if workspace["join_mode"] == "invite_only":
                raise ApiError(403, "forbidden", "workspace is invite only")
            workspaces_store.add_workspace_member(
                conn,
                workspace_id=workspace["id"],
                user_id=caller["id"],
                role="member",
            )
            role = "member"

        if role == "guest":
            raise ApiError(403, "forbidden", "guests cannot join channels")

        channels_store.add_channel_member(
            conn, channel_id=channel["id"], user_id=caller["id"]
        )
        conn.commit()
        return {"channel": channel}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.post("/{channel_id}/leave")
def leave_channel(
    channel_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        channel = _require_channel(conn, channel_id)
        is_member = channels_store.is_channel_member(
            conn, channel_id=channel["id"], user_id=caller["id"]
        )
        role = _workspace_role(
            conn, workspace_id=channel["workspace_id"], user_id=caller["id"]
        )

        if channel["is_private"] or channel["is_dm"]:
            if not is_member and role is None:
                raise ApiError(404, "not_found", "channel not found")

        if is_member:
            channels_store.remove_channel_member(
                conn, channel_id=channel["id"], user_id=caller["id"]
            )
        conn.commit()
        return {"channel": channel}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.get("/{channel_id}/members")
def list_channel_members(
    channel_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        channel = _require_channel(conn, channel_id)
        _require_channel_read_access(conn, channel=channel, user_id=caller["id"])
        members = channels_store.list_members_as_users(
            conn, channel_id=channel["id"]
        )
        return {"members": members}
    finally:
        conn.close()


def _resolve_add_member_target(
    conn: Any, *, username: str | None, user_id: str | None
) -> dict[str, Any]:
    """Resolve username and/or user_id to a UserObj; enforce single-target rules."""
    has_username = isinstance(username, str) and username.strip() != ""
    has_user_id = isinstance(user_id, str) and user_id.strip() != ""
    if not has_username and not has_user_id:
        raise ApiError(
            400, "validation_error", "username or user_id is required"
        )

    by_username: dict[str, Any] | None = None
    by_id: dict[str, Any] | None = None

    if has_username:
        row = auth_users.get_user_row_by_username(conn, username.strip())
        if row is None:
            raise ApiError(400, "validation_error", "user not found")
        by_username = auth_users.row_to_user_obj(row)

    if has_user_id:
        by_id = auth_users.get_user_by_id(conn, user_id.strip())
        if by_id is None:
            raise ApiError(400, "validation_error", "user not found")

    if by_username is not None and by_id is not None:
        if by_username["id"] != by_id["id"]:
            raise ApiError(
                400,
                "validation_error",
                "username and user_id refer to different users",
            )
        return by_username
    return by_username if by_username is not None else by_id  # type: ignore[return-value]


@router.post("/{channel_id}/members")
def add_channel_member(
    channel_id: str,
    body: AddChannelMemberBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    """Add a workspace member to a channel (idempotent). Not for DMs."""
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        channel = _require_channel(conn, channel_id)

        if channel["is_dm"]:
            raise ApiError(403, "forbidden", "cannot add members to a DM channel")

        caller_role = _workspace_role(
            conn, workspace_id=channel["workspace_id"], user_id=caller["id"]
        )
        if caller_role is None:
            raise ApiError(404, "not_found", "channel not found")

        is_channel_member = channels_store.is_channel_member(
            conn, channel_id=channel["id"], user_id=caller["id"]
        )
        is_ws_admin = caller_role in ("owner", "admin")
        is_member_adder = is_channel_member and caller_role in (
            "owner",
            "admin",
            "member",
        )
        if caller_role == "guest" or not (is_ws_admin or is_member_adder):
            raise ApiError(403, "forbidden", "cannot add channel members")

        target = _resolve_add_member_target(
            conn, username=body.username, user_id=body.user_id
        )
        target_role = _workspace_role(
            conn, workspace_id=channel["workspace_id"], user_id=target["id"]
        )
        if target_role is None:
            raise ApiError(
                400,
                "validation_error",
                "target must be a workspace member",
            )

        channels_store.add_channel_member(
            conn, channel_id=channel["id"], user_id=target["id"]
        )
        members = channels_store.list_members_as_users(
            conn, channel_id=channel["id"]
        )
        conn.commit()
        return {"members": members}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.patch("/{channel_id}")
def patch_channel(
    channel_id: str,
    body: PatchChannelBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    patch = body.model_dump(exclude_unset=True)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        channel = _require_channel(conn, channel_id)
        workspace = _get_workspace_row(conn, channel["workspace_id"])
        if workspace is None:
            raise ApiError(404, "not_found", "channel not found")

        is_member = channels_store.is_channel_member(
            conn, channel_id=channel["id"], user_id=caller["id"]
        )
        is_owner = workspace["owner_id"] == caller["id"]
        role = _workspace_role(
            conn, workspace_id=workspace["id"], user_id=caller["id"]
        )

        # DMs: membership required (no workspace-owner bypass).
        if channel["is_dm"]:
            if not is_member:
                if role is None:
                    raise ApiError(404, "not_found", "channel not found")
                raise ApiError(403, "forbidden", "channel membership required")
        elif not (is_member or is_owner):
            if role is None and channel["is_private"]:
                raise ApiError(404, "not_found", "channel not found")
            if role is None:
                raise ApiError(404, "not_found", "channel not found")
            raise ApiError(403, "forbidden", "channel membership required")

        if not patch:
            conn.commit()
            return {"channel": channel}

        if "topic" in patch:
            if patch["topic"] is None:
                raise ApiError(400, "validation_error", "topic cannot be null")
            channels_store.assert_channel_writable(channel)
            channel = channels_store.update_topic(
                conn, channel_id=channel["id"], topic=patch["topic"]
            )

        conn.commit()
        return {"channel": channel}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.post("/{channel_id}/archive")
def archive_channel(
    channel_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    return _set_archive(channel_id, request, caller, archived=True)


@router.post("/{channel_id}/unarchive")
def unarchive_channel(
    channel_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    return _set_archive(channel_id, request, caller, archived=False)


def _set_archive(
    channel_id: str,
    request: Request,
    caller: dict[str, Any],
    *,
    archived: bool,
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        channel = _require_channel(conn, channel_id)
        workspace = _get_workspace_row(conn, channel["workspace_id"])
        if workspace is None:
            raise ApiError(404, "not_found", "channel not found")

        role = _workspace_role(
            conn, workspace_id=workspace["id"], user_id=caller["id"]
        )
        if role is None:
            raise ApiError(404, "not_found", "channel not found")
        if caller["id"] != workspace["owner_id"]:
            raise ApiError(403, "forbidden", "only the owner can archive")

        channel = channels_store.set_archived(
            conn, channel_id=channel["id"], archived=archived
        )
        conn.commit()
        return {"channel": channel}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.post("/{channel_id}/messages", status_code=201)
def post_channel_message(
    channel_id: str,
    body: PostMessageBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        channel = _require_channel(conn, channel_id)
        messages_store.require_channel_message_write(
            conn, channel=channel, user_id=caller["id"]
        )
        message = messages_store.create_message(
            conn,
            channel_id=channel["id"],
            author_id=caller["id"],
            body=body.body,
            parent_id=body.parent_id,
            file_ids=body.file_ids,
            blocks=body.blocks,
        )
        conn.commit()
        events.publish_message_created(
            channel_id=channel["id"], message=message
        )
        return {"message": message}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.get("/{channel_id}/messages")
def list_channel_messages(
    channel_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
    limit: int | None = Query(default=None),
    before: str | None = Query(default=None),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        channel = _require_channel(conn, channel_id)
        messages_store.require_channel_message_read(
            conn, channel=channel, user_id=caller["id"]
        )
        effective_limit = 50 if limit is None else limit
        messages = messages_store.list_channel_messages(
            conn,
            channel_id=channel["id"],
            limit=effective_limit,
            before=before,
        )
        return {"messages": messages}
    finally:
        conn.close()


@router.get("/{channel_id}/pins")
def list_channel_pins(
    channel_id: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        channel = _require_channel(conn, channel_id)
        # Pin list: private → channel member only (not owner-without-membership).
        if channel["is_private"] or channel["is_dm"]:
            if not channels_store.is_channel_member(
                conn, channel_id=channel["id"], user_id=caller["id"]
            ):
                role = _workspace_role(
                    conn,
                    workspace_id=channel["workspace_id"],
                    user_id=caller["id"],
                )
                if role is not None:
                    raise ApiError(
                        403, "forbidden", "private channel access denied"
                    )
                raise ApiError(404, "not_found", "channel not found")
        else:
            role = _workspace_role(
                conn,
                workspace_id=channel["workspace_id"],
                user_id=caller["id"],
            )
            if role is None:
                raise ApiError(404, "not_found", "channel not found")

        pin_rows = channels_store.list_pins_for_channel(
            conn, channel_id=channel["id"]
        )
        pins: list[dict[str, Any]] = []
        for pin in pin_rows:
            message = messages_store.get_message(conn, pin["message_id"])
            if message is None:
                continue
            pins.append(
                {
                    "message": message,
                    "pinned_by": pin["pinned_by"],
                    "pinned_at": pin["pinned_at"],
                }
            )
        return {"pins": pins}
    finally:
        conn.close()
