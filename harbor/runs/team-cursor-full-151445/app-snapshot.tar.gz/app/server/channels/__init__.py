"""Channel persistence and HTTP routes (lifecycle + pins list)."""
