"""Channel persistence, ChannelObj mapping, and read_state embedding."""

from __future__ import annotations

import re
import sqlite3
import uuid
from typing import Any

from server.auth.users import row_to_user_obj
from server.db import utc_now_z
from server.errors import ApiError

CHANNEL_OBJ_KEYS = (
    "id",
    "workspace_id",
    "name",
    "is_private",
    "is_dm",
    "topic",
    "is_archived",
)

READ_STATE_ENTRY_KEYS = (
    "channel_id",
    "last_read_seq",
    "unread_count",
    "mention_count",
)

CHANNEL_NAME_RE = re.compile(r"^[a-z0-9-]{2,32}$")
TOPIC_MAX = 250


def row_to_channel_obj(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    get = row.__getitem__
    return {
        "id": get("id"),
        "workspace_id": get("workspace_id"),
        "name": get("name"),
        "is_private": bool(get("is_private")),
        "is_dm": bool(get("is_dm")),
        "topic": get("topic") if get("topic") is not None else "",
        "is_archived": bool(get("is_archived")),
    }


def validate_channel_name(name: str) -> str:
    if not isinstance(name, str) or not CHANNEL_NAME_RE.fullmatch(name):
        raise ApiError(400, "validation_error", "invalid channel name")
    return name


def validate_topic(topic: str) -> str:
    if not isinstance(topic, str):
        raise ApiError(400, "validation_error", "topic must be a string")
    if len(topic) > TOPIC_MAX:
        raise ApiError(400, "validation_error", "topic is too long")
    return topic


def assert_channel_writable(channel: dict[str, Any]) -> None:
    """Raise 423 archived when the channel rejects mutating writes."""
    if channel.get("is_archived"):
        raise ApiError(423, "archived", "channel is archived")


def get_channel(
    conn: sqlite3.Connection, channel_id: str
) -> dict[str, Any] | None:
    row = conn.execute(
        "SELECT * FROM channels WHERE id = ?", (channel_id,)
    ).fetchone()
    if row is None:
        return None
    return row_to_channel_obj(row)


def is_channel_member(
    conn: sqlite3.Connection, *, channel_id: str, user_id: str
) -> bool:
    row = conn.execute(
        """
        SELECT 1 FROM channel_members
        WHERE channel_id = ? AND user_id = ?
        """,
        (channel_id, user_id),
    ).fetchone()
    return row is not None


def add_channel_member(
    conn: sqlite3.Connection, *, channel_id: str, user_id: str
) -> None:
    """Insert channel membership; idempotent if already a member."""
    if is_channel_member(conn, channel_id=channel_id, user_id=user_id):
        return
    conn.execute(
        """
        INSERT INTO channel_members (channel_id, user_id, created_at)
        VALUES (?, ?, ?)
        """,
        (channel_id, user_id, utc_now_z()),
    )


def ensure_channel_member(
    conn: sqlite3.Connection, *, channel_id: str, user_id: str
) -> None:
    """Idempotent channel membership insert (alias used by invitation accept)."""
    add_channel_member(conn, channel_id=channel_id, user_id=user_id)


def get_general_channel(
    conn: sqlite3.Connection, *, workspace_id: str
) -> dict[str, Any] | None:
    """Return the public #general ChannelObj for a workspace, if present."""
    row = conn.execute(
        """
        SELECT * FROM channels
        WHERE workspace_id = ? AND name = 'general' AND is_dm = 0
        """,
        (workspace_id,),
    ).fetchone()
    if row is None:
        return None
    return row_to_channel_obj(row)


def remove_channel_member(
    conn: sqlite3.Connection, *, channel_id: str, user_id: str
) -> None:
    """Remove channel membership; no-op if absent."""
    conn.execute(
        """
        DELETE FROM channel_members
        WHERE channel_id = ? AND user_id = ?
        """,
        (channel_id, user_id),
    )


def create_channel(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    creator_user_id: str,
    name: str,
    is_private: bool = False,
    topic: str = "",
) -> dict[str, Any]:
    """Insert channel + creator membership. Returns ChannelObj."""
    name = validate_channel_name(name)
    topic = validate_topic(topic)
    channel_id = str(uuid.uuid4())
    now = utc_now_z()
    try:
        conn.execute(
            """
            INSERT INTO channels (
                id, workspace_id, name, is_private, is_dm, topic, is_archived,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, 0, ?, 0, ?, ?)
            """,
            (
                channel_id,
                workspace_id,
                name,
                1 if is_private else 0,
                topic,
                now,
                now,
            ),
        )
    except sqlite3.IntegrityError as exc:
        raise ApiError(409, "conflict", "channel name already taken") from exc

    conn.execute(
        """
        INSERT INTO channel_members (channel_id, user_id, created_at)
        VALUES (?, ?, ?)
        """,
        (channel_id, creator_user_id, now),
    )
    return {
        "id": channel_id,
        "workspace_id": workspace_id,
        "name": name,
        "is_private": bool(is_private),
        "is_dm": False,
        "topic": topic,
        "is_archived": False,
    }


def create_general_channel(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    creator_user_id: str,
) -> dict[str, Any]:
    """Insert public #general and add creator as channel member. Returns ChannelObj."""
    channel_id = str(uuid.uuid4())
    now = utc_now_z()
    conn.execute(
        """
        INSERT INTO channels (
            id, workspace_id, name, is_private, is_dm, topic, is_archived,
            created_at, updated_at
        ) VALUES (?, ?, 'general', 0, 0, '', 0, ?, ?)
        """,
        (channel_id, workspace_id, now, now),
    )
    conn.execute(
        """
        INSERT INTO channel_members (channel_id, user_id, created_at)
        VALUES (?, ?, ?)
        """,
        (channel_id, creator_user_id, now),
    )
    return {
        "id": channel_id,
        "workspace_id": workspace_id,
        "name": "general",
        "is_private": False,
        "is_dm": False,
        "topic": "",
        "is_archived": False,
    }


def find_dm_by_name(
    conn: sqlite3.Connection, *, workspace_id: str, name: str
) -> dict[str, Any] | None:
    """Return ChannelObj for an is_dm row matching (workspace_id, name), else None."""
    row = conn.execute(
        """
        SELECT * FROM channels
        WHERE workspace_id = ? AND name = ? AND is_dm = 1
        """,
        (workspace_id, name),
    ).fetchone()
    if row is None:
        return None
    return row_to_channel_obj(row)


def create_dm_channel(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    name: str,
) -> dict[str, Any]:
    """Insert a private DM channel row (no members). Returns ChannelObj.

    Caller must supply a synthetic name that already satisfies CHANNEL_NAME_RE.
    On UNIQUE conflict, raises ApiError 409 without hijacking a non-DM row.
    """
    name = validate_channel_name(name)
    channel_id = str(uuid.uuid4())
    now = utc_now_z()
    try:
        conn.execute(
            """
            INSERT INTO channels (
                id, workspace_id, name, is_private, is_dm, topic, is_archived,
                created_at, updated_at
            ) VALUES (?, ?, ?, 1, 1, '', 0, ?, ?)
            """,
            (channel_id, workspace_id, name, now, now),
        )
    except sqlite3.IntegrityError as exc:
        existing = conn.execute(
            """
            SELECT * FROM channels
            WHERE workspace_id = ? AND name = ?
            """,
            (workspace_id, name),
        ).fetchone()
        if existing is not None and int(existing["is_dm"]) == 1:
            raise
        raise ApiError(
            409, "conflict", "channel name already taken"
        ) from exc
    return {
        "id": channel_id,
        "workspace_id": workspace_id,
        "name": name,
        "is_private": True,
        "is_dm": True,
        "topic": "",
        "is_archived": False,
    }


def list_channels_for_workspace_user(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    user_id: str,
    include_archived: bool,
) -> list[dict[str, Any]]:
    """Visible: member, or true public (is_dm=0 AND is_private=0). Archive filter."""
    rows = conn.execute(
        """
        SELECT c.*
        FROM channels c
        LEFT JOIN channel_members cm
            ON cm.channel_id = c.id AND cm.user_id = ?
        WHERE c.workspace_id = ?
          AND (
            (c.is_dm = 0 AND c.is_private = 0)
            OR cm.user_id IS NOT NULL
          )
          AND (? = 1 OR c.is_archived = 0)
        ORDER BY LOWER(c.name) ASC, c.name ASC
        """,
        (user_id, workspace_id, 1 if include_archived else 0),
    ).fetchall()
    return [row_to_channel_obj(row) for row in rows]


def list_read_state_for_channels(
    conn: sqlite3.Connection,
    *,
    user_id: str,
    channel_ids: list[str],
) -> list[dict[str, Any]]:
    """Full ReadStateEntry list for caller, only for the given visible channel ids."""
    if not channel_ids:
        return []
    placeholders = ",".join("?" for _ in channel_ids)
    rows = conn.execute(
        f"""
        SELECT channel_id, last_read_seq, unread_count, mention_count
        FROM channel_read_state
        WHERE user_id = ?
          AND channel_id IN ({placeholders})
        ORDER BY channel_id ASC
        """,
        (user_id, *channel_ids),
    ).fetchall()
    entries: list[dict[str, Any]] = []
    for row in rows:
        unread = row["unread_count"]
        mention = row["mention_count"]
        entries.append(
            {
                "channel_id": row["channel_id"],
                "last_read_seq": int(row["last_read_seq"] or 0),
                "unread_count": int(0 if unread is None else unread),
                "mention_count": int(0 if mention is None else mention),
            }
        )
    return entries


def list_members_as_users(
    conn: sqlite3.Connection, *, channel_id: str
) -> list[dict[str, Any]]:
    """Channel members as UserObj[], ordered by username ASC / id ASC."""
    rows = conn.execute(
        """
        SELECT u.*
        FROM channel_members cm
        INNER JOIN users u ON u.id = cm.user_id
        WHERE cm.channel_id = ?
        ORDER BY LOWER(u.username) ASC, u.id ASC
        """,
        (channel_id,),
    ).fetchall()
    return [row_to_user_obj(row) for row in rows]


def update_topic(
    conn: sqlite3.Connection, *, channel_id: str, topic: str
) -> dict[str, Any]:
    topic = validate_topic(topic)
    now = utc_now_z()
    conn.execute(
        """
        UPDATE channels
        SET topic = ?, updated_at = ?
        WHERE id = ?
        """,
        (topic, now, channel_id),
    )
    channel = get_channel(conn, channel_id)
    if channel is None:
        raise ApiError(404, "not_found", "channel not found")
    return channel


def set_archived(
    conn: sqlite3.Connection, *, channel_id: str, archived: bool
) -> dict[str, Any]:
    now = utc_now_z()
    conn.execute(
        """
        UPDATE channels
        SET is_archived = ?, updated_at = ?
        WHERE id = ?
        """,
        (1 if archived else 0, now, channel_id),
    )
    channel = get_channel(conn, channel_id)
    if channel is None:
        raise ApiError(404, "not_found", "channel not found")
    return channel


def list_pins_for_channel(
    conn: sqlite3.Connection, *, channel_id: str
) -> list[dict[str, Any]]:
    """Pin list entries newest-first. Caller embeds MessageObj separately."""
    rows = conn.execute(
        """
        SELECT message_id, channel_id, pinned_by, pinned_at
        FROM channel_pins
        WHERE channel_id = ?
        ORDER BY pinned_at DESC, message_id DESC
        """,
        (channel_id,),
    ).fetchall()
    return [
        {
            "message_id": row["message_id"],
            "channel_id": row["channel_id"],
            "pinned_by": row["pinned_by"],
            "pinned_at": row["pinned_at"],
        }
        for row in rows
    ]


def get_pin(
    conn: sqlite3.Connection, *, message_id: str
) -> dict[str, Any] | None:
    row = conn.execute(
        """
        SELECT message_id, channel_id, pinned_by, pinned_at
        FROM channel_pins
        WHERE message_id = ?
        """,
        (message_id,),
    ).fetchone()
    if row is None:
        return None
    return {
        "message_id": row["message_id"],
        "channel_id": row["channel_id"],
        "pinned_by": row["pinned_by"],
        "pinned_at": row["pinned_at"],
    }


def insert_pin(
    conn: sqlite3.Connection,
    *,
    message_id: str,
    channel_id: str,
    pinned_by: str,
) -> dict[str, Any]:
    """Insert pin or return existing (idempotent; keeps first pinner/time)."""
    existing = get_pin(conn, message_id=message_id)
    if existing is not None:
        return {
            "message_id": existing["message_id"],
            "pinned_by": existing["pinned_by"],
            "pinned_at": existing["pinned_at"],
        }
    now = utc_now_z()
    try:
        conn.execute(
            """
            INSERT INTO channel_pins (message_id, channel_id, pinned_by, pinned_at)
            VALUES (?, ?, ?, ?)
            """,
            (message_id, channel_id, pinned_by, now),
        )
    except sqlite3.IntegrityError:
        existing = get_pin(conn, message_id=message_id)
        if existing is not None:
            return {
                "message_id": existing["message_id"],
                "pinned_by": existing["pinned_by"],
                "pinned_at": existing["pinned_at"],
            }
        raise
    return {
        "message_id": message_id,
        "pinned_by": pinned_by,
        "pinned_at": now,
    }


def delete_pin(conn: sqlite3.Connection, *, message_id: str) -> None:
    """Delete pin row; no-op if absent."""
    conn.execute(
        "DELETE FROM channel_pins WHERE message_id = ?", (message_id,)
    )
