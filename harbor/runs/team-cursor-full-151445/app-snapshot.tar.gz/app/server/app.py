"""FastAPI application factory for a Huddle HTTP node."""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from server import db
from server.auth.routes import router as auth_router
from server.channels.routes import router as channels_router
from server.dms.routes import router as dms_router
from server.errors import register_exception_handlers
from server.groups.routes import router as groups_router
from server.invitations.routes import router as invitations_router
from server.messages.routes import router as messages_router
from server.settings import Settings, load_settings
from server.users.routes import router as users_router
from server.workspaces.routes import router as workspaces_router

APP_ROOT = Path(__file__).resolve().parent.parent
STATIC_DIR = APP_ROOT / "static"
INDEX_HTML = STATIC_DIR / "index.html"


def create_app(settings: Settings | None = None) -> FastAPI:
    """Build the FastAPI app for one node."""
    cfg = settings if settings is not None else load_settings()

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        # Idempotent; also applied eagerly below so TestClient without
        # lifespan context still sees migrated schema.
        db.ensure_schema(cfg.sqlite_path)
        yield

    # Apply schema at construction so unit tests and early imports are safe.
    db.ensure_schema(cfg.sqlite_path)

    application = FastAPI(title="Huddle", lifespan=lifespan)
    application.state.settings = cfg
    register_exception_handlers(application)
    application.include_router(auth_router)
    application.include_router(users_router)
    application.include_router(workspaces_router)
    application.include_router(groups_router)
    application.include_router(invitations_router)
    application.include_router(channels_router)
    application.include_router(dms_router)
    application.include_router(messages_router)

    @application.get("/api/health")
    def health() -> JSONResponse:
        return JSONResponse(
            content={"status": "ok", "node_id": cfg.node_id},
            status_code=200,
        )

    @application.get("/")
    def root() -> FileResponse:
        return FileResponse(
            INDEX_HTML,
            media_type="text/html",
        )

    application.mount(
        "/static",
        StaticFiles(directory=str(STATIC_DIR)),
        name="static",
    )

    return application


# Uvicorn target: server.app:app (HUDDLE_NODE_ID must be set by start.sh).
# Avoid constructing at import time during unit tests with no env.
app: FastAPI | None
if os.environ.get("HUDDLE_NODE_ID"):
    app = create_app()
else:
    app = None
