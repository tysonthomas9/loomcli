"""Profiles HTTP routes: GET /api/users/{id}, PATCH /api/users/me."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict

from server import db
from server.auth import users
from server.auth.deps import get_current_user
from server.errors import ApiError
from server.events import publish_user_updated
from server.settings import Settings

router = APIRouter(prefix="/api/users", tags=["users"])


class PatchMeBody(BaseModel):
    """Mutable profile fields; omit = leave unchanged; unknown keys ignored."""

    model_config = ConfigDict(extra="ignore")

    display_name: str | None = None
    timezone: str | None = None
    avatar_url: str | None = None
    status_text: str | None = None
    status_emoji: str | None = None


def _settings(request: Request) -> Settings:
    return request.app.state.settings


@router.patch("/me")
def patch_me(
    body: PatchMeBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    # Only keys explicitly present in the JSON body (exclude_unset).
    patch = body.model_dump(exclude_unset=True)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        user, changed = users.update_user_profile(conn, caller["id"], patch)
        conn.commit()
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    if changed:
        publish_user_updated(user)
    return {"user": user}


@router.get("/{user_id}")
def get_user(
    user_id: str,
    request: Request,
    _caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        user = users.get_user_by_id(conn, user_id)
        if user is None:
            raise ApiError(404, "not_found", "user not found")
        return {"user": user}
    finally:
        conn.close()
