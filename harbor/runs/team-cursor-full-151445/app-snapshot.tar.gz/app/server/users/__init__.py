"""Profiles / user directory HTTP surface."""

from server.users.routes import router

__all__ = ["router"]
