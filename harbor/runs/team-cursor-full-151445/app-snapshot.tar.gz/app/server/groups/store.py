"""User group persistence, validation, and GroupObj mapping."""

from __future__ import annotations

import re
import sqlite3
import uuid
from typing import Any

from server.auth.users import USERNAME_RE
from server.db import utc_now_z
from server.errors import ApiError
from server.workspaces import store as workspaces_store

GROUP_OBJ_KEYS = (
    "id",
    "handle",
    "name",
    "member_user_ids",
)

HANDLE_RE = USERNAME_RE
NAME_MAX = 80


def validate_handle(handle: str) -> str:
    if not isinstance(handle, str) or not HANDLE_RE.fullmatch(handle):
        raise ApiError(400, "validation_error", "invalid handle")
    return handle


def validate_group_name(name: str) -> str:
    if not isinstance(name, str):
        raise ApiError(400, "validation_error", "name is required")
    stripped = name.strip()
    if not stripped:
        raise ApiError(400, "validation_error", "name is required")
    if len(stripped) > NAME_MAX:
        raise ApiError(400, "validation_error", "name is too long")
    return stripped


def _normalize_user_ids(user_ids: Any) -> list[str]:
    if user_ids is None:
        return []
    if not isinstance(user_ids, list):
        raise ApiError(400, "validation_error", "user_ids must be an array")
    out: list[str] = []
    seen: set[str] = set()
    for item in user_ids:
        if not isinstance(item, str) or not item:
            raise ApiError(400, "validation_error", "invalid user_ids entry")
        if item in seen:
            continue
        seen.add(item)
        out.append(item)
    return out


def validate_member_user_ids(
    conn: sqlite3.Connection, *, workspace_id: str, user_ids: Any
) -> list[str]:
    """Dedupe and require every id to be a current workspace member."""
    ids = _normalize_user_ids(user_ids)
    for user_id in ids:
        role = workspaces_store.get_member_role(
            conn, workspace_id=workspace_id, user_id=user_id
        )
        if role is None:
            raise ApiError(
                400,
                "validation_error",
                "user_ids must contain only workspace members",
            )
    return ids


def _member_ids_for_group(
    conn: sqlite3.Connection, group_id: str
) -> list[str]:
    rows = conn.execute(
        """
        SELECT user_id FROM user_group_members
        WHERE group_id = ?
        ORDER BY user_id ASC
        """,
        (group_id,),
    ).fetchall()
    return [str(row["user_id"]) for row in rows]


def row_to_group_obj(
    conn: sqlite3.Connection, row: sqlite3.Row | dict[str, Any]
) -> dict[str, Any]:
    get = row.__getitem__
    group_id = get("id")
    return {
        "id": group_id,
        "handle": get("handle"),
        "name": get("name"),
        "member_user_ids": _member_ids_for_group(conn, group_id),
    }


def _replace_members(
    conn: sqlite3.Connection, *, group_id: str, user_ids: list[str]
) -> None:
    now = utc_now_z()
    conn.execute(
        "DELETE FROM user_group_members WHERE group_id = ?", (group_id,)
    )
    for user_id in user_ids:
        conn.execute(
            """
            INSERT INTO user_group_members (group_id, user_id, created_at)
            VALUES (?, ?, ?)
            """,
            (group_id, user_id, now),
        )


def list_groups(
    conn: sqlite3.Connection, *, workspace_id: str
) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT * FROM user_groups
        WHERE workspace_id = ?
        ORDER BY handle ASC
        """,
        (workspace_id,),
    ).fetchall()
    return [row_to_group_obj(conn, row) for row in rows]


def get_group_by_handle(
    conn: sqlite3.Connection, *, workspace_id: str, handle: str
) -> dict[str, Any] | None:
    row = conn.execute(
        """
        SELECT * FROM user_groups
        WHERE workspace_id = ? AND handle = ?
        """,
        (workspace_id, handle),
    ).fetchone()
    if row is None:
        return None
    return row_to_group_obj(conn, row)


def get_group_row_by_handle(
    conn: sqlite3.Connection, *, workspace_id: str, handle: str
) -> sqlite3.Row | None:
    return conn.execute(
        """
        SELECT * FROM user_groups
        WHERE workspace_id = ? AND handle = ?
        """,
        (workspace_id, handle),
    ).fetchone()


def create_group(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    created_by: str,
    handle: str,
    name: str,
    user_ids: Any = None,
) -> dict[str, Any]:
    handle = validate_handle(handle)
    name = validate_group_name(name)
    member_ids = validate_member_user_ids(
        conn, workspace_id=workspace_id, user_ids=user_ids
    )
    group_id = str(uuid.uuid4())
    now = utc_now_z()
    try:
        conn.execute(
            """
            INSERT INTO user_groups (
                id, workspace_id, handle, name, created_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (group_id, workspace_id, handle, name, created_by, now, now),
        )
    except sqlite3.IntegrityError as exc:
        raise ApiError(409, "conflict", "handle already taken") from exc
    _replace_members(conn, group_id=group_id, user_ids=member_ids)
    row = conn.execute(
        "SELECT * FROM user_groups WHERE id = ?", (group_id,)
    ).fetchone()
    assert row is not None
    return row_to_group_obj(conn, row)


def update_group(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    handle: str,
    patch: dict[str, Any],
) -> dict[str, Any]:
    row = get_group_row_by_handle(
        conn, workspace_id=workspace_id, handle=handle
    )
    if row is None:
        raise ApiError(404, "not_found", "group not found")

    sets: list[str] = []
    values: list[Any] = []
    changed = False

    if "name" in patch:
        raw = patch["name"]
        if raw is None:
            raise ApiError(400, "validation_error", "name cannot be null")
        name = validate_group_name(raw)
        if name != row["name"]:
            sets.append("name = ?")
            values.append(name)
            changed = True

    if "user_ids" in patch:
        member_ids = validate_member_user_ids(
            conn, workspace_id=workspace_id, user_ids=patch["user_ids"]
        )
        _replace_members(conn, group_id=row["id"], user_ids=member_ids)
        changed = True

    if changed:
        sets.append("updated_at = ?")
        values.append(utc_now_z())
        values.append(row["id"])
        conn.execute(
            f"UPDATE user_groups SET {', '.join(sets)} WHERE id = ?",
            values,
        )

    updated = get_group_by_handle(
        conn, workspace_id=workspace_id, handle=handle
    )
    assert updated is not None
    return updated


def delete_group(
    conn: sqlite3.Connection, *, workspace_id: str, handle: str
) -> None:
    row = get_group_row_by_handle(
        conn, workspace_id=workspace_id, handle=handle
    )
    if row is None:
        raise ApiError(404, "not_found", "group not found")
    conn.execute("DELETE FROM user_groups WHERE id = ?", (row["id"],))
