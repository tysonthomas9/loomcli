"""HTTP routes for workspace user groups."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field

from server import db
from server.auth.deps import get_current_user
from server.errors import ApiError
from server.groups import store as groups_store
from server.settings import Settings
from server.workspaces import store as workspaces_store

router = APIRouter(prefix="/api/workspaces", tags=["groups"])


class CreateGroupBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    handle: str
    name: str
    user_ids: list[str] = Field(default_factory=list)


class PatchGroupBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str | None = None
    user_ids: list[str] | None = None


def _settings(request: Request) -> Settings:
    return request.app.state.settings


def _require_member_workspace(
    conn: Any,
    *,
    slug: str,
    user_id: str,
) -> tuple[dict[str, Any], str]:
    workspace = workspaces_store.get_workspace_by_slug(conn, slug)
    if workspace is None:
        raise ApiError(404, "not_found", "workspace not found")
    role = workspaces_store.get_member_role(
        conn, workspace_id=workspace["id"], user_id=user_id
    )
    if role is None:
        raise ApiError(404, "not_found", "workspace not found")
    return workspace, role


def _require_group_mutator(
    *,
    workspace: dict[str, Any],
    role: str,
    group_row: Any,
    caller_id: str,
) -> None:
    """Creator or workspace owner may mutate; others → 403."""
    is_creator = group_row["created_by"] == caller_id
    is_owner = (
        role == "owner" or workspace["owner_id"] == caller_id
    )
    if not (is_creator or is_owner):
        raise ApiError(403, "forbidden", "creator or owner role required")


@router.get("/{slug}/groups")
def list_groups(
    slug: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        workspace, _role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        groups = groups_store.list_groups(
            conn, workspace_id=workspace["id"]
        )
        return {"groups": groups}
    finally:
        conn.close()


@router.post("/{slug}/groups", status_code=201)
def create_group(
    slug: str,
    body: CreateGroupBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        if role == "guest":
            raise ApiError(403, "forbidden", "guests cannot create groups")
        group = groups_store.create_group(
            conn,
            workspace_id=workspace["id"],
            created_by=caller["id"],
            handle=body.handle,
            name=body.name,
            user_ids=body.user_ids,
        )
        conn.commit()
        return {"group": group}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.patch("/{slug}/groups/{handle}")
def patch_group(
    slug: str,
    handle: str,
    body: PatchGroupBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    patch = body.model_dump(exclude_unset=True)
    # handle is not patchable even if sent (extra=ignore already drops unknown).
    patch.pop("handle", None)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        group_row = groups_store.get_group_row_by_handle(
            conn, workspace_id=workspace["id"], handle=handle
        )
        if group_row is None:
            raise ApiError(404, "not_found", "group not found")
        _require_group_mutator(
            workspace=workspace,
            role=role,
            group_row=group_row,
            caller_id=caller["id"],
        )
        group = groups_store.update_group(
            conn,
            workspace_id=workspace["id"],
            handle=handle,
            patch=patch,
        )
        conn.commit()
        return {"group": group}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.delete("/{slug}/groups/{handle}")
def delete_group(
    slug: str,
    handle: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        group_row = groups_store.get_group_row_by_handle(
            conn, workspace_id=workspace["id"], handle=handle
        )
        if group_row is None:
            raise ApiError(404, "not_found", "group not found")
        _require_group_mutator(
            workspace=workspace,
            role=role,
            group_row=group_row,
            caller_id=caller["id"],
        )
        groups_store.delete_group(
            conn, workspace_id=workspace["id"], handle=handle
        )
        conn.commit()
        return {"deleted": True}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
