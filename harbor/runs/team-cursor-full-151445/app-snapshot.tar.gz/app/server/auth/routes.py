"""Auth HTTP routes: register, login, me."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field

from server import db
from server.auth import tokens, users
from server.auth.deps import get_current_user
from server.auth.passwords import verify_password
from server.errors import ApiError
from server.settings import Settings

router = APIRouter(prefix="/api/auth", tags=["auth"])


class RegisterBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    username: str
    password: str
    display_name: str | None = None


class LoginBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    username: str = Field(min_length=1)
    password: str


def _settings(request: Request) -> Settings:
    return request.app.state.settings


@router.post("/register", status_code=201)
def register(body: RegisterBody, request: Request) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        user = users.create_user(
            conn,
            username=body.username,
            password=body.password,
            display_name=body.display_name,
        )
        raw_token = tokens.mint_raw_token()
        tokens.insert_token(conn, user["id"], raw_token)
        conn.commit()
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"user": user, "token": raw_token}


@router.post("/login")
def login(body: LoginBody, request: Request) -> dict[str, Any]:
    settings = _settings(request)
    # Empty username caught by Field(min_length=1) → 400 envelope via handler.
    # Invalid username pattern on login still 401 (unknown user), not 400 —
    # but empty string is validation. Non-matching slug that doesn't exist → 401.
    if not isinstance(body.username, str) or body.username == "":
        raise ApiError(400, "validation_error", "username is required")
    if not isinstance(body.password, str) or body.password == "":
        raise ApiError(400, "validation_error", "password is required")

    conn = db.connect(settings.sqlite_path)
    try:
        row = users.get_user_row_by_username(conn, body.username)
        if row is None or not verify_password(body.password, row["password_hash"]):
            raise ApiError(401, "unauthorized", "invalid username or password")
        user = users.row_to_user_obj(row)
        raw_token = tokens.mint_raw_token()
        tokens.insert_token(conn, user["id"], raw_token)
        conn.commit()
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"user": user, "token": raw_token}


@router.get("/me")
def me(user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
    return {"user": user}
