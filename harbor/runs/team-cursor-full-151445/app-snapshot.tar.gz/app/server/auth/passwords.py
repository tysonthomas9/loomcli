"""Password hashing helpers (stdlib scrypt)."""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets

# Format: scrypt$N=2^14$r=8$p=1$<salt_b64>$<hash_b64>
_SCRYPT_N = 2**14
_SCRYPT_R = 8
_SCRYPT_P = 1
_SCRYPT_DKLEN = 64
_SALT_BYTES = 16


def hash_password(password: str) -> str:
    """Hash a password with scrypt; return encoded parameter string."""
    salt = secrets.token_bytes(_SALT_BYTES)
    digest = hashlib.scrypt(
        password.encode("utf-8"),
        salt=salt,
        n=_SCRYPT_N,
        r=_SCRYPT_R,
        p=_SCRYPT_P,
        dklen=_SCRYPT_DKLEN,
    )
    salt_b64 = base64.b64encode(salt).decode("ascii")
    hash_b64 = base64.b64encode(digest).decode("ascii")
    return f"scrypt$N=2^14$r=8$p=1${salt_b64}${hash_b64}"


def verify_password(password: str, encoded: str) -> bool:
    """Verify password against stored scrypt encoding (constant-time compare)."""
    try:
        parts = encoded.split("$")
        # scrypt, N=2^14, r=8, p=1, salt, hash
        if len(parts) != 6 or parts[0] != "scrypt":
            return False
        n_spec = parts[1]
        if not n_spec.startswith("N="):
            return False
        n_expr = n_spec[2:]
        if n_expr.startswith("2^"):
            n = 2 ** int(n_expr[2:])
        else:
            n = int(n_expr)
        r = int(parts[2].split("=", 1)[1])
        p = int(parts[3].split("=", 1)[1])
        salt = base64.b64decode(parts[4].encode("ascii"))
        expected = base64.b64decode(parts[5].encode("ascii"))
    except (ValueError, IndexError, TypeError):
        return False

    digest = hashlib.scrypt(
        password.encode("utf-8"),
        salt=salt,
        n=n,
        r=r,
        p=p,
        dklen=len(expected),
    )
    return hmac.compare_digest(digest, expected)
