"""User persistence and UserObj mapping."""

from __future__ import annotations

import re
import sqlite3
import uuid
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from server.auth.passwords import hash_password
from server.db import utc_now_z
from server.errors import ApiError

USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{1,31}$")
USER_OBJ_KEYS = (
    "id",
    "username",
    "display_name",
    "timezone",
    "avatar_url",
    "status_text",
    "status_emoji",
)

# Profile PATCH length limits (Unicode code points).
DISPLAY_NAME_MAX = 80
TIMEZONE_MAX = 64
AVATAR_URL_MAX = 2048
STATUS_TEXT_MAX = 100
STATUS_EMOJI_MAX = 64


def validate_username(username: str) -> str:
    if not isinstance(username, str) or not USERNAME_RE.fullmatch(username):
        raise ApiError(400, "validation_error", "invalid username")
    return username


def validate_password(password: str) -> str:
    if not isinstance(password, str):
        raise ApiError(400, "validation_error", "password is required")
    length = len(password)
    if length < 8:
        raise ApiError(
            400, "validation_error", "password must be at least 8 characters"
        )
    if length > 128:
        raise ApiError(
            400, "validation_error", "password must be at most 128 characters"
        )
    return password


def normalize_display_name(display_name: str | None, username: str) -> str:
    if display_name is None:
        return username
    if not isinstance(display_name, str):
        raise ApiError(400, "validation_error", "invalid display_name")
    stripped = display_name.strip()
    if not stripped:
        return username
    return stripped


def row_to_user_obj(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    get = row.__getitem__
    return {
        "id": get("id"),
        "username": get("username"),
        "display_name": get("display_name"),
        "timezone": get("timezone"),
        "avatar_url": get("avatar_url"),
        "status_text": get("status_text"),
        "status_emoji": get("status_emoji"),
    }


def get_user_by_id(conn: sqlite3.Connection, user_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        return None
    return row_to_user_obj(row)


def get_user_row_by_username(
    conn: sqlite3.Connection, username: str
) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM users WHERE username = ?", (username,)
    ).fetchone()


def create_user(
    conn: sqlite3.Connection,
    *,
    username: str,
    password: str,
    display_name: str | None,
) -> dict[str, Any]:
    username = validate_username(username)
    validate_password(password)
    display = normalize_display_name(display_name, username)
    user_id = str(uuid.uuid4())
    now = utc_now_z()
    password_hash = hash_password(password)
    try:
        conn.execute(
            """
            INSERT INTO users (
                id, username, password_hash, display_name,
                timezone, avatar_url, status_text, status_emoji,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, NULL, NULL, NULL, NULL, ?, ?)
            """,
            (user_id, username, password_hash, display, now, now),
        )
    except sqlite3.IntegrityError as exc:
        raise ApiError(409, "conflict", "username already taken") from exc
    return {
        "id": user_id,
        "username": username,
        "display_name": display,
        "timezone": None,
        "avatar_url": None,
        "status_text": None,
        "status_emoji": None,
    }


def validate_profile_display_name(value: str | None, username: str) -> str:
    """Normalize PATCH display_name; null/blank → username; max 80 code points."""
    if value is None:
        return username
    if not isinstance(value, str):
        raise ApiError(400, "validation_error", "invalid display_name")
    stripped = value.strip()
    if not stripped:
        return username
    if len(stripped) > DISPLAY_NAME_MAX:
        raise ApiError(400, "validation_error", "display_name is too long")
    return stripped


def validate_profile_timezone(value: str | None) -> str | None:
    """Validate IANA timezone; null/\"\" → SQL NULL. Store client string as given."""
    if value is None or value == "":
        return None
    if not isinstance(value, str):
        raise ApiError(400, "validation_error", "invalid timezone")
    if len(value) > TIMEZONE_MAX:
        raise ApiError(400, "validation_error", "timezone is too long")
    try:
        ZoneInfo(value)
    except (ZoneInfoNotFoundError, ValueError, OSError) as exc:
        raise ApiError(400, "validation_error", "invalid timezone") from exc
    return value


def validate_nullable_profile_string(
    value: str | None, *, field: str, max_len: int
) -> str | None:
    """null/\"\" → NULL; otherwise require string length 1..max_len."""
    if value is None or value == "":
        return None
    if not isinstance(value, str):
        raise ApiError(400, "validation_error", f"invalid {field}")
    length = len(value)
    if length < 1 or length > max_len:
        raise ApiError(400, "validation_error", f"{field} is too long")
    return value


def update_user_profile(
    conn: sqlite3.Connection,
    user_id: str,
    patch: dict[str, Any],
) -> tuple[dict[str, Any], bool]:
    """Apply a validated mutable-field subset. Returns (UserObj, changed)."""
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise ApiError(401, "unauthorized", "unauthorized")

    username = row["username"]
    proposed: dict[str, Any] = {}

    if "display_name" in patch:
        proposed["display_name"] = validate_profile_display_name(
            patch["display_name"], username
        )
    if "timezone" in patch:
        proposed["timezone"] = validate_profile_timezone(patch["timezone"])
    if "avatar_url" in patch:
        proposed["avatar_url"] = validate_nullable_profile_string(
            patch["avatar_url"], field="avatar_url", max_len=AVATAR_URL_MAX
        )
    if "status_text" in patch:
        proposed["status_text"] = validate_nullable_profile_string(
            patch["status_text"], field="status_text", max_len=STATUS_TEXT_MAX
        )
    if "status_emoji" in patch:
        proposed["status_emoji"] = validate_nullable_profile_string(
            patch["status_emoji"], field="status_emoji", max_len=STATUS_EMOJI_MAX
        )

    changed = {key: val for key, val in proposed.items() if row[key] != val}
    if not changed:
        return row_to_user_obj(row), False

    changed["updated_at"] = utc_now_z()
    assignments = ", ".join(f"{col} = ?" for col in changed)
    conn.execute(
        f"UPDATE users SET {assignments} WHERE id = ?",
        (*changed.values(), user_id),
    )
    updated = get_user_by_id(conn, user_id)
    assert updated is not None
    return updated, True
