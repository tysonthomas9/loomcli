"""Opaque bearer token minting and SQLite persistence."""

from __future__ import annotations

import hashlib
import secrets
import sqlite3

from server.db import utc_now_z


def hash_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode("ascii")).hexdigest()


def mint_raw_token() -> str:
    """Return a new opaque bearer token (length always >= 16)."""
    return secrets.token_urlsafe(32)


def insert_token(conn: sqlite3.Connection, user_id: str, raw_token: str) -> None:
    """Persist SHA-256 hex of raw_token for user_id."""
    conn.execute(
        """
        INSERT INTO auth_tokens (token_hash, user_id, created_at)
        VALUES (?, ?, ?)
        """,
        (hash_token(raw_token), user_id, utc_now_z()),
    )


def resolve_user_id(conn: sqlite3.Connection, raw_token: str) -> str | None:
    """Look up user_id by hashing the presented bearer token."""
    if not raw_token or any(ch.isspace() for ch in raw_token):
        return None
    row = conn.execute(
        "SELECT user_id FROM auth_tokens WHERE token_hash = ?",
        (hash_token(raw_token),),
    ).fetchone()
    if row is None:
        return None
    return str(row["user_id"])
