"""Auth package: register/login/me and bearer dependency."""

from server.auth.deps import get_current_user
from server.auth.routes import router

__all__ = ["get_current_user", "router"]
