"""FastAPI auth dependency: resolve Bearer token to UserObj."""

from __future__ import annotations

from typing import Any

from fastapi import Request

from server import db
from server.auth import tokens, users
from server.errors import ApiError
from server.settings import Settings


def _unauthorized(message: str = "unauthorized") -> ApiError:
    return ApiError(401, "unauthorized", message)


def parse_bearer_token(authorization: str | None) -> str:
    """Extract opaque token from Authorization header or raise 401."""
    if authorization is None or authorization == "":
        raise _unauthorized()
    parts = authorization.split(" ", 1)
    if len(parts) != 2:
        raise _unauthorized()
    scheme, token = parts[0], parts[1]
    if scheme.lower() != "bearer":
        raise _unauthorized()
    if not token or any(ch.isspace() for ch in token):
        raise _unauthorized()
    return token


def get_current_user(request: Request) -> dict[str, Any]:
    """Resolve Authorization Bearer → UserObj (raises ApiError on failure)."""
    settings: Settings = request.app.state.settings
    raw = parse_bearer_token(request.headers.get("Authorization"))
    conn = db.connect(settings.sqlite_path)
    try:
        user_id = tokens.resolve_user_id(conn, raw)
        if user_id is None:
            raise _unauthorized()
        user = users.get_user_by_id(conn, user_id)
        if user is None:
            raise _unauthorized()
        return user
    finally:
        conn.close()
