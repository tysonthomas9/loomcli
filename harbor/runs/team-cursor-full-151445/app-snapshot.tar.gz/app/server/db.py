"""Shared SQLite bootstrap and schema migrations for Huddle nodes."""

from __future__ import annotations

import os
import sqlite3
from datetime import datetime, timezone
from typing import Callable


def utc_now_z() -> str:
    """UTC timestamp as YYYY-MM-DDTHH:MM:SSZ."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def connect(sqlite_path: str) -> sqlite3.Connection:
    """Open SQLite with WAL, busy_timeout, and foreign_keys (every call)."""
    parent = os.path.dirname(sqlite_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    conn = sqlite3.connect(sqlite_path, timeout=5.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def connect_and_bootstrap(sqlite_path: str) -> sqlite3.Connection:
    """Open the shared DB with WAL pragmas and ensure schema_migrations exists."""
    conn = connect(sqlite_path)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version INTEGER PRIMARY KEY,
            applied_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    return conn


def ensure_bootstrap(sqlite_path: str) -> None:
    """Create the DB file and bootstrap table, then close."""
    conn = connect_and_bootstrap(sqlite_path)
    # Record bootstrap version 0 if empty (idempotent).
    row = conn.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()
    if row is not None and row[0] == 0:
        conn.execute(
            "INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)",
            (0, utc_now_z()),
        )
        conn.commit()
    conn.close()


def _migrate_v1(conn: sqlite3.Connection) -> None:
    """Create users and auth_tokens tables (additive)."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id TEXT NOT NULL PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            display_name TEXT NOT NULL,
            timezone TEXT,
            avatar_url TEXT,
            status_text TEXT,
            status_emoji TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS auth_tokens (
            token_hash TEXT NOT NULL PRIMARY KEY,
            user_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_auth_tokens_user_id
            ON auth_tokens(user_id);
        """
    )


def _reverse_v1(conn: sqlite3.Connection) -> None:
    """Drop auth_tokens and users (local reverse verification only)."""
    conn.executescript(
        """
        DROP TABLE IF EXISTS auth_tokens;
        DROP TABLE IF EXISTS users;
        """
    )


def _migrate_v2(conn: sqlite3.Connection) -> None:
    """Create workspaces, members, channels, and channel_read_state (additive)."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS workspaces (
            id TEXT NOT NULL PRIMARY KEY,
            slug TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            owner_id TEXT NOT NULL,
            join_mode TEXT NOT NULL DEFAULT 'open'
                CHECK (join_mode IN ('open', 'invite_only')),
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (owner_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS workspace_members (
            workspace_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            role TEXT NOT NULL
                CHECK (role IN ('owner', 'admin', 'member', 'guest')),
            created_at TEXT NOT NULL,
            PRIMARY KEY (workspace_id, user_id),
            FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_workspace_members_user_id
            ON workspace_members(user_id);

        CREATE TABLE IF NOT EXISTS channels (
            id TEXT NOT NULL PRIMARY KEY,
            workspace_id TEXT NOT NULL,
            name TEXT NOT NULL,
            is_private INTEGER NOT NULL DEFAULT 0,
            is_dm INTEGER NOT NULL DEFAULT 0,
            topic TEXT NOT NULL DEFAULT '',
            is_archived INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE (workspace_id, name),
            FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS channel_members (
            channel_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY (channel_id, user_id),
            FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS channel_read_state (
            channel_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            last_read_seq INTEGER NOT NULL DEFAULT 0,
            unread_count INTEGER NOT NULL DEFAULT 0,
            mention_count INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (channel_id, user_id),
            FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        """
    )


def _reverse_v2(conn: sqlite3.Connection) -> None:
    """Drop v2 workspace/channel tables (local reverse verification only)."""
    conn.executescript(
        """
        DROP TABLE IF EXISTS channel_read_state;
        DROP TABLE IF EXISTS channel_members;
        DROP TABLE IF EXISTS channels;
        DROP TABLE IF EXISTS workspace_members;
        DROP TABLE IF EXISTS workspaces;
        """
    )


def _migrate_v3(conn: sqlite3.Connection) -> None:
    """Create minimal messages + channel_pins (additive; MARATHON-8 extends messages)."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS messages (
            id TEXT NOT NULL PRIMARY KEY,
            channel_id TEXT NOT NULL,
            author_id TEXT NOT NULL,
            body TEXT NOT NULL,
            parent_id TEXT,
            created_at TEXT NOT NULL,
            edited_at TEXT,
            deleted_at TEXT,
            FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE,
            FOREIGN KEY (author_id) REFERENCES users(id),
            FOREIGN KEY (parent_id) REFERENCES messages(id)
        );

        CREATE INDEX IF NOT EXISTS idx_messages_channel_id
            ON messages(channel_id);

        CREATE TABLE IF NOT EXISTS channel_pins (
            message_id TEXT NOT NULL PRIMARY KEY,
            channel_id TEXT NOT NULL,
            pinned_by TEXT NOT NULL,
            pinned_at TEXT NOT NULL,
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE,
            FOREIGN KEY (pinned_by) REFERENCES users(id)
        );

        CREATE INDEX IF NOT EXISTS idx_channel_pins_channel_pinned_at
            ON channel_pins(channel_id, pinned_at DESC);
        """
    )


def _reverse_v3(conn: sqlite3.Connection) -> None:
    """Drop v3 messages/pins tables (local reverse verification only)."""
    conn.executescript(
        """
        DROP TABLE IF EXISTS channel_pins;
        DROP TABLE IF EXISTS messages;
        """
    )


def _migrate_v4(conn: sqlite3.Connection) -> None:
    """Create user_groups, members, and workspace_invitations (additive)."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS user_groups (
            id TEXT NOT NULL PRIMARY KEY,
            workspace_id TEXT NOT NULL,
            handle TEXT NOT NULL,
            name TEXT NOT NULL,
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE (workspace_id, handle),
            FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
            FOREIGN KEY (created_by) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS user_group_members (
            group_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY (group_id, user_id),
            FOREIGN KEY (group_id) REFERENCES user_groups(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_user_group_members_user_id
            ON user_group_members(user_id);

        CREATE TABLE IF NOT EXISTS workspace_invitations (
            id TEXT NOT NULL PRIMARY KEY,
            workspace_id TEXT NOT NULL,
            code TEXT NOT NULL UNIQUE,
            created_by TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT,
            max_uses INTEGER NOT NULL,
            use_count INTEGER NOT NULL DEFAULT 0,
            invited_user_id TEXT,
            invited_username TEXT,
            revoked_at TEXT,
            FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
            FOREIGN KEY (created_by) REFERENCES users(id),
            FOREIGN KEY (invited_user_id) REFERENCES users(id)
        );

        CREATE INDEX IF NOT EXISTS idx_workspace_invitations_workspace_id
            ON workspace_invitations(workspace_id);
        """
    )


def _reverse_v4(conn: sqlite3.Connection) -> None:
    """Drop v4 groups/invitations tables (local reverse verification only)."""
    conn.executescript(
        """
        DROP TABLE IF EXISTS workspace_invitations;
        DROP TABLE IF EXISTS user_group_members;
        DROP TABLE IF EXISTS user_groups;
        """
    )


def _migrate_v5(conn: sqlite3.Connection) -> None:
    """Add message reactions/files join, blocks_json, history indexes (MARATHON-8).

    Version 5: design text said v4, but v4 is already user_groups/invitations
    (MARATHON-12). Additive only — does not recreate v3 ``messages``.
    """
    cols = {
        row[1] for row in conn.execute("PRAGMA table_info(messages)").fetchall()
    }
    if "blocks_json" not in cols:
        conn.execute("ALTER TABLE messages ADD COLUMN blocks_json TEXT")

    conn.executescript(
        """
        CREATE INDEX IF NOT EXISTS idx_messages_channel_created
            ON messages(channel_id, created_at DESC, id DESC);

        CREATE INDEX IF NOT EXISTS idx_messages_parent_created
            ON messages(parent_id, created_at ASC, id ASC);

        CREATE TABLE IF NOT EXISTS message_reactions (
            message_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            emoji TEXT NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY (message_id, user_id, emoji),
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE INDEX IF NOT EXISTS idx_message_reactions_message_created
            ON message_reactions(message_id, created_at ASC);

        CREATE TABLE IF NOT EXISTS message_files (
            message_id TEXT NOT NULL,
            file_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY (message_id, file_id),
            UNIQUE (file_id),
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
        );
        """
    )


def _reverse_v5(conn: sqlite3.Connection) -> None:
    """Drop v5 reaction/file objects (blocks_json column retained; SQLite)."""
    conn.executescript(
        """
        DROP TABLE IF EXISTS message_files;
        DROP TABLE IF EXISTS message_reactions;
        DROP INDEX IF EXISTS idx_messages_parent_created;
        DROP INDEX IF EXISTS idx_messages_channel_created;
        """
    )


MIGRATIONS: list[tuple[int, Callable[[sqlite3.Connection], None]]] = [
    (1, _migrate_v1),
    (2, _migrate_v2),
    (3, _migrate_v3),
    (4, _migrate_v4),
    (5, _migrate_v5),
]

REVERSES: dict[int, Callable[[sqlite3.Connection], None]] = {
    1: _reverse_v1,
    2: _reverse_v2,
    3: _reverse_v3,
    4: _reverse_v4,
    5: _reverse_v5,
}


def apply_migrations(conn: sqlite3.Connection) -> None:
    """Apply pending migrations in version order (idempotent)."""
    applied = {
        int(row[0])
        for row in conn.execute("SELECT version FROM schema_migrations").fetchall()
    }
    for version, migrate_fn in MIGRATIONS:
        if version in applied:
            continue
        migrate_fn(conn)
        conn.execute(
            "INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)",
            (version, utc_now_z()),
        )
        conn.commit()


def reverse_migration(conn: sqlite3.Connection, version: int) -> None:
    """Reverse a single migration version if a reverse exists."""
    reverse_fn = REVERSES.get(version)
    if reverse_fn is None:
        raise ValueError(f"no reverse for migration version {version}")
    reverse_fn(conn)
    conn.execute("DELETE FROM schema_migrations WHERE version = ?", (version,))
    conn.commit()


def ensure_schema(sqlite_path: str) -> None:
    """Bootstrap schema_migrations and apply all product migrations."""
    ensure_bootstrap(sqlite_path)
    conn = connect_and_bootstrap(sqlite_path)
    apply_migrations(conn)
    conn.close()
