"""Internal event publish hooks (fan-out wired by MARATHON-13/14)."""

from __future__ import annotations

from typing import Any


def publish_user_updated(user: dict[str, Any]) -> None:
    """Notify subscribers that a user's public profile changed.

    Intended payload (no ``channel_id`` / ``seq`` — profile events are not
    channel-sequenced)::

        {"type": "user.updated", "user": <UserObj>}

    No-op until MARATHON-13/14 replace this with Redis pub/sub + WebSocket
    fan-out. Must not raise after a successful HTTP commit.
    """
    _ = user
    return None


def publish_message_created(
    *, channel_id: str, message: dict[str, Any]
) -> None:
    """Notify that a message was created.

    Intended payload (``seq`` assigned by MARATHON-13)::

        {"type": "message.created", "channel_id": ..., "message": <MessageObj>}

    No-op until MARATHON-13. Must not raise after a successful HTTP commit.
    """
    _ = channel_id, message
    return None


def publish_message_updated(
    *, channel_id: str, message: dict[str, Any]
) -> None:
    """Notify that a message was edited.

    Intended payload (``seq`` assigned by MARATHON-13)::

        {"type": "message.updated", "channel_id": ..., "message": <MessageObj>}

    No-op until MARATHON-13. Must not raise after a successful HTTP commit.
    """
    _ = channel_id, message
    return None


def publish_message_deleted(
    *, channel_id: str, message_id: str
) -> None:
    """Notify that a message was soft-deleted.

    Intended payload (``seq`` assigned by MARATHON-13)::

        {"type": "message.deleted", "channel_id": ..., "message_id": ...}

    No-op until MARATHON-13. Must not raise after a successful HTTP commit.
    """
    _ = channel_id, message_id
    return None


def publish_reaction_changed(
    *,
    channel_id: str,
    message_id: str,
    reactions: list[dict[str, Any]],
) -> None:
    """Notify that reactions on a message changed.

    Intended payload (``seq`` assigned by MARATHON-13)::

        {
            "type": "reaction.changed",
            "channel_id": ...,
            "message_id": ...,
            "reactions": [<ReactionObj>, ...]
        }

    No-op until MARATHON-13. Must not raise after a successful HTTP commit.
    """
    _ = channel_id, message_id, reactions
    return None
