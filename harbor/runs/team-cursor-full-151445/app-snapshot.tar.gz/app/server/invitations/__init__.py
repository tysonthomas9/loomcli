"""Workspace invitation codes package."""
