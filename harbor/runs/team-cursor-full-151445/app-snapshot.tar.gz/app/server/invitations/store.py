"""Invitation persistence, validation, and InvitationObj mapping."""

from __future__ import annotations

import secrets
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from server.auth import users as auth_users
from server.channels import store as channels_store
from server.db import utc_now_z
from server.errors import ApiError
from server.workspaces import store as workspaces_store

INVITATION_OBJ_KEYS = (
    "id",
    "code",
    "workspace_id",
    "created_by",
    "created_at",
    "expires_at",
    "max_uses",
    "use_count",
    "invited_user_id",
    "invited_username",
)

EXPIRES_MIN = 60
EXPIRES_MAX = 2592000  # 30 days
MAX_USES_MAX = 1000


def row_to_invitation_obj(
    row: sqlite3.Row | dict[str, Any],
) -> dict[str, Any]:
    get = row.__getitem__
    return {
        "id": get("id"),
        "code": get("code"),
        "workspace_id": get("workspace_id"),
        "created_by": get("created_by"),
        "created_at": get("created_at"),
        "expires_at": get("expires_at"),
        "max_uses": int(get("max_uses")),
        "use_count": int(get("use_count")),
        "invited_user_id": get("invited_user_id"),
        "invited_username": get("invited_username"),
    }


def _generate_code() -> str:
    # URL-safe opaque token; ~24 chars of entropy.
    return secrets.token_urlsafe(18)


def _parse_optional_int(
    value: Any, *, field: str, minimum: int, maximum: int
) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise ApiError(400, "validation_error", f"invalid {field}")
    if value < minimum or value > maximum:
        raise ApiError(400, "validation_error", f"invalid {field}")
    return value


def _resolve_invite_target(
    conn: sqlite3.Connection,
    *,
    invited_user_id: Any,
    invited_username: Any,
) -> tuple[str | None, str | None]:
    """Resolve optional target fields to (user_id, username) or (None, None)."""
    has_id = invited_user_id is not None
    has_name = invited_username is not None
    if not has_id and not has_name:
        return None, None

    resolved_id: str | None = None
    resolved_username: str | None = None

    if has_id:
        if not isinstance(invited_user_id, str) or not invited_user_id:
            raise ApiError(400, "validation_error", "invalid invited_user_id")
        user = auth_users.get_user_by_id(conn, invited_user_id)
        if user is None:
            raise ApiError(400, "validation_error", "invited_user_id not found")
        resolved_id = user["id"]
        resolved_username = user["username"]

    if has_name:
        if not isinstance(invited_username, str) or not invited_username:
            raise ApiError(400, "validation_error", "invalid invited_username")
        row = auth_users.get_user_row_by_username(conn, invited_username)
        if row is None:
            raise ApiError(400, "validation_error", "invited_username not found")
        name_id = str(row["id"])
        name_username = str(row["username"])
        if resolved_id is not None and resolved_id != name_id:
            raise ApiError(
                400,
                "validation_error",
                "invited_user_id and invited_username must refer to the same user",
            )
        resolved_id = name_id
        resolved_username = name_username

    return resolved_id, resolved_username


def create_invitation(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    created_by: str,
    expires_in_seconds: Any = None,
    max_uses: Any = None,
    invited_user_id: Any = None,
    invited_username: Any = None,
) -> dict[str, Any]:
    target_id, target_username = _resolve_invite_target(
        conn,
        invited_user_id=invited_user_id,
        invited_username=invited_username,
    )
    targeted = target_id is not None

    parsed_max = _parse_optional_int(
        max_uses, field="max_uses", minimum=1, maximum=MAX_USES_MAX
    )
    if targeted:
        if parsed_max is not None and parsed_max != 1:
            raise ApiError(
                400,
                "validation_error",
                "targeted invitations must have max_uses=1",
            )
        effective_max = 1
    else:
        effective_max = 1 if parsed_max is None else parsed_max

    parsed_expires = _parse_optional_int(
        expires_in_seconds,
        field="expires_in_seconds",
        minimum=EXPIRES_MIN,
        maximum=EXPIRES_MAX,
    )
    expires_at: str | None = None
    if parsed_expires is not None:
        expires_at = (
            datetime.now(timezone.utc) + timedelta(seconds=parsed_expires)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")

    invitation_id = str(uuid.uuid4())
    now = utc_now_z()
    code = _generate_code()
    for _ in range(5):
        try:
            conn.execute(
                """
                INSERT INTO workspace_invitations (
                    id, workspace_id, code, created_by, created_at,
                    expires_at, max_uses, use_count,
                    invited_user_id, invited_username, revoked_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, NULL)
                """,
                (
                    invitation_id,
                    workspace_id,
                    code,
                    created_by,
                    now,
                    expires_at,
                    effective_max,
                    target_id,
                    target_username,
                ),
            )
            break
        except sqlite3.IntegrityError:
            code = _generate_code()
    else:
        raise ApiError(500, "internal_error", "could not allocate invitation code")

    row = conn.execute(
        "SELECT * FROM workspace_invitations WHERE id = ?", (invitation_id,)
    ).fetchone()
    assert row is not None
    return row_to_invitation_obj(row)


def list_active_invitations(
    conn: sqlite3.Connection, *, workspace_id: str
) -> list[dict[str, Any]]:
    now = utc_now_z()
    rows = conn.execute(
        """
        SELECT * FROM workspace_invitations
        WHERE workspace_id = ?
          AND revoked_at IS NULL
          AND (expires_at IS NULL OR expires_at > ?)
          AND use_count < max_uses
        ORDER BY created_at DESC, id DESC
        """,
        (workspace_id, now),
    ).fetchall()
    return [row_to_invitation_obj(row) for row in rows]


def get_invitation_by_code(
    conn: sqlite3.Connection, code: str
) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM workspace_invitations WHERE code = ?", (code,)
    ).fetchone()


def _is_inactive(row: sqlite3.Row | dict[str, Any], *, now: str) -> bool:
    get = row.__getitem__
    if get("revoked_at") is not None:
        return True
    expires_at = get("expires_at")
    if expires_at is not None and expires_at <= now:
        return True
    if int(get("use_count")) >= int(get("max_uses")):
        return True
    return False


def revoke_invitation(conn: sqlite3.Connection, *, code: str) -> None:
    row = get_invitation_by_code(conn, code)
    if row is None or row["revoked_at"] is not None:
        raise ApiError(404, "not_found", "invitation not found")
    conn.execute(
        """
        UPDATE workspace_invitations
        SET revoked_at = ?
        WHERE code = ?
        """,
        (utc_now_z(), code),
    )


def accept_invitation(
    conn: sqlite3.Connection,
    *,
    code: str,
    caller_id: str,
) -> dict[str, Any]:
    """Validate invite, onboard caller, return workspace detail payload."""
    now = utc_now_z()
    row = get_invitation_by_code(conn, code)
    if row is None or _is_inactive(row, now=now):
        raise ApiError(404, "not_found", "invitation not found")

    invited_user_id = row["invited_user_id"]
    if invited_user_id is not None and invited_user_id != caller_id:
        raise ApiError(403, "forbidden", "invitation is for another user")

    workspace_id = str(row["workspace_id"])
    workspace_row = conn.execute(
        "SELECT * FROM workspaces WHERE id = ?", (workspace_id,)
    ).fetchone()
    if workspace_row is None:
        raise ApiError(404, "not_found", "invitation not found")

    already_member = workspaces_store.is_workspace_member(
        conn, workspace_id=workspace_id, user_id=caller_id
    )
    if not already_member:
        # Re-check capacity inside the write path for concurrent accepts.
        row = get_invitation_by_code(conn, code)
        if row is None or _is_inactive(row, now=utc_now_z()):
            raise ApiError(404, "not_found", "invitation not found")
        workspaces_store.add_workspace_member(
            conn,
            workspace_id=workspace_id,
            user_id=caller_id,
            role="member",
        )
        general = channels_store.get_general_channel(
            conn, workspace_id=workspace_id
        )
        if general is not None:
            channels_store.ensure_channel_member(
                conn, channel_id=general["id"], user_id=caller_id
            )
        conn.execute(
            """
            UPDATE workspace_invitations
            SET use_count = use_count + 1
            WHERE code = ?
              AND revoked_at IS NULL
              AND use_count < max_uses
            """,
            (code,),
        )
        updated = get_invitation_by_code(conn, code)
        if updated is None or int(updated["use_count"]) <= int(row["use_count"]):
            raise ApiError(404, "not_found", "invitation not found")

    workspace = workspaces_store.row_to_workspace_obj(workspace_row)
    channels = channels_store.list_channels_for_workspace_user(
        conn,
        workspace_id=workspace_id,
        user_id=caller_id,
        include_archived=False,
    )
    channel_ids = [ch["id"] for ch in channels]
    read_state = channels_store.list_read_state_for_channels(
        conn, user_id=caller_id, channel_ids=channel_ids
    )
    return {
        "workspace": workspace,
        "channels": channels,
        "read_state": read_state,
    }
