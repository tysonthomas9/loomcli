"""HTTP routes for workspace invitations and code redeem/revoke."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict

from server import db
from server.auth.deps import get_current_user
from server.errors import ApiError
from server.invitations import store as invitations_store
from server.settings import Settings
from server.workspaces import store as workspaces_store

router = APIRouter(tags=["invitations"])


class CreateInvitationBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_in_seconds: int | None = None
    max_uses: int | None = None
    invited_username: str | None = None
    invited_user_id: str | None = None


def _settings(request: Request) -> Settings:
    return request.app.state.settings


def _require_member_workspace(
    conn: Any,
    *,
    slug: str,
    user_id: str,
) -> tuple[dict[str, Any], str]:
    workspace = workspaces_store.get_workspace_by_slug(conn, slug)
    if workspace is None:
        raise ApiError(404, "not_found", "workspace not found")
    role = workspaces_store.get_member_role(
        conn, workspace_id=workspace["id"], user_id=user_id
    )
    if role is None:
        raise ApiError(404, "not_found", "workspace not found")
    return workspace, role


def _require_admin(role: str) -> None:
    if role not in ("owner", "admin"):
        raise ApiError(403, "forbidden", "admin or owner role required")


@router.post("/api/workspaces/{slug}/invitations", status_code=201)
def create_invitation(
    slug: str,
    body: CreateInvitationBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        _require_admin(role)
        invitation = invitations_store.create_invitation(
            conn,
            workspace_id=workspace["id"],
            created_by=caller["id"],
            expires_in_seconds=body.expires_in_seconds,
            max_uses=body.max_uses,
            invited_user_id=body.invited_user_id,
            invited_username=body.invited_username,
        )
        conn.commit()
        return {"invitation": invitation}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.get("/api/workspaces/{slug}/invitations")
def list_invitations(
    slug: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        workspace, role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        _require_admin(role)
        invitations = invitations_store.list_active_invitations(
            conn, workspace_id=workspace["id"]
        )
        return {"invitations": invitations}
    finally:
        conn.close()


@router.post("/api/invitations/{code}/accept")
def accept_invitation(
    code: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        payload = invitations_store.accept_invitation(
            conn, code=code, caller_id=caller["id"]
        )
        conn.commit()
        return payload
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.delete("/api/invitations/{code}")
def revoke_invitation(
    code: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        row = invitations_store.get_invitation_by_code(conn, code)
        if row is None or row["revoked_at"] is not None:
            raise ApiError(404, "not_found", "invitation not found")

        ws_row = conn.execute(
            "SELECT * FROM workspaces WHERE id = ?", (row["workspace_id"],)
        ).fetchone()
        if ws_row is None:
            raise ApiError(404, "not_found", "invitation not found")

        role = workspaces_store.get_member_role(
            conn, workspace_id=str(ws_row["id"]), user_id=caller["id"]
        )
        if role is None:
            raise ApiError(404, "not_found", "invitation not found")
        _require_admin(role)

        invitations_store.revoke_invitation(conn, code=code)
        conn.commit()
        return {"revoked": True}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
