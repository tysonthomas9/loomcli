"""Workspace HTTP routes and persistence."""

from server.workspaces.routes import router

__all__ = ["router"]
