"""Workspace persistence, validation, and WorkspaceObj mapping."""

from __future__ import annotations

import re
import sqlite3
import uuid
from typing import Any

from server.channels import store as channels_store
from server.db import utc_now_z
from server.errors import ApiError

SLUG_RE = re.compile(r"^[a-z0-9-]{2,32}$")
NAME_MAX = 80
JOIN_MODES = frozenset({"open", "invite_only"})
ASSIGNABLE_ROLES = frozenset({"admin", "member", "guest"})
WORKSPACE_OBJ_KEYS = (
    "id",
    "slug",
    "name",
    "owner_id",
    "join_mode",
)

MEMBER_OBJ_KEYS = (
    "user_id",
    "role",
    "username",
    "display_name",
)


def validate_slug(slug: str) -> str:
    if not isinstance(slug, str) or not SLUG_RE.fullmatch(slug):
        raise ApiError(400, "validation_error", "invalid slug")
    return slug


def validate_name(name: str) -> str:
    if not isinstance(name, str):
        raise ApiError(400, "validation_error", "name is required")
    stripped = name.strip()
    if not stripped:
        raise ApiError(400, "validation_error", "name is required")
    if len(stripped) > NAME_MAX:
        raise ApiError(400, "validation_error", "name is too long")
    return stripped


def validate_join_mode(join_mode: str) -> str:
    if not isinstance(join_mode, str) or join_mode not in JOIN_MODES:
        raise ApiError(400, "validation_error", "invalid join_mode")
    return join_mode


def validate_assignable_role(role: str) -> str:
    """Roles allowed on PATCH .../members/{id} (never owner)."""
    if not isinstance(role, str):
        raise ApiError(400, "validation_error", "role is required")
    if role == "owner":
        raise ApiError(
            400,
            "validation_error",
            "cannot set role to owner; use transfer_ownership",
        )
    if role not in ASSIGNABLE_ROLES:
        raise ApiError(400, "validation_error", "invalid role")
    return role


def row_to_workspace_obj(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    get = row.__getitem__
    return {
        "id": get("id"),
        "slug": get("slug"),
        "name": get("name"),
        "owner_id": get("owner_id"),
        "join_mode": get("join_mode"),
    }


def create_workspace(
    conn: sqlite3.Connection,
    *,
    owner_id: str,
    slug: str,
    name: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Atomically create workspace, owner membership, and #general.

    Returns (WorkspaceObj, ChannelObj for general).
    """
    slug = validate_slug(slug)
    name = validate_name(name)
    workspace_id = str(uuid.uuid4())
    now = utc_now_z()
    try:
        conn.execute(
            """
            INSERT INTO workspaces (
                id, slug, name, owner_id, join_mode, created_at, updated_at
            ) VALUES (?, ?, ?, ?, 'open', ?, ?)
            """,
            (workspace_id, slug, name, owner_id, now, now),
        )
    except sqlite3.IntegrityError as exc:
        raise ApiError(409, "conflict", "slug already taken") from exc

    conn.execute(
        """
        INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
        VALUES (?, ?, 'owner', ?)
        """,
        (workspace_id, owner_id, now),
    )
    general = channels_store.create_general_channel(
        conn, workspace_id=workspace_id, creator_user_id=owner_id
    )
    workspace = {
        "id": workspace_id,
        "slug": slug,
        "name": name,
        "owner_id": owner_id,
        "join_mode": "open",
    }
    return workspace, general


def list_workspaces_for_user(
    conn: sqlite3.Connection, user_id: str
) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT w.*
        FROM workspaces w
        INNER JOIN workspace_members wm
            ON wm.workspace_id = w.id
        WHERE wm.user_id = ?
        ORDER BY LOWER(w.name) ASC, w.slug ASC
        """,
        (user_id,),
    ).fetchall()
    return [row_to_workspace_obj(row) for row in rows]


def get_workspace_by_slug(
    conn: sqlite3.Connection, slug: str
) -> dict[str, Any] | None:
    row = conn.execute(
        "SELECT * FROM workspaces WHERE slug = ?", (slug,)
    ).fetchone()
    if row is None:
        return None
    return row_to_workspace_obj(row)


def is_workspace_member(
    conn: sqlite3.Connection, *, workspace_id: str, user_id: str
) -> bool:
    row = conn.execute(
        """
        SELECT 1 FROM workspace_members
        WHERE workspace_id = ? AND user_id = ?
        """,
        (workspace_id, user_id),
    ).fetchone()
    return row is not None


def get_member_role(
    conn: sqlite3.Connection, *, workspace_id: str, user_id: str
) -> str | None:
    row = conn.execute(
        """
        SELECT role FROM workspace_members
        WHERE workspace_id = ? AND user_id = ?
        """,
        (workspace_id, user_id),
    ).fetchone()
    if row is None:
        return None
    return str(row["role"])


def add_workspace_member(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    user_id: str,
    role: str = "member",
) -> None:
    """Insert workspace membership. Idempotent if already a member (no role change)."""
    if role not in ("owner", "admin", "member", "guest"):
        raise ApiError(400, "validation_error", "invalid role")
    existing = get_member_role(conn, workspace_id=workspace_id, user_id=user_id)
    if existing is not None:
        return
    conn.execute(
        """
        INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
        VALUES (?, ?, ?, ?)
        """,
        (workspace_id, user_id, role, utc_now_z()),
    )


def row_to_member_obj(row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    get = row.__getitem__
    return {
        "user_id": get("user_id"),
        "role": get("role"),
        "username": get("username"),
        "display_name": get("display_name"),
    }


def get_member(
    conn: sqlite3.Connection, *, workspace_id: str, user_id: str
) -> dict[str, Any] | None:
    row = conn.execute(
        """
        SELECT wm.user_id AS user_id, wm.role AS role,
               u.username AS username, u.display_name AS display_name
        FROM workspace_members wm
        INNER JOIN users u ON u.id = wm.user_id
        WHERE wm.workspace_id = ? AND wm.user_id = ?
        """,
        (workspace_id, user_id),
    ).fetchone()
    if row is None:
        return None
    return row_to_member_obj(row)


def list_members(
    conn: sqlite3.Connection, *, workspace_id: str
) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT wm.user_id AS user_id, wm.role AS role,
               u.username AS username, u.display_name AS display_name
        FROM workspace_members wm
        INNER JOIN users u ON u.id = wm.user_id
        WHERE wm.workspace_id = ?
        ORDER BY
            CASE wm.role
                WHEN 'owner' THEN 0
                WHEN 'admin' THEN 1
                WHEN 'member' THEN 2
                WHEN 'guest' THEN 3
                ELSE 4
            END ASC,
            LOWER(u.username) ASC,
            wm.user_id ASC
        """,
        (workspace_id,),
    ).fetchall()
    return [row_to_member_obj(row) for row in rows]


def update_workspace_settings(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    patch: dict[str, Any],
) -> dict[str, Any]:
    """Apply name/join_mode. Empty patch is a no-op (no updated_at bump)."""
    row = conn.execute(
        "SELECT * FROM workspaces WHERE id = ?", (workspace_id,)
    ).fetchone()
    if row is None:
        raise ApiError(404, "not_found", "workspace not found")

    sets: list[str] = []
    values: list[Any] = []
    changed = False

    if "name" in patch:
        raw = patch["name"]
        if raw is None:
            raise ApiError(400, "validation_error", "name cannot be null")
        name = validate_name(raw)
        if name != row["name"]:
            sets.append("name = ?")
            values.append(name)
            changed = True

    if "join_mode" in patch:
        raw = patch["join_mode"]
        if raw is None:
            raise ApiError(400, "validation_error", "join_mode cannot be null")
        join_mode = validate_join_mode(raw)
        if join_mode != row["join_mode"]:
            sets.append("join_mode = ?")
            values.append(join_mode)
            changed = True

    if changed:
        sets.append("updated_at = ?")
        values.append(utc_now_z())
        values.append(workspace_id)
        conn.execute(
            f"UPDATE workspaces SET {', '.join(sets)} WHERE id = ?",
            values,
        )
        row = conn.execute(
            "SELECT * FROM workspaces WHERE id = ?", (workspace_id,)
        ).fetchone()
        assert row is not None

    return row_to_workspace_obj(row)


def update_member_role(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    user_id: str,
    role: str,
) -> dict[str, Any]:
    role = validate_assignable_role(role)
    conn.execute(
        """
        UPDATE workspace_members
        SET role = ?
        WHERE workspace_id = ? AND user_id = ?
        """,
        (role, workspace_id, user_id),
    )
    member = get_member(conn, workspace_id=workspace_id, user_id=user_id)
    if member is None:
        raise ApiError(404, "not_found", "member not found")
    return member


def transfer_ownership(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    previous_owner_id: str,
    new_owner_id: str,
) -> dict[str, Any]:
    """Atomically reassign owner_id and membership roles."""
    now = utc_now_z()
    conn.execute(
        """
        UPDATE workspaces
        SET owner_id = ?, updated_at = ?
        WHERE id = ?
        """,
        (new_owner_id, now, workspace_id),
    )
    conn.execute(
        """
        UPDATE workspace_members
        SET role = 'admin'
        WHERE workspace_id = ? AND user_id = ?
        """,
        (workspace_id, previous_owner_id),
    )
    conn.execute(
        """
        UPDATE workspace_members
        SET role = 'owner'
        WHERE workspace_id = ? AND user_id = ?
        """,
        (workspace_id, new_owner_id),
    )
    row = conn.execute(
        "SELECT * FROM workspaces WHERE id = ?", (workspace_id,)
    ).fetchone()
    if row is None:
        raise ApiError(404, "not_found", "workspace not found")
    return row_to_workspace_obj(row)
