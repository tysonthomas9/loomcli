"""Workspace HTTP routes: create, list, detail, members, roles, transfer."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, ConfigDict

from server import db
from server.auth.deps import get_current_user
from server.channels import store as channels_store
from server.errors import ApiError
from server.settings import Settings
from server.workspaces import store as workspaces_store

router = APIRouter(prefix="/api/workspaces", tags=["workspaces"])


class CreateWorkspaceBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    slug: str
    name: str


class PatchWorkspaceBody(BaseModel):
    """Mutable workspace settings; omit = leave unchanged; unknown keys ignored."""

    model_config = ConfigDict(extra="ignore")

    name: str | None = None
    join_mode: str | None = None


class PatchMemberBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    role: str


class TransferOwnershipBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    new_owner_id: str


class CreateChannelBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    is_private: bool = False
    topic: str = ""


def _settings(request: Request) -> Settings:
    return request.app.state.settings


def _parse_include_archived(raw: str | None) -> bool:
    """True only for exact '1' or case-insensitive 'true'; soft values → False."""
    if raw is None:
        return False
    if raw == "1":
        return True
    if raw.lower() == "true":
        return True
    return False


def _require_member_workspace(
    conn: Any,
    *,
    slug: str,
    user_id: str,
) -> tuple[dict[str, Any], str]:
    """Resolve slug + membership. Non-members get 404 (do not leak existence)."""
    workspace = workspaces_store.get_workspace_by_slug(conn, slug)
    if workspace is None:
        raise ApiError(404, "not_found", "workspace not found")
    role = workspaces_store.get_member_role(
        conn, workspace_id=workspace["id"], user_id=user_id
    )
    if role is None:
        raise ApiError(404, "not_found", "workspace not found")
    return workspace, role


@router.post("", status_code=201)
def create_workspace(
    body: CreateWorkspaceBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, general = workspaces_store.create_workspace(
            conn,
            owner_id=caller["id"],
            slug=body.slug,
            name=body.name,
        )
        conn.commit()
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"workspace": workspace, "general_channel": general}


@router.get("")
def list_workspaces(
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        workspaces = workspaces_store.list_workspaces_for_user(conn, caller["id"])
        return {"workspaces": workspaces}
    finally:
        conn.close()


@router.get("/{slug}")
def get_workspace(
    slug: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
    include_archived: str | None = Query(default=None),
) -> dict[str, Any]:
    settings = _settings(request)
    include = _parse_include_archived(include_archived)
    conn = db.connect(settings.sqlite_path)
    try:
        workspace = workspaces_store.get_workspace_by_slug(conn, slug)
        if workspace is None or not workspaces_store.is_workspace_member(
            conn, workspace_id=workspace["id"], user_id=caller["id"]
        ):
            raise ApiError(404, "not_found", "workspace not found")

        channels = channels_store.list_channels_for_workspace_user(
            conn,
            workspace_id=workspace["id"],
            user_id=caller["id"],
            include_archived=include,
        )
        channel_ids = [ch["id"] for ch in channels]
        read_state = channels_store.list_read_state_for_channels(
            conn, user_id=caller["id"], channel_ids=channel_ids
        )
        return {
            "workspace": workspace,
            "channels": channels,
            "read_state": read_state,
        }
    finally:
        conn.close()


@router.post("/{slug}/join")
def join_workspace(
    slug: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace = workspaces_store.get_workspace_by_slug(conn, slug)
        if workspace is None:
            raise ApiError(404, "not_found", "workspace not found")

        role = workspaces_store.get_member_role(
            conn, workspace_id=workspace["id"], user_id=caller["id"]
        )
        if role is None:
            if workspace["join_mode"] == "invite_only":
                raise ApiError(403, "forbidden", "workspace is invite only")
            workspaces_store.add_workspace_member(
                conn,
                workspace_id=workspace["id"],
                user_id=caller["id"],
                role="member",
            )

        channels = channels_store.list_channels_for_workspace_user(
            conn,
            workspace_id=workspace["id"],
            user_id=caller["id"],
            include_archived=False,
        )
        channel_ids = [ch["id"] for ch in channels]
        read_state = channels_store.list_read_state_for_channels(
            conn, user_id=caller["id"], channel_ids=channel_ids
        )
        conn.commit()
        return {
            "workspace": workspace,
            "channels": channels,
            "read_state": read_state,
        }
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.post("/{slug}/channels", status_code=201)
def create_channel(
    slug: str,
    body: CreateChannelBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        if role == "guest":
            raise ApiError(403, "forbidden", "guests cannot create channels")
        if body.is_private and role not in ("owner", "admin"):
            raise ApiError(
                403, "forbidden", "only admin or owner can create private channels"
            )

        # Validate bool-ish: pydantic already typed; topic/name via store.
        channel = channels_store.create_channel(
            conn,
            workspace_id=workspace["id"],
            creator_user_id=caller["id"],
            name=body.name,
            is_private=body.is_private,
            topic=body.topic,
        )
        conn.commit()
        return {"channel": channel}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.patch("/{slug}")
def patch_workspace(
    slug: str,
    body: PatchWorkspaceBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    patch = body.model_dump(exclude_unset=True)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        if role not in ("owner", "admin"):
            raise ApiError(403, "forbidden", "admin or owner role required")
        updated = workspaces_store.update_workspace_settings(
            conn, workspace_id=workspace["id"], patch=patch
        )
        conn.commit()
        return {"workspace": updated}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.get("/{slug}/members")
def list_members(
    slug: str,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        workspace, _role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        members = workspaces_store.list_members(
            conn, workspace_id=workspace["id"]
        )
        return {"members": members}
    finally:
        conn.close()


@router.patch("/{slug}/members/{user_id}")
def patch_member(
    slug: str,
    user_id: str,
    body: PatchMemberBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    # Validate role early so role=owner is always 400 (not 403/404).
    new_role = workspaces_store.validate_assignable_role(body.role)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, actor_role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        if actor_role in ("member", "guest"):
            raise ApiError(403, "forbidden", "admin or owner role required")

        target = workspaces_store.get_member(
            conn, workspace_id=workspace["id"], user_id=user_id
        )
        if target is None:
            raise ApiError(404, "not_found", "member not found")

        if target["role"] == "owner" or target["user_id"] == workspace["owner_id"]:
            raise ApiError(403, "forbidden", "cannot change owner role via PATCH")

        if actor_role == "admin" and target["role"] in ("admin", "owner"):
            raise ApiError(403, "forbidden", "admins cannot modify admin or owner")

        member = workspaces_store.update_member_role(
            conn,
            workspace_id=workspace["id"],
            user_id=user_id,
            role=new_role,
        )
        conn.commit()
        return {"member": member}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@router.post("/{slug}/transfer_ownership")
def transfer_ownership(
    slug: str,
    body: TransferOwnershipBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        workspace, _role = _require_member_workspace(
            conn, slug=slug, user_id=caller["id"]
        )
        if caller["id"] != workspace["owner_id"]:
            raise ApiError(403, "forbidden", "only the owner can transfer ownership")

        new_owner_id = body.new_owner_id
        if not isinstance(new_owner_id, str) or not new_owner_id:
            raise ApiError(400, "validation_error", "new_owner_id is required")
        if new_owner_id == caller["id"]:
            raise ApiError(
                400, "validation_error", "cannot transfer ownership to yourself"
            )

        target_role = workspaces_store.get_member_role(
            conn, workspace_id=workspace["id"], user_id=new_owner_id
        )
        if target_role != "admin":
            raise ApiError(
                400,
                "validation_error",
                "new_owner_id must be a workspace admin",
            )

        updated = workspaces_store.transfer_ownership(
            conn,
            workspace_id=workspace["id"],
            previous_owner_id=caller["id"],
            new_owner_id=new_owner_id,
        )
        conn.commit()
        return {"workspace": updated}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
