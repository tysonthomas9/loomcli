"""HTTP routes for DM get-or-create."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field

from server import db
from server.auth.deps import get_current_user
from server.dms import store as dms_store
from server.errors import ApiError
from server.settings import Settings

router = APIRouter(prefix="/api/dms", tags=["dms"])


class CreateDmBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    user_id: str = Field(min_length=1)
    workspace_id: str = Field(min_length=1)


def _settings(request: Request) -> Settings:
    return request.app.state.settings


@router.post("")
def create_or_get_dm(
    body: CreateDmBody,
    request: Request,
    caller: dict[str, Any] = Depends(get_current_user),
) -> dict[str, str]:
    workspace_id = body.workspace_id.strip()
    peer_id = body.user_id.strip()
    if not workspace_id or not peer_id:
        raise ApiError(400, "validation_error", "user_id and workspace_id are required")

    settings = _settings(request)
    conn = db.connect(settings.sqlite_path)
    try:
        conn.execute("BEGIN")
        channel_id = dms_store.get_or_create_dm_channel(
            conn,
            workspace_id=workspace_id,
            caller_id=caller["id"],
            peer_id=peer_id,
        )
        conn.commit()
        return {"channel_id": channel_id}
    except ApiError:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
