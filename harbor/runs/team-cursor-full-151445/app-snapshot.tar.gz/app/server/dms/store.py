"""DM channel get-or-create orchestration (no migration; name-hash dedupe)."""

from __future__ import annotations

import hashlib
import sqlite3

from server.channels import store as channels_store
from server.errors import ApiError
from server.workspaces import store as workspaces_store


def canonical_dm_name(
    *, workspace_id: str, user_a: str, user_b: str
) -> str:
    """Deterministic synthetic channel name for an unordered user pair."""
    user_lo, user_hi = sorted([user_a, user_b])
    digest = hashlib.sha256(
        f"{workspace_id}:{user_lo}:{user_hi}".encode("utf-8")
    ).hexdigest()
    return "dm-" + digest[:29]


def get_or_create_dm_channel(
    conn: sqlite3.Connection,
    *,
    workspace_id: str,
    caller_id: str,
    peer_id: str,
) -> str:
    """Resolve workspace-scoped 1:1 DM; return channel_id. Raises ApiError."""
    if peer_id == caller_id:
        raise ApiError(400, "validation_error", "cannot dm yourself")

    if not workspaces_store.is_workspace_member(
        conn, workspace_id=workspace_id, user_id=caller_id
    ):
        raise ApiError(404, "not_found", "workspace not found")

    if not workspaces_store.is_workspace_member(
        conn, workspace_id=workspace_id, user_id=peer_id
    ):
        raise ApiError(404, "not_found", "user not found")

    name = canonical_dm_name(
        workspace_id=workspace_id, user_a=caller_id, user_b=peer_id
    )

    channel = channels_store.find_dm_by_name(
        conn, workspace_id=workspace_id, name=name
    )
    if channel is None:
        try:
            channel = channels_store.create_dm_channel(
                conn, workspace_id=workspace_id, name=name
            )
        except sqlite3.IntegrityError:
            # Concurrent insert won; re-select by deterministic name.
            channel = channels_store.find_dm_by_name(
                conn, workspace_id=workspace_id, name=name
            )
            if channel is None:
                raise ApiError(
                    409, "conflict", "channel name already taken"
                ) from None

    channel_id = channel["id"]
    channels_store.add_channel_member(
        conn, channel_id=channel_id, user_id=caller_id
    )
    channels_store.add_channel_member(
        conn, channel_id=channel_id, user_id=peer_id
    )
    return channel_id
