"""Shared JSON error envelope helpers for Huddle REST APIs."""

from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse


class ApiError(Exception):
    """Application error rendered as `{error: {code, message}}`."""

    def __init__(self, status_code: int, code: str, message: str) -> None:
        self.status_code = status_code
        self.code = code
        self.message = message
        super().__init__(message)


def error_response(status_code: int, code: str, message: str) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={"error": {"code": code, "message": message}},
    )


def _validation_message(exc: RequestValidationError) -> str:
    errors = exc.errors()
    if not errors:
        return "invalid request"
    err = errors[0]
    loc = err.get("loc") or ()
    # Drop leading "body" / "query" / "path" from location.
    parts = [str(p) for p in loc if p not in ("body", "query", "path", "header")]
    field = ".".join(parts) if parts else None
    msg = err.get("msg") or "invalid request"
    if field:
        return f"{field}: {msg}"
    return str(msg)


def register_exception_handlers(app: FastAPI) -> None:
    """Install ApiError + /api/* validation → envelope handlers."""

    @app.exception_handler(ApiError)
    async def api_error_handler(_request: Request, exc: ApiError) -> JSONResponse:
        return error_response(exc.status_code, exc.code, exc.message)

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        # Envelope for all /api/* except health (MARATHON-4 / MARATHON-5).
        path = request.url.path
        if path.startswith("/api/") and path != "/api/health":
            return error_response(400, "validation_error", _validation_message(exc))
        return JSONResponse(status_code=422, content={"detail": exc.errors()})
