"""Process-local settings for a Huddle HTTP node."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass

NODE_PORT_MAP: dict[int, int] = {
    0: 8000,
    1: 8001,
    2: 8002,
}

PORT_NODE_MAP: dict[int, int] = {port: node_id for node_id, port in NODE_PORT_MAP.items()}

DEFAULT_DATA_DIR = "/app/data"
DEFAULT_REDIS_URL = "redis://127.0.0.1:6379/0"


@dataclass(frozen=True)
class Settings:
    node_id: int
    port: int
    data_dir: str
    redis_url: str

    @property
    def sqlite_path(self) -> str:
        return os.path.join(self.data_dir, "huddle.sqlite")


def _require_env(name: str) -> str:
    value = os.environ.get(name)
    if value is None or value == "":
        raise SystemExit(f"missing required environment variable: {name}")
    return value


def load_settings() -> Settings:
    """Load and validate HUDDLE_* env. Exits non-zero on misconfiguration."""
    try:
        node_id = int(_require_env("HUDDLE_NODE_ID"))
    except ValueError as exc:
        raise SystemExit(f"HUDDLE_NODE_ID must be an integer: {exc}") from exc

    if node_id not in NODE_PORT_MAP:
        raise SystemExit(f"HUDDLE_NODE_ID must be 0, 1, or 2; got {node_id}")

    port_raw = os.environ.get("HUDDLE_PORT")
    if port_raw is None or port_raw == "":
        port = NODE_PORT_MAP[node_id]
    else:
        try:
            port = int(port_raw)
        except ValueError as exc:
            raise SystemExit(f"HUDDLE_PORT must be an integer: {exc}") from exc

    expected_port = NODE_PORT_MAP[node_id]
    if port != expected_port:
        raise SystemExit(
            f"HUDDLE_NODE_ID={node_id} requires port {expected_port}, got {port}"
        )

    data_dir = os.environ.get("HUDDLE_DATA_DIR") or DEFAULT_DATA_DIR
    redis_url = os.environ.get("HUDDLE_REDIS_URL") or DEFAULT_REDIS_URL

    return Settings(
        node_id=node_id,
        port=port,
        data_dir=data_dir,
        redis_url=redis_url,
    )


# Eager load when imported under uvicorn so misconfig fails before bind.
# Only load when HUDDLE_NODE_ID is present (unit tests may import app factory).
settings: Settings | None
if "HUDDLE_NODE_ID" in os.environ:
    try:
        settings = load_settings()
    except SystemExit as exc:
        print(str(exc), file=sys.stderr)
        raise
else:
    settings = None
