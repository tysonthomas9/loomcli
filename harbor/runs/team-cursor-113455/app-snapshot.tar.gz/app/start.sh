#!/usr/bin/env bash
# Huddle cluster supervisor: local Redis + three HTTP nodes on 127.0.0.1.
set -euo pipefail

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_ROOT"

export HUDDLE_HOST="${HUDDLE_HOST:-127.0.0.1}"
export HUDDLE_REDIS_URL="${HUDDLE_REDIS_URL:-redis://127.0.0.1:6379/0}"
export HUDDLE_DATA_DIR="${HUDDLE_DATA_DIR:-$APP_ROOT/data}"

DATA_DIR="$HUDDLE_DATA_DIR"
REDIS_DIR="$DATA_DIR/redis"
VENV_DIR="$APP_ROOT/.venv"
PYTHON_BIN="${PYTHON_BIN:-python3}"

REDIS_PID=""
declare -A NODE_PIDS=()

log() {
  printf '[huddle] %s\n' "$*" >&2
}

die() {
  log "ERROR: $*"
  exit 1
}

port_in_use() {
  local port="$1"
  if command -v ss >/dev/null 2>&1; then
    ss -ltn "sport = :$port" 2>/dev/null | grep -q ":$port"
  else
    # Fallback: try binding via python
    "$PYTHON_BIN" -c "import socket;s=socket.socket();s.bind(('127.0.0.1',$port))" 2>/dev/null && return 1 || return 0
  fi
}

ensure_deps() {
  if ! command -v redis-server >/dev/null 2>&1; then
    die "redis-server binary not found in PATH"
  fi
  if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    die "python3 not found"
  fi

  mkdir -p "$DATA_DIR" "$REDIS_DIR"

  if [[ ! -d "$VENV_DIR" ]]; then
    log "Creating virtualenv at $VENV_DIR"
    "$PYTHON_BIN" -m venv "$VENV_DIR"
  fi
  # shellcheck disable=SC1091
  source "$VENV_DIR/bin/activate"

  if ! python -c "import fastapi, uvicorn" 2>/dev/null; then
    log "Installing Python dependencies from vendor/ (offline preferred)"
    if [[ -d "$APP_ROOT/vendor" ]] && compgen -G "$APP_ROOT/vendor/*.whl" >/dev/null; then
      pip install --no-index --find-links="$APP_ROOT/vendor" -r "$APP_ROOT/requirements.txt"
    else
      pip install -r "$APP_ROOT/requirements.txt"
    fi
  fi
}

check_http_ports_free() {
  local port
  for port in 8000 8001 8002; do
    if port_in_use "$port"; then
      die "Port 127.0.0.1:$port is already in use"
    fi
  done
}

start_redis() {
  if redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
    log "Reusing existing Redis on 127.0.0.1:6379"
    REDIS_PID=""
    return 0
  fi
  if port_in_use 6379; then
    die "Port 127.0.0.1:6379 is in use but Redis PING failed"
  fi
  log "Starting redis-server on 127.0.0.1:6379"
  redis-server \
    --bind 127.0.0.1 \
    --port 6379 \
    --dir "$REDIS_DIR" \
    --daemonize no \
    --protected-mode yes \
    --save "" \
    --appendonly no \
    >/dev/null 2>&1 &
  REDIS_PID=$!
  local i
  for i in $(seq 1 50); do
    if redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
      log "Redis ready (pid=${REDIS_PID:-external})"
      return 0
    fi
    sleep 0.1
  done
  die "Redis failed to become ready"
}

start_node() {
  local node_id="$1"
  local port="$2"
  log "Starting HTTP node_id=$node_id on 127.0.0.1:$port"
  (
    export HUDDLE_NODE_ID="$node_id"
    export HUDDLE_PORT="$port"
    export HUDDLE_HOST
    export HUDDLE_REDIS_URL
    export HUDDLE_DATA_DIR
    exec python -m huddle
  ) &
  NODE_PIDS[$node_id]=$!
}

stop_children() {
  local pid node_id
  for node_id in "${!NODE_PIDS[@]}"; do
    pid="${NODE_PIDS[$node_id]:-}"
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
      kill "$pid" 2>/dev/null || true
    fi
  done
  if [[ -n "${REDIS_PID:-}" ]] && kill -0 "$REDIS_PID" 2>/dev/null; then
    kill "$REDIS_PID" 2>/dev/null || true
  fi
  wait 2>/dev/null || true
}

on_signal() {
  log "Shutting down cluster..."
  stop_children
  exit 0
}

trap on_signal INT TERM

ensure_deps
check_http_ports_free
start_redis

start_node 0 8000
start_node 1 8001
start_node 2 8002

log "Cluster running (foreground). Nodes: ${NODE_PIDS[*]}; redis_pid=${REDIS_PID:-reused}"

# Supervisor loop: restart dead children; stay in foreground.
while true; do
  # Redis
  if ! redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
    log "Redis not responding; restarting"
    if [[ -n "${REDIS_PID:-}" ]] && kill -0 "$REDIS_PID" 2>/dev/null; then
      kill "$REDIS_PID" 2>/dev/null || true
      wait "$REDIS_PID" 2>/dev/null || true
    fi
    REDIS_PID=""
    start_redis
  elif [[ -n "${REDIS_PID:-}" ]] && ! kill -0 "$REDIS_PID" 2>/dev/null; then
    # We started redis but pid is gone while PING still works (adopted) — clear pid.
    if redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
      REDIS_PID=""
    else
      log "Redis process exited; restarting"
      start_redis
    fi
  fi

  # HTTP nodes
  local_id=0
  for port in 8000 8001 8002; do
    pid="${NODE_PIDS[$local_id]:-}"
    if [[ -z "$pid" ]] || ! kill -0 "$pid" 2>/dev/null; then
      log "Node $local_id (port $port) is down; restarting"
      start_node "$local_id" "$port"
    fi
    local_id=$((local_id + 1))
  done

  sleep 1
done
