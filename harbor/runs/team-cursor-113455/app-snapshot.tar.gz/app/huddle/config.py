"""Huddle node configuration from HUDDLE_* environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass

PORT_TO_NODE_ID: dict[int, int] = {
    8000: 0,
    8001: 1,
    8002: 2,
}

NODE_ID_TO_PORT: dict[int, int] = {v: k for k, v in PORT_TO_NODE_ID.items()}


@dataclass(frozen=True)
class Settings:
    node_id: int
    port: int
    host: str
    redis_url: str
    data_dir: str


def load_settings() -> Settings:
    """Read and validate HUDDLE_* env; raise SystemExit on misconfiguration."""
    raw_node = os.environ.get("HUDDLE_NODE_ID")
    raw_port = os.environ.get("HUDDLE_PORT")
    if raw_node is None or raw_port is None:
        raise SystemExit(
            "HUDDLE_NODE_ID and HUDDLE_PORT are required "
            f"(got NODE_ID={raw_node!r} PORT={raw_port!r})"
        )

    try:
        node_id = int(raw_node)
        port = int(raw_port)
    except ValueError as exc:
        raise SystemExit(
            f"HUDDLE_NODE_ID and HUDDLE_PORT must be integers: {exc}"
        ) from exc

    expected_node = PORT_TO_NODE_ID.get(port)
    expected_port = NODE_ID_TO_PORT.get(node_id)
    if expected_node is None or expected_port is None:
        raise SystemExit(
            f"Invalid HUDDLE_PORT={port} or HUDDLE_NODE_ID={node_id}; "
            f"allowed ports {sorted(PORT_TO_NODE_ID)} "
            f"with node_ids {sorted(NODE_ID_TO_PORT)}"
        )
    if node_id != expected_node or port != expected_port:
        raise SystemExit(
            f"HUDDLE_NODE_ID={node_id} does not match HUDDLE_PORT={port}; "
            f"expected node_id={expected_node} for that port "
            f"(or port={expected_port} for that node_id)"
        )

    host = os.environ.get("HUDDLE_HOST", "127.0.0.1")
    redis_url = os.environ.get("HUDDLE_REDIS_URL", "redis://127.0.0.1:6379/0")
    data_dir = os.environ.get("HUDDLE_DATA_DIR", "/app/data")

    return Settings(
        node_id=node_id,
        port=port,
        host=host,
        redis_url=redis_url,
        data_dir=data_dir,
    )
