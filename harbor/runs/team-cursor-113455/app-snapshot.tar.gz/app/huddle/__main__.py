"""Entry point: python -m huddle"""

from __future__ import annotations

import uvicorn

from huddle.app import create_app
from huddle.config import load_settings


def main() -> None:
    settings = load_settings()
    uvicorn.run(
        create_app(),
        host=settings.host,
        port=settings.port,
        log_level="info",
    )


if __name__ == "__main__":
    main()
