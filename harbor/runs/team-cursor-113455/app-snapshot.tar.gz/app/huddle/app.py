"""FastAPI application factory for a Huddle HTTP node."""

from __future__ import annotations

from fastapi import FastAPI

from huddle.api import api_router


def create_app() -> FastAPI:
    app = FastAPI(title="Huddle", docs_url=None, redoc_url=None)
    app.include_router(api_router, prefix="/api")
    return app
