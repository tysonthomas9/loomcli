"""GET /api/health — liveness only; does not probe Redis or SQLite."""

from __future__ import annotations

from fastapi import APIRouter

from huddle.config import load_settings

router = APIRouter()


@router.get("/health")
def health() -> dict[str, object]:
    settings = load_settings()
    return {"status": "ok", "node_id": settings.node_id}
