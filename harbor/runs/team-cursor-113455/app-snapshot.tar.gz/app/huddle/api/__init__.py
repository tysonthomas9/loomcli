"""API router aggregate. Sibling tasks include additional routers here."""

from __future__ import annotations

from fastapi import APIRouter

from huddle.api import health

api_router = APIRouter()
api_router.include_router(health.router)

# Sibling routers (auth, workspaces, …) are included here by later tasks.
