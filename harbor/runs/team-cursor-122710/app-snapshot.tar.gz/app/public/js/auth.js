'use strict';

(function (global) {
  const TOKEN_KEY = 'huddle.token';
  const USERNAME_RE = /^[A-Za-z0-9_]{1,32}$/;

  function getToken() {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch (err) {
      throw new Error('localStorage is unavailable; cannot persist auth');
    }
  }

  function setToken(token) {
    try {
      localStorage.setItem(TOKEN_KEY, token);
    } catch (err) {
      throw new Error('localStorage is unavailable; cannot persist auth');
    }
  }

  function clearToken() {
    try {
      localStorage.removeItem(TOKEN_KEY);
    } catch (err) {
      // Still treat as cleared for in-memory session.
    }
  }

  function authHeaders(token) {
    const headers = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
    if (token) {
      headers.Authorization = 'Bearer ' + token;
    }
    return headers;
  }

  async function parseJsonResponse(res) {
    let body = null;
    try {
      body = await res.json();
    } catch {
      body = null;
    }
    return body;
  }

  /**
   * @param {string} path
   * @param {RequestInit & { token?: string | null }} options
   */
  async function apiFetch(path, options = {}) {
    const { token, headers: extraHeaders, ...rest } = options;
    const headers = {
      ...authHeaders(token === undefined ? null : token),
      ...(extraHeaders || {}),
    };
    const res = await fetch(path, { ...rest, headers });
    const body = await parseJsonResponse(res);
    return { ok: res.ok, status: res.status, body };
  }

  async function register({ username, password, display_name }) {
    const payload = { username, password };
    if (display_name !== undefined && display_name !== '') {
      payload.display_name = display_name;
    }
    return apiFetch('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async function login({ username, password }) {
    return apiFetch('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
  }

  async function me(token) {
    return apiFetch('/api/auth/me', {
      method: 'GET',
      token,
    });
  }

  function validateClient({ mode, username, password }) {
    if (!username || !password) {
      return 'username and password are required';
    }
    if (mode === 'register') {
      if (!USERNAME_RE.test(username)) {
        return 'username must match ^[A-Za-z0-9_]{1,32}$';
      }
      if (password.length < 8) {
        return 'password must be at least 8 characters';
      }
    }
    return null;
  }

  global.HuddleAuth = {
    TOKEN_KEY,
    getToken,
    setToken,
    clearToken,
    authHeaders,
    register,
    login,
    me,
    validateClient,
  };
})(window);
