'use strict';

(function () {
  /** @type {'register' | 'login'} */
  let mode = 'register';
  /** @type {object | null} */
  let currentUser = null;
  let pending = false;
  /** @type {'idle' | 'booting' | 'boot_error'} */
  let bootState = 'idle';

  const els = {
    modal: document.getElementById('auth-modal'),
    form: document.getElementById('auth-form'),
    submit: document.getElementById('auth-submit'),
    toggle: document.getElementById('auth-toggle'),
    error: document.getElementById('auth-error'),
    title: document.getElementById('auth-title'),
    lede: document.getElementById('auth-lede'),
    displayNameField: document.getElementById('display-name-field'),
    displayName: document.getElementById('auth-display-name'),
    username: document.getElementById('auth-username'),
    password: document.getElementById('auth-password'),
    chrome: document.getElementById('app-chrome'),
    shell: document.getElementById('app-shell'),
    currentUser: document.getElementById('current-user'),
    logoutBtn: document.getElementById('logout-btn'),
  };

  function displayIdentity(user) {
    if (!user) return '';
    const name = (user.display_name || '').trim();
    return name || user.username || '';
  }

  function showError(message) {
    if (!message) {
      els.error.hidden = true;
      els.error.textContent = '';
      return;
    }
    els.error.hidden = false;
    els.error.textContent = message;
  }

  function setPending(isPending) {
    pending = isPending;
    els.submit.disabled = isPending;
  }

  function setMode(next) {
    mode = next;
    const isRegister = mode === 'register';
    els.title.textContent = isRegister ? 'Sign up' : 'Log in';
    els.lede.textContent = isRegister
      ? 'Create an account to join your team workspace.'
      : 'Welcome back. Sign in to continue.';
    els.submit.textContent = isRegister ? 'Sign up' : 'Log in';
    els.toggle.textContent = isRegister
      ? 'Already have an account? Log in'
      : 'Need an account? Sign up';
    els.displayNameField.hidden = !isRegister;
    els.password.autocomplete = isRegister ? 'new-password' : 'current-password';
    els.password.value = '';
    showError('');
  }

  function showAuthenticated(user) {
    currentUser = user;
    bootState = 'idle';
    els.modal.hidden = true;
    els.chrome.hidden = false;
    els.shell.hidden = false;
    els.currentUser.textContent = displayIdentity(user);
    window.dispatchEvent(
      new CustomEvent('huddle:auth', { detail: { user } })
    );
  }

  function showUnauthenticated(opts) {
    const options = opts || {};
    currentUser = null;
    els.chrome.hidden = true;
    els.shell.hidden = true;
    els.currentUser.textContent = '';
    els.modal.hidden = false;
    setMode(options.mode || 'login');
    if (options.clearPassword !== false) {
      els.password.value = '';
    }
    if (options.error) {
      showError(options.error);
    } else if (!options.keepError) {
      showError('');
    }
    window.dispatchEvent(new CustomEvent('huddle:logout'));
  }

  function enterSession(user, token) {
    HuddleAuth.setToken(token);
    showAuthenticated(user);
  }

  async function boot() {
    let token;
    try {
      token = HuddleAuth.getToken();
    } catch (err) {
      showUnauthenticated({
        mode: 'login',
        error: err.message || 'localStorage is unavailable; cannot persist auth',
      });
      return;
    }

    if (!token) {
      showUnauthenticated({ mode: 'register' });
      return;
    }

    bootState = 'booting';
    els.modal.hidden = false;
    els.chrome.hidden = true;
    els.shell.hidden = true;
    els.currentUser.textContent = '';
    showError('Restoring session…');
    setPending(true);

    try {
      const result = await HuddleAuth.me(token);
      if (result.status === 401) {
        HuddleAuth.clearToken();
        showUnauthenticated({
          mode: 'login',
          error: (result.body && result.body.error) || 'Session expired. Please log in again.',
        });
        return;
      }
      if (!result.ok || !result.body || !result.body.user) {
        bootState = 'boot_error';
        showUnauthenticated({
          mode: 'login',
          error:
            (result.body && result.body.error) ||
            'Could not restore session. Check your connection and try logging in.',
          keepError: true,
        });
        return;
      }
      showAuthenticated(result.body.user);
    } catch {
      bootState = 'boot_error';
      showUnauthenticated({
        mode: 'login',
        error: 'Could not restore session. Check your connection and try logging in.',
      });
    } finally {
      setPending(false);
    }
  }

  async function onSubmit(event) {
    event.preventDefault();
    if (pending) return;

    const username = (els.username.value || '').trim();
    const password = els.password.value || '';
    const display_name = (els.displayName.value || '').trim();

    const clientError = HuddleAuth.validateClient({ mode, username, password });
    if (clientError) {
      showError(clientError);
      return;
    }

    showError('');
    setPending(true);

    try {
      const result =
        mode === 'register'
          ? await HuddleAuth.register({ username, password, display_name })
          : await HuddleAuth.login({ username, password });

      if (!result.ok) {
        const msg =
          (result.body && result.body.error) ||
          (result.status >= 500
            ? 'Something went wrong'
            : 'Something went wrong');
        showError(msg);
        return;
      }

      const token = result.body && result.body.token;
      const user = result.body && result.body.user;
      if (!token || !user) {
        showError('Something went wrong');
        return;
      }

      try {
        enterSession(user, token);
      } catch (err) {
        showError(err.message || 'localStorage is unavailable; cannot persist auth');
      }
    } catch {
      showError('Something went wrong');
    } finally {
      setPending(false);
    }
  }

  function onToggle() {
    if (pending) return;
    setMode(mode === 'register' ? 'login' : 'register');
  }

  function onLogout() {
    HuddleAuth.clearToken();
    showUnauthenticated({ mode: 'login' });
  }

  document.addEventListener('DOMContentLoaded', () => {
    els.form.addEventListener('submit', onSubmit);
    els.toggle.addEventListener('click', onToggle);
    els.logoutBtn.addEventListener('click', onLogout);
    boot();
  });
})();
