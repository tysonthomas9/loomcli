#!/usr/bin/env bash
# Huddle cluster supervisor: Redis + three HTTP nodes. Stays in the foreground.
set -u

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR" || exit 1

NODE_BIN="${NODE_BIN:-}"
if [[ -z "$NODE_BIN" ]]; then
  if [[ -x /usr/bin/node ]]; then
    NODE_BIN=/usr/bin/node
  else
    NODE_BIN="$(command -v node || true)"
  fi
fi
if [[ -z "$NODE_BIN" || ! -x "$NODE_BIN" ]]; then
  echo "[supervisor] node binary not found" >&2
  exit 1
fi

REDIS_BIN="$(command -v redis-server || true)"
if [[ -z "$REDIS_BIN" ]]; then
  echo "[supervisor] redis-server not found" >&2
  exit 1
fi

mkdir -p "$APP_DIR/data/redis"

REDIS_PID=""
declare -a NODE_PIDS=("" "" "")
SHUTTING_DOWN=0

prefix_stream() {
  local prefix="$1"
  while IFS= read -r line || [[ -n "${line:-}" ]]; do
    printf '%s %s\n' "$prefix" "$line"
  done
}

is_alive() {
  local pid="${1:-}"
  [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null
}

start_redis() {
  if [[ -f "$APP_DIR/redis.conf" ]]; then
    "$REDIS_BIN" "$APP_DIR/redis.conf" \
      > >(prefix_stream '[redis]') 2>&1 &
  else
    "$REDIS_BIN" \
      --bind 127.0.0.1 \
      --port 6379 \
      --dir "$APP_DIR/data/redis" \
      --protected-mode yes \
      --daemonize no \
      --save "" \
      --appendonly no \
      > >(prefix_stream '[redis]') 2>&1 &
  fi
  REDIS_PID=$!
  echo "[supervisor] started redis pid=$REDIS_PID"
}

start_node() {
  local id="$1"
  local port=$((8000 + id))
  NODE_ID="$id" PORT="$port" "$NODE_BIN" "$APP_DIR/server/index.js" \
    > >(prefix_stream "[node-$id]") 2>&1 &
  NODE_PIDS[$id]=$!
  echo "[supervisor] started node-$id pid=${NODE_PIDS[$id]} port=$port"
}

stop_children() {
  local pid
  for pid in "${NODE_PIDS[@]:-}" "$REDIS_PID"; do
    if is_alive "$pid"; then
      kill "$pid" 2>/dev/null || true
    fi
  done
  sleep 0.2
  for pid in "${NODE_PIDS[@]:-}" "$REDIS_PID"; do
    if is_alive "$pid"; then
      kill -9 "$pid" 2>/dev/null || true
    fi
  done
}

on_signal() {
  SHUTTING_DOWN=1
  echo "[supervisor] shutting down..."
  stop_children
  exit 0
}

trap on_signal INT TERM

start_redis
start_node 0
start_node 1
start_node 2

echo "[supervisor] huddle cluster running (redis + nodes 0/1/2)"

while true; do
  if [[ "$SHUTTING_DOWN" -eq 1 ]]; then
    break
  fi

  if ! is_alive "$REDIS_PID"; then
    echo "[supervisor] redis died (pid=${REDIS_PID:-none}); respawning"
    start_redis
  fi

  for id in 0 1 2; do
    if ! is_alive "${NODE_PIDS[$id]}"; then
      echo "[supervisor] node-$id died (pid=${NODE_PIDS[$id]:-none}); respawning"
      start_node "$id"
    fi
  done

  sleep 1
done
