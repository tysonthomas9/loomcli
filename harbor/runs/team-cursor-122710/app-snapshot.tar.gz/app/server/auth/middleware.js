'use strict';

const { findUserIdByToken } = require('./tokens');
const { findUserById, publicUser } = require('./users');
const { sendJson } = require('../httpUtil');

const BEARER_RE = /^Bearer\s+(\S+)$/i;

/**
 * Resolve Authorization header to a public UserObj, or null.
 * @param {string | null | undefined} authorizationHeader
 * @returns {import('./users').UserObj | null}
 */
function resolveBearerUser(authorizationHeader) {
  if (!authorizationHeader || typeof authorizationHeader !== 'string') {
    return null;
  }
  const trimmed = authorizationHeader.trim();
  const match = BEARER_RE.exec(trimmed);
  if (!match) {
    return null;
  }
  const token = match[1];
  const userId = findUserIdByToken(token);
  if (!userId) {
    return null;
  }
  const row = findUserById(userId);
  if (!row) {
    return null;
  }
  return publicUser(row);
}

/**
 * Require an authenticated user; writes 401 and returns null on failure.
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 * @returns {import('./users').UserObj | null}
 */
function requireUser(req, res) {
  const header = req.headers.authorization;
  const user = resolveBearerUser(
    Array.isArray(header) ? header[0] : header
  );
  if (!user) {
    sendJson(res, 401, { error: 'unauthorized' });
    return null;
  }
  return user;
}

module.exports = { resolveBearerUser, requireUser };
