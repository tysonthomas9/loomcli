'use strict';

const { readJson, sendJson } = require('../httpUtil');
const { getDb } = require('../db');
const { verifyPassword } = require('./passwords');
const {
  createUser,
  findUserByUsername,
  publicUser,
} = require('./users');
const { issueToken } = require('./tokens');
const { requireUser } = require('./middleware');

const USERNAME_RE = /^[A-Za-z0-9_]{1,32}$/;

/**
 * @param {unknown} body
 * @returns {{ ok: true, username: string, password: string, displayName: string } | { ok: false, error: string }}
 */
function parseRegisterBody(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, error: 'body must be a JSON object' };
  }
  const obj = /** @type {Record<string, unknown>} */ (body);

  if (!('username' in obj) || !('password' in obj)) {
    return { ok: false, error: 'username and password are required' };
  }
  if (typeof obj.username !== 'string' || typeof obj.password !== 'string') {
    return { ok: false, error: 'username and password must be strings' };
  }
  if (!USERNAME_RE.test(obj.username)) {
    return {
      ok: false,
      error: 'username must match ^[A-Za-z0-9_]{1,32}$',
    };
  }
  if (obj.password.length < 8) {
    return { ok: false, error: 'password must be at least 8 characters' };
  }

  let displayName = obj.username;
  if ('display_name' in obj && obj.display_name !== undefined) {
    if (typeof obj.display_name !== 'string') {
      return { ok: false, error: 'display_name must be a string' };
    }
    const trimmed = obj.display_name.trim();
    if (trimmed.length > 0) {
      displayName = trimmed;
    }
  }

  return {
    ok: true,
    username: obj.username,
    password: obj.password,
    displayName,
  };
}

/**
 * @param {unknown} body
 * @returns {{ ok: true, username: string, password: string } | { ok: false, error: string }}
 */
function parseLoginBody(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    return { ok: false, error: 'body must be a JSON object' };
  }
  const obj = /** @type {Record<string, unknown>} */ (body);

  if (!('username' in obj) || !('password' in obj)) {
    return { ok: false, error: 'username and password are required' };
  }
  if (typeof obj.username !== 'string' || typeof obj.password !== 'string') {
    return { ok: false, error: 'username and password must be strings' };
  }
  return { ok: true, username: obj.username, password: obj.password };
}

/**
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 */
async function handleRegister(req, res) {
  const parsed = await readJson(req);
  if (!parsed.ok) {
    sendJson(res, 400, { error: parsed.error });
    return;
  }

  const input = parseRegisterBody(parsed.value);
  if (!input.ok) {
    sendJson(res, 400, { error: input.error });
    return;
  }

  const db = getDb();
  try {
    db.exec('BEGIN');
    try {
      const { user, row } = createUser({
        username: input.username,
        password: input.password,
        displayName: input.displayName,
      });
      const token = issueToken(String(row.id));
      db.exec('COMMIT');
      sendJson(res, 201, { user, token });
    } catch (err) {
      try {
        db.exec('ROLLBACK');
      } catch {
        /* ignore */
      }
      throw err;
    }
  } catch (err) {
    const message = err && err.message ? String(err.message) : String(err);
    if (/UNIQUE constraint failed/i.test(message) || /username_lower/i.test(message)) {
      sendJson(res, 409, { error: 'username already taken' });
      return;
    }
    console.error('[auth/register]', message);
    sendJson(res, 500, { error: 'internal server error' });
  }
}

/**
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 */
async function handleLogin(req, res) {
  const parsed = await readJson(req);
  if (!parsed.ok) {
    sendJson(res, 400, { error: parsed.error });
    return;
  }

  const input = parseLoginBody(parsed.value);
  if (!input.ok) {
    sendJson(res, 400, { error: input.error });
    return;
  }

  try {
    const row = findUserByUsername(input.username);
    if (!row) {
      sendJson(res, 401, { error: 'invalid credentials' });
      return;
    }
    const ok = verifyPassword(
      input.password,
      String(row.password_salt),
      String(row.password_hash)
    );
    if (!ok) {
      sendJson(res, 401, { error: 'invalid credentials' });
      return;
    }
    const token = issueToken(String(row.id));
    sendJson(res, 200, { user: publicUser(row), token });
  } catch (err) {
    const message = err && err.message ? String(err.message) : String(err);
    console.error('[auth/login]', message);
    sendJson(res, 500, { error: 'internal server error' });
  }
}

/**
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 */
function handleMe(req, res) {
  const user = requireUser(req, res);
  if (!user) return;
  sendJson(res, 200, { user });
}

/**
 * Route auth endpoints. Returns true if handled.
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 * @param {string} pathname
 * @returns {boolean | Promise<boolean>}
 */
function handleAuthRoutes(req, res, pathname) {
  if (pathname === '/api/auth/register') {
    if (req.method === 'POST') {
      return handleRegister(req, res).then(() => true);
    }
    sendJson(res, 405, { error: 'method_not_allowed' });
    return true;
  }
  if (pathname === '/api/auth/login') {
    if (req.method === 'POST') {
      return handleLogin(req, res).then(() => true);
    }
    sendJson(res, 405, { error: 'method_not_allowed' });
    return true;
  }
  if (pathname === '/api/auth/me') {
    if (req.method === 'GET') {
      handleMe(req, res);
      return true;
    }
    sendJson(res, 405, { error: 'method_not_allowed' });
    return true;
  }
  return false;
}

module.exports = {
  handleAuthRoutes,
  handleRegister,
  handleLogin,
  handleMe,
};
