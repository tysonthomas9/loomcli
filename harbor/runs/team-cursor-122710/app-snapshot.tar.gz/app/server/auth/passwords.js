'use strict';

const crypto = require('crypto');

const SCRYPT_KEYLEN = 64;

/**
 * @param {string} password
 * @returns {{ salt: string, hash: string }}
 */
function hashPassword(password) {
  const saltBuf = crypto.randomBytes(16);
  const hashBuf = crypto.scryptSync(password, saltBuf, SCRYPT_KEYLEN);
  return {
    salt: saltBuf.toString('hex'),
    hash: hashBuf.toString('hex'),
  };
}

/**
 * @param {string} password
 * @param {string} saltHex
 * @param {string} hashHex
 * @returns {boolean}
 */
function verifyPassword(password, saltHex, hashHex) {
  let saltBuf;
  let expected;
  try {
    saltBuf = Buffer.from(saltHex, 'hex');
    expected = Buffer.from(hashHex, 'hex');
  } catch {
    return false;
  }
  if (saltBuf.length === 0 || expected.length === 0) {
    return false;
  }
  const actual = crypto.scryptSync(password, saltBuf, expected.length);
  if (actual.length !== expected.length) {
    return false;
  }
  return crypto.timingSafeEqual(actual, expected);
}

module.exports = { hashPassword, verifyPassword };
