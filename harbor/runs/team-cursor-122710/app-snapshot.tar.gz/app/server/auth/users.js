'use strict';

const crypto = require('crypto');
const { getDb } = require('../db');
const { hashPassword } = require('./passwords');

/**
 * @typedef {{
 *   id: string,
 *   username: string,
 *   display_name: string,
 *   timezone: string,
 *   avatar_url: string,
 *   status_text: string,
 *   status_emoji: string
 * }} UserObj
 */

/**
 * @param {Record<string, unknown>} row
 * @returns {UserObj}
 */
function publicUser(row) {
  return {
    id: String(row.id),
    username: String(row.username),
    display_name: String(row.display_name),
    timezone: String(row.timezone ?? 'UTC'),
    avatar_url: String(row.avatar_url ?? ''),
    status_text: String(row.status_text ?? ''),
    status_emoji: String(row.status_emoji ?? ''),
  };
}

/**
 * @param {string} username
 * @returns {Record<string, unknown> | undefined}
 */
function findUserByUsername(username) {
  const db = getDb();
  return db
    .prepare('SELECT * FROM users WHERE username_lower = ?')
    .get(username.toLowerCase());
}

/**
 * @param {string} id
 * @returns {Record<string, unknown> | undefined}
 */
function findUserById(id) {
  const db = getDb();
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

/**
 * @param {{ username: string, password: string, displayName: string }} input
 * @returns {{ user: UserObj, row: Record<string, unknown> }}
 */
function createUser(input) {
  const db = getDb();
  const id = crypto.randomUUID();
  const { salt, hash } = hashPassword(input.password);
  const createdAt = new Date().toISOString();
  const usernameLower = input.username.toLowerCase();

  db.prepare(
    `INSERT INTO users (
      id, username, username_lower, password_salt, password_hash,
      display_name, timezone, avatar_url, status_text, status_emoji, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, 'UTC', '', '', '', ?)`
  ).run(
    id,
    input.username,
    usernameLower,
    salt,
    hash,
    input.displayName,
    createdAt
  );

  const row = findUserById(id);
  if (!row) {
    throw new Error('user insert failed');
  }
  return { user: publicUser(row), row };
}

module.exports = {
  publicUser,
  findUserByUsername,
  findUserById,
  createUser,
};
