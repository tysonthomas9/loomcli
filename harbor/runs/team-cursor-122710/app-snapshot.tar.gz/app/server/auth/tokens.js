'use strict';

const crypto = require('crypto');
const { getDb } = require('../db');

/**
 * Issue a new opaque bearer token for a user and persist it.
 * @param {string} userId
 * @returns {string}
 */
function issueToken(userId) {
  const db = getDb();
  const token = crypto.randomBytes(32).toString('base64url');
  const createdAt = new Date().toISOString();
  db.prepare(
    'INSERT INTO tokens (token, user_id, created_at) VALUES (?, ?, ?)'
  ).run(token, userId, createdAt);
  return token;
}

/**
 * @param {string} token
 * @returns {string | null}
 */
function findUserIdByToken(token) {
  if (!token || typeof token !== 'string' || token.length < 16) {
    return null;
  }
  const db = getDb();
  const row = db.prepare('SELECT user_id FROM tokens WHERE token = ?').get(token);
  return row ? String(row.user_id) : null;
}

module.exports = { issueToken, findUserIdByToken };
