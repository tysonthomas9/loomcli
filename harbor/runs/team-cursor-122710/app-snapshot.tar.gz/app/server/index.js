'use strict';

const http = require('http');
const { sendHealth } = require('./health');
const { sendJson } = require('./httpUtil');
const { initDb } = require('./db');
const { handleAuthRoutes } = require('./auth/routes');
const { handleStatic } = require('./static');

function parseEnv() {
  const rawId = process.env.NODE_ID;
  const rawPort = process.env.PORT;

  if (rawId === undefined || rawId === '') {
    console.error('NODE_ID is required (0, 1, or 2)');
    process.exit(1);
  }

  const nodeId = Number(rawId);
  if (!Number.isInteger(nodeId) || nodeId < 0 || nodeId > 2) {
    console.error(`Invalid NODE_ID: ${rawId} (must be integer 0, 1, or 2)`);
    process.exit(1);
  }

  if (rawPort === undefined || rawPort === '') {
    console.error('PORT is required');
    process.exit(1);
  }

  const port = Number(rawPort);
  const expected = 8000 + nodeId;
  if (!Number.isInteger(port) || port !== expected) {
    console.error(`PORT must equal 8000+NODE_ID (${expected}), got: ${rawPort}`);
    process.exit(1);
  }

  return { nodeId, port };
}

const { nodeId, port } = parseEnv();
initDb();

const server = http.createServer((req, res) => {
  let pathname = '/';
  try {
    pathname = new URL(req.url || '/', `http://127.0.0.1:${port}`).pathname;
  } catch {
    pathname = '/';
  }

  if (pathname === '/api/health') {
    if (req.method === 'GET') {
      sendHealth(res, nodeId);
      return;
    }
    sendJson(res, 405, { error: 'method_not_allowed' });
    return;
  }

  Promise.resolve(handleAuthRoutes(req, res, pathname))
    .then((handled) => {
      if (handled) return;
      if (handleStatic(req, res, pathname)) return;
      sendJson(res, 404, { error: 'not_found' });
    })
    .catch((err) => {
      console.error(`[node-${nodeId}] unhandled`, err);
      if (!res.headersSent) {
        sendJson(res, 500, { error: 'internal server error' });
      }
    });
});

server.on('error', (err) => {
  console.error(`[node-${nodeId}] Failed to bind 127.0.0.1:${port}: ${err.message}`);
  process.exit(1);
});

server.listen(port, '127.0.0.1', () => {
  console.error(`[node-${nodeId}] listening on 127.0.0.1:${port}`);
});
