'use strict';

/**
 * Build the GET /api/health response body.
 * @param {number} nodeId Integer 0, 1, or 2
 * @returns {{ status: string, node_id: number }}
 */
function healthBody(nodeId) {
  return { status: 'ok', node_id: nodeId };
}

/**
 * Write a 200 JSON health response.
 * @param {import('http').ServerResponse} res
 * @param {number} nodeId
 */
function sendHealth(res, nodeId) {
  const body = JSON.stringify(healthBody(nodeId));
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

module.exports = { healthBody, sendHealth };
