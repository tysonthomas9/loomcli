'use strict';

const fs = require('fs');
const path = require('path');
const { sendJson, sendText } = require('./httpUtil');

const PUBLIC_ROOT = path.resolve(__dirname, '..', 'public');

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.svg': 'image/svg+xml; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

/**
 * Resolve a URL pathname to a file under public/, or null if unsafe / outside root.
 * @param {string} pathname
 * @returns {string | null}
 */
function resolvePublicPath(pathname) {
  let decoded;
  try {
    decoded = decodeURIComponent(pathname);
  } catch {
    return null;
  }

  if (decoded.includes('\0')) return null;

  const segments = decoded.split('/').filter((s) => s.length > 0);
  if (segments.some((s) => s === '..')) return null;

  let relative = segments.join(path.sep);
  if (!relative || relative === '') {
    relative = 'index.html';
  }

  const candidate = path.resolve(PUBLIC_ROOT, relative);
  if (candidate !== PUBLIC_ROOT && !candidate.startsWith(PUBLIC_ROOT + path.sep)) {
    return null;
  }
  return candidate;
}

/**
 * Serve static SPA assets from public/.
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 * @param {string} pathname
 * @returns {boolean} true if this handler took the response
 */
function handleStatic(req, res, pathname) {
  if (pathname.startsWith('/api/')) {
    return false;
  }

  const method = req.method || 'GET';
  if (method !== 'GET' && method !== 'HEAD') {
    if (pathname === '/' || pathname.startsWith('/css/') || pathname.startsWith('/js/')) {
      sendJson(res, 405, { error: 'method_not_allowed' });
      return true;
    }
    return false;
  }

  const filePath = resolvePublicPath(pathname);
  if (!filePath) {
    sendJson(res, 404, { error: 'not_found' });
    return true;
  }

  let stat;
  try {
    stat = fs.statSync(filePath);
  } catch {
    sendJson(res, 404, { error: 'not_found' });
    return true;
  }

  if (!stat.isFile()) {
    sendJson(res, 404, { error: 'not_found' });
    return true;
  }

  const ext = path.extname(filePath).toLowerCase();
  const contentType = CONTENT_TYPES[ext] || 'application/octet-stream';

  let body;
  try {
    body = fs.readFileSync(filePath);
  } catch {
    sendJson(res, 404, { error: 'not_found' });
    return true;
  }

  if (method === 'HEAD') {
    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': body.length,
    });
    res.end();
    return true;
  }

  sendText(res, 200, body, contentType);
  return true;
}

module.exports = { handleStatic, resolvePublicPath, PUBLIC_ROOT };
