'use strict';

const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = process.env.HUDDLE_DB_PATH || '/app/data/huddle.db';

/** @type {import('node:sqlite').DatabaseSync | null} */
let db = null;

const DDL = `
CREATE TABLE IF NOT EXISTS users (
  id TEXT NOT NULL PRIMARY KEY,
  username TEXT NOT NULL,
  username_lower TEXT NOT NULL UNIQUE,
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  avatar_url TEXT NOT NULL DEFAULT '',
  status_text TEXT NOT NULL DEFAULT '',
  status_emoji TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tokens (
  token TEXT NOT NULL PRIMARY KEY,
  user_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
`;

/**
 * Open the shared SQLite database, apply pragmas and DDL.
 * Exits the process on failure.
 * @returns {import('node:sqlite').DatabaseSync}
 */
function initDb() {
  if (db) return db;

  const dir = path.dirname(DB_PATH);
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch (err) {
    console.error(`[db] failed to create data dir ${dir}: ${err.message}`);
    process.exit(1);
  }

  const sleepSync = (ms) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      /* spin */
    }
  };

  const maxAttempts = 30;
  let lastErr = null;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    /** @type {import('node:sqlite').DatabaseSync | null} */
    let conn = null;
    try {
      conn = new DatabaseSync(DB_PATH, { timeout: 5000 });
      conn.exec('PRAGMA busy_timeout = 5000');
      conn.exec('PRAGMA journal_mode = WAL');
      conn.exec('PRAGMA foreign_keys = ON');
      conn.exec(DDL);
      db = conn;
      return db;
    } catch (err) {
      lastErr = err;
      if (conn) {
        try {
          conn.close();
        } catch {
          /* ignore */
        }
      }
      const msg = err && err.message ? String(err.message) : String(err);
      if (!/locked|busy/i.test(msg) || attempt === maxAttempts) {
        break;
      }
      sleepSync(50 * attempt);
    }
  }

  console.error(
    `[db] failed to open ${DB_PATH}: ${lastErr && lastErr.message ? lastErr.message : lastErr}`
  );
  process.exit(1);
}

/**
 * @returns {import('node:sqlite').DatabaseSync}
 */
function getDb() {
  if (!db) {
    return initDb();
  }
  return db;
}

module.exports = { initDb, getDb, DB_PATH };
