'use strict';

/**
 * @param {import('http').ServerResponse} res
 * @param {number} status
 * @param {unknown} body
 */
function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
  });
  res.end(payload);
}

/**
 * Read and parse a JSON request body.
 * @param {import('http').IncomingMessage} req
 * @returns {Promise<{ ok: true, value: unknown } | { ok: false, error: string }>}
 */
function readJson(req) {
  return new Promise((resolve) => {
    const chunks = [];
    let size = 0;
    const max = 1_048_576;

    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > max) {
        resolve({ ok: false, error: 'request body too large' });
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw.trim()) {
        resolve({ ok: false, error: 'empty request body' });
        return;
      }
      try {
        resolve({ ok: true, value: JSON.parse(raw) });
      } catch {
        resolve({ ok: false, error: 'invalid JSON' });
      }
    });

    req.on('error', () => {
      resolve({ ok: false, error: 'failed to read request body' });
    });
  });
}

/**
 * @param {import('http').ServerResponse} res
 * @param {number} status
 * @param {string | Buffer} body
 * @param {string} contentType
 */
function sendText(res, status, body, contentType) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(String(body), 'utf8');
  res.writeHead(status, {
    'Content-Type': contentType,
    'Content-Length': buf.length,
  });
  res.end(buf);
}

module.exports = { sendJson, sendText, readJson };
