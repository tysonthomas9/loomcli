#!/usr/bin/env bash
# QA verification for MARATHON-27 — HTTP and Redis kill recovery on integrated head.
# Criteria from MARATHON-2 design AC6, AC7, AC9 (edge: HTTP/Redis SIGKILL).
# Run under: marathon-freeports; marathon-portlock ./test/qa-kill-recovery.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
chmod +x "$ROOT/start.sh"

PASS=0
FAIL=0
pass() { echo "PASS: $*"; PASS=$((PASS + 1)); }
fail() { echo "FAIL: $*"; FAIL=$((FAIL + 1)); }

SUPERVISOR_PID=""

cleanup() {
  if [[ -n "${SUPERVISOR_PID}" ]] && kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
    kill -TERM "$SUPERVISOR_PID" 2>/dev/null || true
    for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
      kill -0 "$SUPERVISOR_PID" 2>/dev/null || break
      sleep 0.2
    done
    kill -9 "$SUPERVISOR_PID" 2>/dev/null || true
    for port in 8000 8001 8002 6379; do
      local p
      p="$(listener_pid "$port" || true)"
      if [[ -n "${p:-}" ]]; then
        kill -9 "$p" 2>/dev/null || true
      fi
    done
    wait "$SUPERVISOR_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

assert_health_contract() {
  # Args: port expect_node_id
  local port="$1" expect_id="$2"
  local tmp hdr status body
  tmp="$(mktemp)"
  hdr="$(mktemp)"
  status="$(curl -sS -m 2 -D "$hdr" -o "$tmp" -w '%{http_code}' "http://127.0.0.1:${port}/api/health" 2>/dev/null)" || status="000"
  body="$(cat "$tmp")"
  if [[ "$status" != "200" ]]; then
    echo "  health :${port}: expected HTTP 200 got ${status} body=${body}"
    rm -f "$tmp" "$hdr"
    return 1
  fi
  if ! tr -d '\r' < "$hdr" | awk -F': ' 'tolower($1)=="content-type"{print tolower($2)}' | grep -q 'application/json'; then
    echo "  health :${port}: Content-Type not application/json"
    rm -f "$tmp" "$hdr"
    return 1
  fi
  rm -f "$hdr"
  if ! EXPECT_ID="$expect_id" python3 -c "
import json, os, re, sys
raw = open(sys.argv[1]).read()
expect = int(os.environ['EXPECT_ID'])
d = json.loads(raw)
assert isinstance(d, dict), d
assert 'status' in d and 'node_id' in d, d
assert d['status'] == 'ok', d
assert isinstance(d['node_id'], int) and not isinstance(d['node_id'], bool), type(d['node_id']).__name__
assert d['node_id'] == expect, d
assert re.search(r'\"node_id\"\\s*:\\s*%d\\b' % expect, raw), raw
assert not re.search(r'\"node_id\"\\s*:\\s*\"%d\"' % expect, raw), raw
" "$tmp"; then
    echo "  health :${port}: contract failed body=${body}"
    rm -f "$tmp"
    return 1
  fi
  rm -f "$tmp"
  return 0
}

wait_health() {
  local port="$1" expect_id="$2" timeout_s="${3:-30}"
  local deadline=$((SECONDS + timeout_s))
  while (( SECONDS < deadline )); do
    if assert_health_contract "$port" "$expect_id" >/dev/null 2>&1; then
      return 0
    fi
    sleep 0.25
  done
  assert_health_contract "$port" "$expect_id" || true
  return 1
}

wait_redis() {
  local timeout_s="${1:-30}"
  local deadline=$((SECONDS + timeout_s))
  while (( SECONDS < deadline )); do
    if redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
      return 0
    fi
    sleep 0.25
  done
  return 1
}

listener_pid() {
  local port="$1"
  local pid=""
  pid="$(ss -lptn "sport = :${port}" 2>/dev/null | sed -n 's/.*pid=\([0-9]*\).*/\1/p' | head -1 || true)"
  if [[ -z "$pid" ]]; then
    pid="$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null | head -1 || true)"
  fi
  echo "$pid"
}

redis_is_down() {
  ! redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG
}

# --- Boot supervisor ---
"$ROOT/start.sh" > /tmp/huddle-qa-kill-recovery.log 2>&1 &
SUPERVISOR_PID=$!

sleep 0.5
if ! kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
  fail "start.sh supervisor died immediately"
  cat /tmp/huddle-qa-kill-recovery.log || true
  exit 1
fi
pass "start.sh supervisor running (pid=${SUPERVISOR_PID})"

if wait_redis 30 && wait_health 8000 0 30 && wait_health 8001 1 30 && wait_health 8002 2 30; then
  pass "baseline: Redis PONG + health 200 on :8000/1/2 with node_id 0/1/2"
else
  fail "baseline cluster not healthy before kill tests"
  cat /tmp/huddle-qa-kill-recovery.log || true
  exit 1
fi

# ---------------------------------------------------------------------------
# AC6: SIGKILL one HTTP node — siblings keep serving; killed port restores
# same node_id within 60s; supervisor MUST NOT exit.
# ---------------------------------------------------------------------------
KILL_PORT=8000
KILL_NODE_ID=0
SIBLING_A_PORT=8001
SIBLING_A_ID=1
SIBLING_B_PORT=8002
SIBLING_B_ID=2

NODE_PID="$(listener_pid "$KILL_PORT")"
if [[ -z "$NODE_PID" ]]; then
  fail "AC6 could not resolve HTTP listener PID on :${KILL_PORT}"
else
  # Capture pre-kill sibling health for "never permanently go down"
  if assert_health_contract "$SIBLING_A_PORT" "$SIBLING_A_ID" && assert_health_contract "$SIBLING_B_PORT" "$SIBLING_B_ID"; then
    pass "AC6 pre-kill: siblings :${SIBLING_A_PORT} and :${SIBLING_B_PORT} healthy"
  else
    fail "AC6 pre-kill siblings not healthy"
  fi

  kill -9 "$NODE_PID"
  sleep 0.2

  # Confirm the killed port is actually down (test can fail / proves SIGKILL landed)
  down_ok=0
  down_deadline=$((SECONDS + 5))
  while (( SECONDS < down_deadline )); do
    if ! curl -sS -m 1 -o /dev/null "http://127.0.0.1:${KILL_PORT}/api/health" 2>/dev/null; then
      down_ok=1
      break
    fi
    # Still up briefly if OS has not reaped yet; also accept if listener pid gone
    if [[ -z "$(listener_pid "$KILL_PORT")" ]]; then
      down_ok=1
      break
    fi
    sleep 0.05
  done
  if [[ "$down_ok" -eq 1 ]]; then
    pass "AC6 confirmed :${KILL_PORT} down after SIGKILL (pid=${NODE_PID})"
  else
    fail "AC6 :${KILL_PORT} still serving immediately after SIGKILL of pid=${NODE_PID}"
  fi

  if kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
    pass "AC9 MUST NOT: start.sh did not exit when HTTP child was SIGKILL'd"
  else
    fail "AC9 MUST NOT: start.sh exited when HTTP child was SIGKILL'd"
  fi

  # Siblings must keep serving during the outage / respawn window
  sibling_ok=1
  for _ in 1 2 3 4 5 6 7 8; do
    if ! assert_health_contract "$SIBLING_A_PORT" "$SIBLING_A_ID" || ! assert_health_contract "$SIBLING_B_PORT" "$SIBLING_B_ID"; then
      sibling_ok=0
      break
    fi
    sleep 0.15
  done
  if [[ "$sibling_ok" -eq 1 ]]; then
    pass "AC6 siblings :${SIBLING_A_PORT} and :${SIBLING_B_PORT} kept serving after :${KILL_PORT} SIGKILL"
  else
    fail "AC6 siblings stopped serving as a consequence of :${KILL_PORT} SIGKILL"
  fi

  START=$SECONDS
  if wait_health "$KILL_PORT" "$KILL_NODE_ID" 60 && (( SECONDS - START <= 60 )); then
    ELAPSED=$((SECONDS - START))
    pass "AC6 :${KILL_PORT}/api/health restored in ${ELAPSED}s with same node_id=${KILL_NODE_ID}"
  else
    fail "AC6 :${KILL_PORT} did not restore /api/health with node_id=${KILL_NODE_ID} within 60s"
  fi

  # Post-respawn: all three still correct (no remap after respawn)
  if assert_health_contract 8000 0 && assert_health_contract 8001 1 && assert_health_contract 8002 2; then
    pass "AC6/AC9 post-HTTP-respawn: all nodes healthy with correct node_id map"
  else
    fail "AC6/AC9 post-HTTP-respawn: node_id map broken"
  fi
fi

# ---------------------------------------------------------------------------
# AC7: SIGKILL redis-server on 127.0.0.1:6379 — health stays 200 on all nodes;
# start.sh respawns Redis so it becomes reachable again.
# ---------------------------------------------------------------------------
REDIS_PID="$(listener_pid 6379)"
if [[ -z "$REDIS_PID" ]]; then
  fail "AC7 could not resolve redis-server listener PID on :6379"
else
  kill -9 "$REDIS_PID"
  sleep 0.15

  if kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
    pass "AC9 MUST NOT: start.sh did not exit when Redis was SIGKILL'd"
  else
    fail "AC9 MUST NOT: start.sh exited when Redis was SIGKILL'd"
  fi

  # Prefer observing a true down window; if respawn races, still probe health hard
  down_deadline=$((SECONDS + 5))
  while (( SECONDS < down_deadline )); do
    if redis_is_down; then
      break
    fi
    sleep 0.05
  done
  if redis_is_down; then
    pass "AC7 Redis down confirmed (PING fails) after SIGKILL"
  else
    pass "AC7 Redis kill issued (respawn raced ahead of PING-fail window)"
  fi

  health_ok=1
  for _ in 1 2 3 4 5 6 7 8 9 10; do
    if ! assert_health_contract 8000 0 || ! assert_health_contract 8001 1 || ! assert_health_contract 8002 2; then
      health_ok=0
      break
    fi
    sleep 0.1
  done
  if [[ "$health_ok" -eq 1 ]]; then
    pass "AC7/AC9 HTTP /api/health still 200 on all nodes during Redis outage/restart"
  else
    fail "AC7/AC9 HTTP health failed during Redis outage (must not require Redis)"
  fi

  if wait_redis 60; then
    pass "AC7 Redis respawned by start.sh (redis-cli PING → PONG on 127.0.0.1:6379)"
  else
    fail "AC7 Redis did not become reachable again within 60s"
  fi

  if assert_health_contract 8000 0 && assert_health_contract 8001 1 && assert_health_contract 8002 2; then
    pass "AC7 health still 200 on all nodes after Redis respawn"
  else
    fail "AC7 health failed after Redis respawn"
  fi
fi

echo "Results: $PASS passed, $FAIL failed"
if [[ "$FAIL" -ne 0 ]]; then
  echo "--- supervisor log ---"
  cat /tmp/huddle-qa-kill-recovery.log || true
  exit 1
fi
exit 0
