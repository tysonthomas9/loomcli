'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { spawn } = require('node:child_process');
const path = require('node:path');
const { sendHealth } = require('../server/health');

const ROOT = path.join(__dirname, '..');
const NODE = process.env.NODE_BIN || '/usr/bin/node';

function listenOnce(nodeId) {
  return new Promise((resolve, reject) => {
    const port = 18000 + nodeId; // ephemeral-ish ports for unit isolation
    const server = http.createServer((req, res) => {
      const url = new URL(req.url || '/', `http://127.0.0.1:${port}`);
      if (url.pathname === '/api/health' && req.method === 'GET') {
        sendHealth(res, nodeId);
        return;
      }
      if (url.pathname === '/api/health') {
        res.writeHead(405, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ error: 'method_not_allowed' }));
        return;
      }
      res.writeHead(404);
      res.end();
    });
    server.listen(port, '127.0.0.1', () => resolve({ server, port, nodeId }));
    server.on('error', reject);
  });
}

function getJson(port, pathname, method = 'GET') {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: pathname, method },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try {
            json = JSON.parse(raw);
          } catch {
            json = null;
          }
          resolve({
            status: res.statusCode,
            headers: res.headers,
            raw,
            json,
          });
        });
      }
    );
    req.on('error', reject);
    req.end();
  });
}

describe('GET /api/health via handler', () => {
  let ctx;

  before(async () => {
    ctx = await listenOnce(1);
  });

  after(async () => {
    await new Promise((r) => ctx.server.close(r));
  });

  it('returns 200 with ok and numeric node_id', async () => {
    const res = await getJson(ctx.port, '/api/health');
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'] || '', /application\/json/);
    assert.equal(res.json.status, 'ok');
    assert.equal(res.json.node_id, 1);
    assert.equal(typeof res.json.node_id, 'number');
  });

  it('rejects non-GET with 405', async () => {
    const res = await getJson(ctx.port, '/api/health', 'POST');
    assert.equal(res.status, 405);
  });
});

describe('server/index.js env validation', () => {
  function runEnv(env) {
    return new Promise((resolve) => {
      const child = spawn(NODE, [path.join(ROOT, 'server/index.js')], {
        env: { ...process.env, ...env },
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      let stderr = '';
      child.stderr.on('data', (d) => {
        stderr += d.toString();
      });
      const timer = setTimeout(() => {
        child.kill('SIGKILL');
        resolve({ code: -1, stderr: stderr + '\ntimeout' });
      }, 2000);
      child.on('exit', (code) => {
        clearTimeout(timer);
        resolve({ code, stderr });
      });
    });
  }

  it('exits non-zero when NODE_ID missing', async () => {
    const r = await runEnv({ PORT: '8000', NODE_ID: '' });
    assert.notEqual(r.code, 0);
  });

  it('exits non-zero when PORT mismatches NODE_ID', async () => {
    const r = await runEnv({ NODE_ID: '0', PORT: '8001' });
    assert.notEqual(r.code, 0);
  });
});
