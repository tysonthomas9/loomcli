#!/usr/bin/env bash
# QA verification for MARATHON-24 — cluster bootstrap health and respawn.
# Acceptance criteria from MARATHON-2 design (integrated head).
# Run under: marathon-freeports; marathon-portlock ./test/qa-cluster-bootstrap.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
chmod +x "$ROOT/start.sh"

PASS=0
FAIL=0
pass() { echo "PASS: $*"; PASS=$((PASS + 1)); }
fail() { echo "FAIL: $*"; FAIL=$((FAIL + 1)); }

SUPERVISOR_PID=""

cleanup() {
  if [[ -n "${SUPERVISOR_PID}" ]] && kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
    kill -TERM "$SUPERVISOR_PID" 2>/dev/null || true
    for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
      kill -0 "$SUPERVISOR_PID" 2>/dev/null || break
      sleep 0.2
    done
    kill -9 "$SUPERVISOR_PID" 2>/dev/null || true
    # Also reap any leftover children if trap failed
    for port in 8000 8001 8002 6379; do
      local p
      p="$(listener_pid "$port" || true)"
      if [[ -n "${p:-}" ]]; then
        kill -9 "$p" 2>/dev/null || true
      fi
    done
    wait "$SUPERVISOR_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

assert_health_contract() {
  # Args: port expect_node_id
  # Checks HTTP 200, Content-Type JSON, status=="ok", node_id number equal to expect.
  local port="$1" expect_id="$2"
  local tmp hdr status body
  tmp="$(mktemp)"
  hdr="$(mktemp)"
  status="$(curl -sS -m 2 -D "$hdr" -o "$tmp" -w '%{http_code}' "http://127.0.0.1:${port}/api/health" 2>/dev/null)" || status="000"
  body="$(cat "$tmp")"
  if [[ "$status" != "200" ]]; then
    echo "  health :${port}: expected HTTP 200 got ${status} body=${body}"
    rm -f "$tmp" "$hdr"
    return 1
  fi
  if ! tr -d '\r' < "$hdr" | awk -F': ' 'tolower($1)=="content-type"{print tolower($2)}' | grep -q 'application/json'; then
    echo "  health :${port}: Content-Type not application/json"
    rm -f "$tmp" "$hdr"
    return 1
  fi
  rm -f "$hdr"
  if ! EXPECT_ID="$expect_id" python3 -c "
import json, os, re, sys
raw = open(sys.argv[1]).read()
expect = int(os.environ['EXPECT_ID'])
d = json.loads(raw)
assert isinstance(d, dict), d
assert 'status' in d and 'node_id' in d, d
assert d['status'] == 'ok', d
assert isinstance(d['node_id'], int) and not isinstance(d['node_id'], bool), type(d['node_id']).__name__
assert d['node_id'] == expect, d
assert re.search(r'\"node_id\"\\s*:\\s*%d\\b' % expect, raw), raw
assert not re.search(r'\"node_id\"\\s*:\\s*\"%d\"' % expect, raw), raw
" "$tmp"; then
    echo "  health :${port}: contract failed body=${body}"
    rm -f "$tmp"
    return 1
  fi
  rm -f "$tmp"
  return 0
}

wait_health() {
  local port="$1" expect_id="$2" timeout_s="${3:-30}"
  local deadline=$((SECONDS + timeout_s))
  while (( SECONDS < deadline )); do
    if assert_health_contract "$port" "$expect_id" >/dev/null 2>&1; then
      return 0
    fi
    sleep 0.25
  done
  assert_health_contract "$port" "$expect_id" || true
  return 1
}

wait_redis() {
  local timeout_s="${1:-30}"
  local deadline=$((SECONDS + timeout_s))
  while (( SECONDS < deadline )); do
    if redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
      return 0
    fi
    sleep 0.25
  done
  return 1
}

listener_pid() {
  local port="$1"
  local pid=""
  pid="$(ss -lptn "sport = :${port}" 2>/dev/null | sed -n 's/.*pid=\([0-9]*\).*/\1/p' | head -1 || true)"
  if [[ -z "$pid" ]]; then
    pid="$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null | head -1 || true)"
  fi
  echo "$pid"
}

# --- Boot supervisor in background job (script itself stays foreground in that job) ---
"$ROOT/start.sh" > /tmp/huddle-qa-bootstrap.log 2>&1 &
SUPERVISOR_PID=$!

sleep 0.5
if ! kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
  fail "AC1 start.sh remains foreground / supervisor alive after start"
  cat /tmp/huddle-qa-bootstrap.log || true
  exit 1
fi
pass "AC1 start.sh supervisor stays running (not daemonized away)"

# Confirm start.sh did not double-fork: process still is bash/start.sh lineage
if ps -p "$SUPERVISOR_PID" -o args= 2>/dev/null | grep -qE 'start\.sh|bash'; then
  pass "AC1 supervisor process is start.sh (foreground script)"
else
  # Still OK if args truncated; PID alive is the hard requirement
  pass "AC1 supervisor PID ${SUPERVISOR_PID} still alive"
fi

if wait_redis 30; then
  pass "AC2 redis-cli PING returns PONG on 127.0.0.1:6379"
else
  fail "AC2 redis-cli PING on 127.0.0.1:6379"
fi

if wait_health 8000 0 30; then pass "AC3/AC5 health :8000 → 200 {status:ok, node_id:0 number}"; else fail "AC3/AC5 health :8000"; fi
if wait_health 8001 1 30; then pass "AC4/AC5 health :8001 → 200 {status:ok, node_id:1 number}"; else fail "AC4/AC5 health :8001"; fi
if wait_health 8002 2 30; then pass "AC4/AC5 health :8002 → 200 {status:ok, node_id:2 number}"; else fail "AC4/AC5 health :8002"; fi

# Negative: MUST NOT remap — wrong node_id on a port fails contract (already asserted above).
# Negative: non-GET on /api/health must not 500
non_get_status="$(curl -sS -m 2 -o /dev/null -w '%{http_code}' -X POST "http://127.0.0.1:8000/api/health" 2>/dev/null || echo "000")"
if [[ "$non_get_status" == "405" || "$non_get_status" == "404" ]]; then
  pass "edge non-GET /api/health returns ${non_get_status} (not 500)"
else
  fail "edge non-GET /api/health expected 405|404 got ${non_get_status}"
fi

# AC6: SIGKILL one HTTP node; respawn ≤60s; siblings stay up; supervisor must NOT exit
NODE1_PID="$(listener_pid 8001)"
if [[ -z "$NODE1_PID" ]]; then
  fail "AC6 could not resolve listener PID on :8001"
else
  kill -9 "$NODE1_PID"
  # Supervisor must still be alive immediately after child death
  sleep 0.3
  if kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
    pass "AC9 MUST NOT: start.sh did not exit when one HTTP child died"
  else
    fail "AC9 MUST NOT: start.sh exited when HTTP child was SIGKILL'd"
  fi

  START=$SECONDS
  if wait_health 8001 1 60 && (( SECONDS - START <= 60 )); then
    pass "AC6 node :8001 health restored in $((SECONDS - START))s with node_id=1"
  else
    fail "AC6 node :8001 did not restore health within 60s"
  fi

  # Siblings must still answer (never permanently down as a consequence)
  if assert_health_contract 8000 0 && assert_health_contract 8002 2; then
    pass "AC6 siblings :8000 and :8002 stayed healthy after :8001 SIGKILL"
  else
    fail "AC6 siblings affected by :8001 SIGKILL"
  fi
fi

# AC7: SIGKILL Redis; health still 200; Redis respawned
REDIS_PID="$(listener_pid 6379)"
if [[ -z "$REDIS_PID" ]]; then
  fail "AC7 could not resolve redis listener PID on :6379"
else
  kill -9 "$REDIS_PID"
  sleep 0.3

  if kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
    pass "AC9 MUST NOT: start.sh did not exit when Redis child died"
  else
    fail "AC9 MUST NOT: start.sh exited when Redis was SIGKILL'd"
  fi

  # Health must remain OK during outage / restart (poll a few times)
  health_ok_during=1
  for _ in 1 2 3 4 5; do
    if ! assert_health_contract 8000 0 || ! assert_health_contract 8001 1 || ! assert_health_contract 8002 2; then
      health_ok_during=0
      break
    fi
    sleep 0.2
  done
  if [[ "$health_ok_during" -eq 1 ]]; then
    pass "AC7/AC9 health still 200 on all nodes while Redis down/restarting"
  else
    fail "AC7/AC9 health failed during Redis outage (must not require Redis for health)"
  fi

  if wait_redis 60; then
    pass "AC7 Redis respawned by start.sh (PING PONG)"
  else
    fail "AC7 Redis did not respawn within 60s"
  fi

  if assert_health_contract 8000 0 && assert_health_contract 8001 1 && assert_health_contract 8002 2; then
    pass "AC7 health still 200 on all nodes after Redis respawn"
  else
    fail "AC7 health failed after Redis respawn"
  fi
fi

# AC8: No Docker / remote services — if we got here with local binds only, pass
if ss -lptn 'sport = :8000 or sport = :8001 or sport = :8002 or sport = :6379' 2>/dev/null | grep -q '127.0.0.1'; then
  pass "AC8 listeners bound on 127.0.0.1 (local-only, no Docker required for verification)"
else
  # Fallback: health already proved local curl worked
  pass "AC8 verification used only 127.0.0.1 (no remote services)"
fi

echo "Results: $PASS passed, $FAIL failed"
if [[ "$FAIL" -ne 0 ]]; then
  echo "--- supervisor log ---"
  cat /tmp/huddle-qa-bootstrap.log || true
  exit 1
fi
exit 0
