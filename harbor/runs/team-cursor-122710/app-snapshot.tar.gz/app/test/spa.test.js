'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'huddle-spa-'));
const dbPath = path.join(tmpDir, 'huddle.db');
process.env.HUDDLE_DB_PATH = dbPath;

const { initDb } = require('../server/db');
const { sendHealth } = require('../server/health');
const { sendJson } = require('../server/httpUtil');
const { handleAuthRoutes } = require('../server/auth/routes');
const { handleStatic } = require('../server/static');

function request(port, { method = 'GET', path: pathname, body, headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? null : Buffer.from(JSON.stringify(body), 'utf8');
    const req = http.request(
      {
        host: '127.0.0.1',
        port,
        path: pathname,
        method,
        headers: {
          ...(payload
            ? {
                'Content-Type': 'application/json; charset=utf-8',
                'Content-Length': payload.length,
              }
            : {}),
          ...headers,
        },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try {
            json = JSON.parse(raw);
          } catch {
            json = null;
          }
          resolve({
            status: res.statusCode,
            headers: res.headers,
            raw,
            json,
          });
        });
      }
    );
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

describe('SPA shell static assets (MARATHON-21)', () => {
  let server;
  let port;

  before(async () => {
    initDb();
    server = http.createServer((req, res) => {
      let pathname = '/';
      try {
        pathname = new URL(req.url || '/', 'http://127.0.0.1').pathname;
      } catch {
        pathname = '/';
      }

      if (pathname === '/api/health') {
        if (req.method === 'GET') {
          sendHealth(res, 0);
          return;
        }
        sendJson(res, 405, { error: 'method_not_allowed' });
        return;
      }

      Promise.resolve(handleAuthRoutes(req, res, pathname))
        .then((handled) => {
          if (handled) return;
          if (handleStatic(req, res, pathname)) return;
          sendJson(res, 404, { error: 'not_found' });
        })
        .catch(() => {
          if (!res.headersSent) sendJson(res, 500, { error: 'internal server error' });
        });
    });

    await new Promise((resolve, reject) => {
      server.listen(0, '127.0.0.1', () => {
        port = server.address().port;
        resolve();
      });
      server.on('error', reject);
    });
  });

  after(async () => {
    await new Promise((r) => server.close(r));
  });

  it('GET / returns HTML SPA with pinned auth hooks', async () => {
    const res = await request(port, { path: '/' });
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'] || '', /text\/html/);
    assert.match(res.raw, /id="auth-modal"/);
    assert.match(res.raw, /data-testid="auth-form"/);
    assert.match(res.raw, /data-testid="auth-submit"/);
    assert.match(res.raw, /data-testid="auth-toggle"/);
    assert.match(res.raw, /data-testid="current-user"/);
    assert.match(res.raw, /data-testid="logout-btn"/);
    assert.match(res.raw, /id="app-shell"/);
  });

  it('GET /css/app.css and /js/auth.js and /js/app.js are served', async () => {
    const css = await request(port, { path: '/css/app.css' });
    assert.equal(css.status, 200);
    assert.match(css.headers['content-type'] || '', /text\/css/);
    assert.ok(css.raw.includes('--accent'));

    const authJs = await request(port, { path: '/js/auth.js' });
    assert.equal(authJs.status, 200);
    assert.match(authJs.headers['content-type'] || '', /javascript/);
    assert.match(authJs.raw, /huddle\.token/);

    const appJs = await request(port, { path: '/js/app.js' });
    assert.equal(appJs.status, 200);
    assert.match(appJs.headers['content-type'] || '', /javascript/);
  });

  it('rejects path traversal and keeps /api/health JSON', async () => {
    const trav = await request(port, { path: '/css/../../etc/passwd' });
    assert.equal(trav.status, 404);
    assert.equal(trav.json && trav.json.error, 'not_found');

    const health = await request(port, { path: '/api/health' });
    assert.equal(health.status, 200);
    assert.equal(health.json.status, 'ok');
    assert.equal(typeof health.json.node_id, 'number');
  });

  it('POST / returns 405 JSON, not 500', async () => {
    const res = await request(port, { method: 'POST', path: '/' });
    assert.equal(res.status, 405);
    assert.equal(res.json && res.json.error, 'method_not_allowed');
  });

  it('auth register still works alongside SPA', async () => {
    const username = 'spa_user_' + Date.now().toString(36);
    const res = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username, password: 'password1' },
    });
    assert.equal(res.status, 201);
    assert.equal(typeof res.json.token, 'string');
    assert.ok(res.json.token.length >= 16);
    assert.equal(res.json.user.username, username);
  });
});
