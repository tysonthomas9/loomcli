'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { healthBody } = require('../server/health');

describe('healthBody', () => {
  it('returns status ok and numeric node_id', () => {
    for (const id of [0, 1, 2]) {
      const body = healthBody(id);
      assert.equal(body.status, 'ok');
      assert.equal(typeof body.node_id, 'number');
      assert.equal(body.node_id, id);
      const parsed = JSON.parse(JSON.stringify(body));
      assert.equal(typeof parsed.node_id, 'number');
      assert.notEqual(typeof parsed.node_id, 'string');
    }
  });
});
