#!/usr/bin/env bash
# Integration test for MARATHON-2 bootstrap (start.sh + health + redis + respawn).
# Intended to run under: marathon-freeports; marathon-portlock ./test/integration-bootstrap.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
chmod +x "$ROOT/start.sh"

PASS=0
FAIL=0
pass() { echo "PASS: $*"; PASS=$((PASS + 1)); }
fail() { echo "FAIL: $*"; FAIL=$((FAIL + 1)); }

SUPERVISOR_PID=""

cleanup() {
  if [[ -n "${SUPERVISOR_PID}" ]] && kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
    kill -TERM "$SUPERVISOR_PID" 2>/dev/null || true
    for _ in 1 2 3 4 5 6 7 8 9 10; do
      kill -0 "$SUPERVISOR_PID" 2>/dev/null || break
      sleep 0.2
    done
    kill -9 "$SUPERVISOR_PID" 2>/dev/null || true
    wait "$SUPERVISOR_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

wait_http() {
  local port="$1" expect_id="$2" deadline=$((SECONDS + 30))
  while (( SECONDS < deadline )); do
    if body="$(curl -sS -m 1 "http://127.0.0.1:${port}/api/health" 2>/dev/null)"; then
      if echo "$body" | python3 -c "import sys,json; d=json.load(sys.stdin); assert d['status']=='ok' and d['node_id']==$expect_id and isinstance(d['node_id'], int)"; then
        return 0
      fi
    fi
    sleep 0.25
  done
  return 1
}

wait_redis() {
  local deadline=$((SECONDS + 30))
  while (( SECONDS < deadline )); do
    if redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
      return 0
    fi
    sleep 0.25
  done
  return 1
}

listener_pid() {
  local port="$1"
  local pid=""
  pid="$(ss -lptn "sport = :${port}" 2>/dev/null | sed -n 's/.*pid=\([0-9]*\).*/\1/p' | head -1 || true)"
  if [[ -z "$pid" ]]; then
    pid="$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null | head -1 || true)"
  fi
  echo "$pid"
}

"$ROOT/start.sh" > /tmp/huddle-start-test.log 2>&1 &
SUPERVISOR_PID=$!

sleep 0.5
if ! kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
  fail "supervisor exited immediately"
  cat /tmp/huddle-start-test.log || true
  exit 1
fi
pass "supervisor stays running"

if wait_redis; then pass "redis PING"; else fail "redis PING"; fi
if wait_http 8000 0; then pass "health :8000 node_id=0"; else fail "health :8000"; fi
if wait_http 8001 1; then pass "health :8001 node_id=1"; else fail "health :8001"; fi
if wait_http 8002 2; then pass "health :8002 node_id=2"; else fail "health :8002"; fi

NODE1_PID="$(listener_pid 8001)"
if [[ -n "$NODE1_PID" ]]; then
  kill -9 "$NODE1_PID"
  START=$SECONDS
  if wait_http 8001 1 && (( SECONDS - START <= 60 )); then
    pass "node-1 respawned in $((SECONDS - START))s"
  else
    fail "node-1 did not respawn within 60s"
  fi
  if wait_http 8000 0 && wait_http 8002 2; then
    pass "other nodes stayed up after node-1 kill"
  else
    fail "sibling nodes affected by node-1 kill"
  fi
else
  fail "could not find node-1 pid"
fi

REDIS_PID="$(listener_pid 6379)"
if [[ -n "$REDIS_PID" ]]; then
  kill -9 "$REDIS_PID"
  sleep 0.5
  if wait_http 8000 0 && wait_http 8001 1 && wait_http 8002 2; then
    pass "health ok while redis down/restarting"
  else
    fail "health failed during redis outage"
  fi
  if wait_redis; then pass "redis respawned"; else fail "redis did not respawn"; fi
else
  fail "could not find redis pid"
fi

echo "Results: $PASS passed, $FAIL failed"
if [[ "$FAIL" -ne 0 ]]; then
  echo "--- supervisor log ---"
  cat /tmp/huddle-start-test.log || true
  exit 1
fi
