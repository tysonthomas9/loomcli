'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'huddle-auth-'));
const dbPath = path.join(tmpDir, 'huddle.db');
process.env.HUDDLE_DB_PATH = dbPath;

const { initDb } = require('../server/db');
const { sendHealth } = require('../server/health');
const { sendJson } = require('../server/httpUtil');
const { handleAuthRoutes } = require('../server/auth/routes');
const { hashPassword, verifyPassword } = require('../server/auth/passwords');
const { resolveBearerUser } = require('../server/auth/middleware');

const USER_FIELDS = [
  'id',
  'username',
  'display_name',
  'timezone',
  'avatar_url',
  'status_text',
  'status_emoji',
];

function assertUserObj(user) {
  assert.equal(typeof user, 'object');
  assert.ok(user);
  for (const key of USER_FIELDS) {
    assert.equal(typeof user[key], 'string', `user.${key} must be string`);
  }
  assert.equal('password' in user, false);
  assert.equal('password_hash' in user, false);
  assert.equal('password_salt' in user, false);
}

function request(port, { method, path: pathname, body, headers = {} }) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? null : Buffer.from(JSON.stringify(body), 'utf8');
    const req = http.request(
      {
        host: '127.0.0.1',
        port,
        path: pathname,
        method,
        headers: {
          ...(payload
            ? {
                'Content-Type': 'application/json; charset=utf-8',
                'Content-Length': payload.length,
              }
            : {}),
          ...headers,
        },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try {
            json = JSON.parse(raw);
          } catch {
            json = null;
          }
          resolve({
            status: res.statusCode,
            headers: res.headers,
            raw,
            json,
          });
        });
      }
    );
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

describe('passwords', () => {
  it('hashes and verifies with timing-safe compare', () => {
    const { salt, hash } = hashPassword('password1');
    assert.ok(salt.length > 0);
    assert.ok(hash.length > 0);
    assert.equal(verifyPassword('password1', salt, hash), true);
    assert.equal(verifyPassword('password2', salt, hash), false);
  });
});

describe('auth HTTP contract', () => {
  let server;
  let port;
  let suffix;

  before(async () => {
    initDb();
    suffix = String(Date.now());
    server = http.createServer((req, res) => {
      let pathname = '/';
      try {
        pathname = new URL(req.url || '/', 'http://127.0.0.1').pathname;
      } catch {
        pathname = '/';
      }
      if (pathname === '/api/health') {
        if (req.method === 'GET') {
          sendHealth(res, 0);
          return;
        }
        sendJson(res, 405, { error: 'method_not_allowed' });
        return;
      }
      Promise.resolve(handleAuthRoutes(req, res, pathname))
        .then((handled) => {
          if (!handled) sendJson(res, 404, { error: 'not_found' });
        })
        .catch((err) => {
          console.error(err);
          if (!res.headersSent) sendJson(res, 500, { error: 'internal server error' });
        });
    });
    await new Promise((resolve, reject) => {
      server.listen(0, '127.0.0.1', () => {
        port = server.address().port;
        resolve();
      });
      server.on('error', reject);
    });
  });

  after(async () => {
    await new Promise((r) => server.close(r));
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  });

  it('registers with 201 user+token envelope', async () => {
    const res = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username: `alice_${suffix}`, password: 'password1' },
    });
    assert.equal(res.status, 201);
    assert.match(res.headers['content-type'] || '', /application\/json/);
    assertUserObj(res.json.user);
    assert.equal(res.json.user.username, `alice_${suffix}`);
    assert.equal(res.json.user.display_name, `alice_${suffix}`);
    assert.equal(res.json.user.timezone, 'UTC');
    assert.equal(typeof res.json.token, 'string');
    assert.ok(res.json.token.length >= 16);
  });

  it('register without email succeeds', async () => {
    const res = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username: `noemail_${suffix}`, password: 'password1' },
    });
    assert.equal(res.status, 201);
  });

  it('rejects short password with 400', async () => {
    const res = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username: `shortpw_${suffix}`, password: '1234567' },
    });
    assert.equal(res.status, 400);
    assert.equal(typeof res.json.error, 'string');
    assert.ok(res.json.error.length > 0);
  });

  it('rejects username with space or hyphen with 400', async () => {
    for (const username of [`bad name_${suffix}`, `bad-name_${suffix}`]) {
      const res = await request(port, {
        method: 'POST',
        path: '/api/auth/register',
        body: { username, password: 'password1' },
      });
      assert.equal(res.status, 400, username);
      assert.equal(typeof res.json.error, 'string');
    }
  });

  it('duplicate username any casing returns 409', async () => {
    const username = `dup_${suffix}`;
    const first = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username, password: 'password1' },
    });
    assert.equal(first.status, 201);
    const second = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username: username.toUpperCase(), password: 'password1' },
    });
    assert.equal(second.status, 409);
    assert.equal(typeof second.json.error, 'string');
  });

  it('login returns 200 with new token; wrong password and unknown user 401', async () => {
    const username = `login_${suffix}`;
    const reg = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username, password: 'password1', display_name: 'Login User' },
    });
    assert.equal(reg.status, 201);

    const ok = await request(port, {
      method: 'POST',
      path: '/api/auth/login',
      body: { username: username.toUpperCase(), password: 'password1' },
    });
    assert.equal(ok.status, 200);
    assertUserObj(ok.json.user);
    assert.equal(ok.json.user.display_name, 'Login User');
    assert.ok(ok.json.token.length >= 16);
    assert.notEqual(ok.json.token, reg.json.token);

    const badPw = await request(port, {
      method: 'POST',
      path: '/api/auth/login',
      body: { username, password: 'wrongpass' },
    });
    assert.equal(badPw.status, 401);

    const unknown = await request(port, {
      method: 'POST',
      path: '/api/auth/login',
      body: { username: `nosuch_${suffix}`, password: 'password1' },
    });
    assert.equal(unknown.status, 401);
  });

  it('GET /api/auth/me with bearer token', async () => {
    const reg = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username: `me_${suffix}`, password: 'password1' },
    });
    assert.equal(reg.status, 201);

    const me = await request(port, {
      method: 'GET',
      path: '/api/auth/me',
      headers: { Authorization: `Bearer ${reg.json.token}` },
    });
    assert.equal(me.status, 200);
    assertUserObj(me.json.user);
    assert.equal(me.json.user.id, reg.json.user.id);
    assert.equal(me.json.user.username, `me_${suffix}`);
    assert.equal('token' in me.json, false);

    const lower = await request(port, {
      method: 'GET',
      path: '/api/auth/me',
      headers: { Authorization: `bearer ${reg.json.token}` },
    });
    assert.equal(lower.status, 200);

    for (const headers of [
      {},
      { Authorization: 'Bearer' },
      { Authorization: 'Bearer ' },
      { Authorization: 'Bearer not-a-real-token-zzzz' },
      { Authorization: 'Basic abc' },
    ]) {
      const bad = await request(port, {
        method: 'GET',
        path: '/api/auth/me',
        headers,
      });
      assert.equal(bad.status, 401, JSON.stringify(headers));
    }
  });

  it('wrong method on auth routes is not 500', async () => {
    const res = await request(port, {
      method: 'GET',
      path: '/api/auth/register',
    });
    assert.ok(res.status === 405 || res.status === 404);
    assert.notEqual(res.status, 500);
  });

  it('health remains unchanged', async () => {
    const res = await request(port, { method: 'GET', path: '/api/health' });
    assert.equal(res.status, 200);
    assert.equal(res.json.status, 'ok');
    assert.equal(res.json.node_id, 0);
  });

  it('resolveBearerUser returns public user only', async () => {
    const reg = await request(port, {
      method: 'POST',
      path: '/api/auth/register',
      body: { username: `mw_${suffix}`, password: 'password1' },
    });
    const user = resolveBearerUser(`Bearer ${reg.json.token}`);
    assertUserObj(user);
    assert.equal(resolveBearerUser(null), null);
    assert.equal(resolveBearerUser('Bearer '), null);
  });
});
