#!/usr/bin/env bash
# QA verification for MARATHON-25 — start.sh self-contained port topology.
# Acceptance criteria from MARATHON-2 design (C2 + AC8/AC9 + kill-entrypoint).
# Run under: marathon-freeports; marathon-portlock ./test/qa-port-topology.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
chmod +x "$ROOT/start.sh"

PASS=0
FAIL=0
pass() { echo "PASS: $*"; PASS=$((PASS + 1)); }
fail() { echo "FAIL: $*"; FAIL=$((FAIL + 1)); }

SUPERVISOR_PID=""
SKIP_CLEANUP_KILL=0

cleanup() {
  if [[ "$SKIP_CLEANUP_KILL" -eq 1 ]]; then
    return 0
  fi
  if [[ -n "${SUPERVISOR_PID}" ]] && kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
    kill -TERM "$SUPERVISOR_PID" 2>/dev/null || true
    for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
      kill -0 "$SUPERVISOR_PID" 2>/dev/null || break
      sleep 0.2
    done
    kill -9 "$SUPERVISOR_PID" 2>/dev/null || true
    for port in 8000 8001 8002 6379; do
      local p
      p="$(listener_pid "$port" || true)"
      if [[ -n "${p:-}" ]]; then
        kill -9 "$p" 2>/dev/null || true
      fi
    done
    wait "$SUPERVISOR_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

assert_health_contract() {
  local port="$1" expect_id="$2"
  local tmp hdr status body
  tmp="$(mktemp)"
  hdr="$(mktemp)"
  status="$(curl -sS -m 2 -D "$hdr" -o "$tmp" -w '%{http_code}' "http://127.0.0.1:${port}/api/health" 2>/dev/null)" || status="000"
  body="$(cat "$tmp")"
  if [[ "$status" != "200" ]]; then
    echo "  health :${port}: expected HTTP 200 got ${status} body=${body}"
    rm -f "$tmp" "$hdr"
    return 1
  fi
  if ! tr -d '\r' < "$hdr" | awk -F': ' 'tolower($1)=="content-type"{print tolower($2)}' | grep -q 'application/json'; then
    echo "  health :${port}: Content-Type not application/json"
    rm -f "$tmp" "$hdr"
    return 1
  fi
  rm -f "$hdr"
  if ! EXPECT_ID="$expect_id" python3 -c "
import json, os, re, sys
raw = open(sys.argv[1]).read()
expect = int(os.environ['EXPECT_ID'])
d = json.loads(raw)
assert isinstance(d, dict), d
assert d.get('status') == 'ok', d
assert isinstance(d.get('node_id'), int) and not isinstance(d.get('node_id'), bool), d
assert d['node_id'] == expect, d
assert re.search(r'\"node_id\"\\s*:\\s*%d\\b' % expect, raw), raw
assert not re.search(r'\"node_id\"\\s*:\\s*\"%d\"' % expect, raw), raw
" "$tmp"; then
    echo "  health :${port}: contract failed body=${body}"
    rm -f "$tmp"
    return 1
  fi
  rm -f "$tmp"
  return 0
}

wait_health() {
  local port="$1" expect_id="$2" timeout_s="${3:-30}"
  local deadline=$((SECONDS + timeout_s))
  while (( SECONDS < deadline )); do
    if assert_health_contract "$port" "$expect_id" >/dev/null 2>&1; then
      return 0
    fi
    sleep 0.25
  done
  assert_health_contract "$port" "$expect_id" || true
  return 1
}

wait_redis() {
  local timeout_s="${1:-30}"
  local deadline=$((SECONDS + timeout_s))
  while (( SECONDS < deadline )); do
    if redis-cli -h 127.0.0.1 -p 6379 PING 2>/dev/null | grep -q PONG; then
      return 0
    fi
    sleep 0.25
  done
  return 1
}

listener_pid() {
  local port="$1"
  local pid=""
  pid="$(ss -lptn "sport = :${port}" 2>/dev/null | sed -n 's/.*pid=\([0-9]*\).*/\1/p' | head -1 || true)"
  if [[ -z "$pid" ]]; then
    pid="$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null | head -1 || true)"
  fi
  echo "$pid"
}

is_descendant_of() {
  # is_descendant_of <child_pid> <ancestor_pid>
  local child="$1" ancestor="$2" cur ppid
  cur="$child"
  for _ in $(seq 1 64); do
    [[ -n "$cur" && "$cur" != "0" && "$cur" != "1" ]] || return 1
    if [[ "$cur" == "$ancestor" ]]; then
      return 0
    fi
    ppid="$(awk '/^PPid:/{print $2}' "/proc/${cur}/status" 2>/dev/null || true)"
    [[ -n "$ppid" ]] || return 1
    cur="$ppid"
  done
  return 1
}

port_is_free() {
  local port="$1"
  local pid
  pid="$(listener_pid "$port" || true)"
  [[ -z "${pid:-}" ]]
}

health_refused() {
  local port="$1"
  local status
  status="$(curl -sS -m 2 -o /dev/null -w '%{http_code}' "http://127.0.0.1:${port}/api/health" 2>/dev/null)" || status="000"
  [[ "$status" == "000" ]]
}

# --- Static self-containment checks (no boot required) ---
if grep -Eiq 'docker|compose|kubectl|aws |gcloud |azure |slack\.com|api\.slack' "$ROOT/start.sh" "$ROOT/server/index.js" "$ROOT/server/health.js" "$ROOT/redis.conf" 2>/dev/null; then
  fail "AC8 MUST NOT: start.sh/server/redis.conf reference Docker or remote/cloud/Slack services"
else
  pass "AC8 static: no Docker/remote/Slack references in bootstrap files"
fi

if [[ -f "$ROOT/Dockerfile" || -f "$ROOT/docker-compose.yml" || -f "$ROOT/compose.yaml" ]]; then
  fail "AC8 MUST NOT: Docker-in-Docker artifacts present for cluster boot"
else
  pass "AC8 no Dockerfile/compose required for cluster"
fi

# --- Boot single supervisor ---
"$ROOT/start.sh" > /tmp/huddle-qa-topology.log 2>&1 &
SUPERVISOR_PID=$!

sleep 0.5
if ! kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
  fail "AC1 start.sh supervisor died immediately"
  cat /tmp/huddle-qa-topology.log || true
  exit 1
fi
pass "AC1 single start.sh supervisor stays foreground (pid=${SUPERVISOR_PID})"

if wait_redis 30; then
  pass "C2 Redis owned locally at 127.0.0.1:6379 (PING PONG)"
else
  fail "C2 Redis not reachable on 127.0.0.1:6379"
fi

if wait_health 8000 0 30; then pass "C2/AC3/AC5 :8000 → node_id 0 (number)"; else fail "C2/AC3 :8000 mapping"; fi
if wait_health 8001 1 30; then pass "C2/AC4/AC5 :8001 → node_id 1 (number)"; else fail "C2/AC4 :8001 mapping"; fi
if wait_health 8002 2 30; then pass "C2/AC4/AC5 :8002 → node_id 2 (number)"; else fail "C2/AC4 :8002 mapping"; fi

# Negative: MUST NOT remap — inverted expectations must fail the contract helper
neg_ok=1
if assert_health_contract 8000 1 >/dev/null 2>&1; then neg_ok=0; fi
if assert_health_contract 8001 0 >/dev/null 2>&1; then neg_ok=0; fi
if assert_health_contract 8002 0 >/dev/null 2>&1; then neg_ok=0; fi
if [[ "$neg_ok" -eq 1 ]]; then
  pass "AC9 MUST NOT: inverted node_id mapping rejected by contract (no silent remap)"
else
  fail "AC9 MUST NOT: contract accepted wrong node_id (remap risk)"
fi

# Bind address: local-only listeners
bind_ok=1
for port in 8000 8001 8002 6379; do
  if ! ss -lptn "sport = :${port}" 2>/dev/null | grep -qE '127\.0\.0\.1|\[::1\]|localhost'; then
    # Accept if ss shows *:port only when we already proved 127.0.0.1 curl works for HTTP;
    # Redis/HTTP must still not require a remote host.
    if [[ "$port" != "6379" ]] && ! assert_health_contract "$port" "$((port - 8000))" >/dev/null 2>&1; then
      bind_ok=0
    fi
  fi
done
if [[ "$bind_ok" -eq 1 ]]; then
  pass "AC8 listeners reachable only via 127.0.0.1 (self-contained, no remote broker)"
else
  fail "AC8 could not confirm local-only reachability"
fi

# Ownership: each listener PID is a descendant of the single start.sh supervisor
own_ok=1
declare -A PORT_EXPECT=( [8000]=0 [8001]=1 [8002]=2 [6379]=redis )
for port in 8000 8001 8002 6379; do
  lp="$(listener_pid "$port")"
  if [[ -z "$lp" ]]; then
    echo "  missing listener on :${port}"
    own_ok=0
    continue
  fi
  if ! is_descendant_of "$lp" "$SUPERVISOR_PID"; then
    echo "  :${port} pid=${lp} is NOT under supervisor ${SUPERVISOR_PID}"
    # Also accept: listener is the supervisor itself (unlikely) or direct child via process group
    if [[ "$lp" == "$SUPERVISOR_PID" ]]; then
      :
    else
      own_ok=0
    fi
  fi
done
if [[ "$own_ok" -eq 1 ]]; then
  pass "C2 only one start.sh supervisor owns listeners on :6379/:8000/:8001/:8002"
else
  fail "C2 listener ownership: ports not under single start.sh supervisor tree"
fi

# Negative: a second start.sh must NOT successfully own the same fixed ports
SECOND_LOG=/tmp/huddle-qa-topology-second.log
"$ROOT/start.sh" > "$SECOND_LOG" 2>&1 &
SECOND_PID=$!
sleep 2
# First supervisor must still be the healthy owner
if kill -0 "$SUPERVISOR_PID" 2>/dev/null && assert_health_contract 8000 0 && assert_health_contract 8001 1 && assert_health_contract 8002 2; then
  pass "AC9/edge double-start: original supervisor keeps correct port map"
else
  fail "AC9/edge double-start disrupted original supervisor topology"
fi
# Second instance should not replace mapping (health still correct above). Reap second.
if kill -0 "$SECOND_PID" 2>/dev/null; then
  kill -TERM "$SECOND_PID" 2>/dev/null || true
  sleep 1
  kill -9 "$SECOND_PID" 2>/dev/null || true
  wait "$SECOND_PID" 2>/dev/null || true
fi
# Ensure first still healthy after killing second
if assert_health_contract 8000 0 && assert_health_contract 8001 1 && assert_health_contract 8002 2; then
  pass "edge double-start teardown left original :8000/:8001/:8002 map intact"
else
  fail "edge double-start teardown broke original port topology"
fi

# Health MUST NOT require Redis
REDIS_LP="$(listener_pid 6379)"
if [[ -z "$REDIS_LP" ]]; then
  fail "AC7/AC9 could not resolve Redis listener before kill"
else
  kill -9 "$REDIS_LP"
  sleep 0.3
  health_ok=1
  for _ in 1 2 3 4 5 6; do
    if ! assert_health_contract 8000 0 || ! assert_health_contract 8001 1 || ! assert_health_contract 8002 2; then
      health_ok=0
      break
    fi
    sleep 0.15
  done
  if [[ "$health_ok" -eq 1 ]]; then
    pass "AC7/AC9 MUST NOT: health still 200 with correct node_ids while Redis down"
  else
    fail "AC7/AC9 health required Redis (failed during Redis outage)"
  fi
  # Allow supervisor to respawn Redis so later teardown is clean
  wait_redis 60 || true
fi

# Killing start.sh stops keeping the service up (harness entrypoint teardown)
SKIP_CLEANUP_KILL=1
kill -TERM "$SUPERVISOR_PID" 2>/dev/null || true
for _ in $(seq 1 40); do
  kill -0 "$SUPERVISOR_PID" 2>/dev/null || break
  sleep 0.25
done
if kill -0 "$SUPERVISOR_PID" 2>/dev/null; then
  kill -9 "$SUPERVISOR_PID" 2>/dev/null || true
  sleep 0.5
fi
wait "$SUPERVISOR_PID" 2>/dev/null || true
SUPERVISOR_PID=""

# Give trap time to reap children
sleep 1
down_ok=1
for port in 8000 8001 8002; do
  if ! health_refused "$port"; then
    echo "  :${port} still answering health after start.sh death"
    down_ok=0
  fi
done
# Redis should also be gone (or at least not the supervisor's child keeping cluster up)
if wait_redis 1; then
  # If something else holds Redis, still fail for harness entrypoint semantics unless free
  if ! port_is_free 6379; then
    echo "  :6379 still listening after start.sh death"
    down_ok=0
  fi
fi
for port in 8000 8001 8002 6379; do
  if ! port_is_free "$port"; then
    # Force-kill leftovers for the agent environment, but count as fail
    lp="$(listener_pid "$port" || true)"
    echo "  port :${port} still held by pid=${lp:-unknown}"
    down_ok=0
    [[ -n "${lp:-}" ]] && kill -9 "$lp" 2>/dev/null || true
  fi
done

if [[ "$down_ok" -eq 1 ]]; then
  pass "entrypoint: killing start.sh stops Redis/:8000/:8001/:8002 (services not kept up)"
else
  fail "entrypoint: killing start.sh left cluster ports serving (orphans)"
fi

echo "Results: $PASS passed, $FAIL failed"
if [[ "$FAIL" -ne 0 ]]; then
  echo "--- supervisor log ---"
  cat /tmp/huddle-qa-topology.log || true
  exit 1
fi
exit 0
